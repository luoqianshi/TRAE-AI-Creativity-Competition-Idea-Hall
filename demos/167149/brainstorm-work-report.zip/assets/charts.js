(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  var chartTimeline = echarts.init(document.getElementById('chart-timeline'), null, { renderer: 'svg' });

  var categories = [
    '概念设计与需求分析',
    'MVP 全栈开发',
    '功能完善与体验优化',
    '多语言扩展与运营'
  ];

  var data = [
    { name: '概念设计与需求分析', value: [0, '2026-07-11', '2026-07-16'], itemStyle: { color: '#94a3b8' } },
    { name: 'MVP 全栈开发', value: [1, '2026-07-13', '2026-07-15'], itemStyle: { color: '#94a3b8' } },
    { name: '功能完善与体验优化', value: [2, '2026-07-16', '2026-09-30'], itemStyle: { color: accent } },
    { name: '多语言扩展与运营', value: [3, '2026-10-01', '2026-12-31'], itemStyle: { color: muted } }
  ];

  function renderItem(params, api) {
    var categoryIndex = api.value(0);
    var start = api.coord([api.value(1), categoryIndex]);
    var end = api.coord([api.value(2), categoryIndex]);
    var height = api.size([0, 1])[1] * 0.45;
    var rectShape = echarts.graphic.clipRectByRect({
      x: start[0],
      y: start[1] - height / 2,
      width: end[0] - start[0],
      height: height
    }, {
      x: params.coordSys.x,
      y: params.coordSys.y,
      width: params.coordSys.width,
      height: params.coordSys.height
    });

    var labelRect = rectShape ? echarts.graphic.clipRectByRect({
      x: rectShape.x + 6,
      y: rectShape.y + 2,
      width: rectShape.width - 12,
      height: rectShape.height - 4
    }, {
      x: rectShape.x,
      y: rectShape.y,
      width: rectShape.width,
      height: rectShape.height
    }) : null;

    var children = [];
    if (rectShape) {
      children.push({
        type: 'rect',
        shape: rectShape,
        style: api.style({
          fill: params.data.itemStyle.color,
          opacity: rectShape.width > 20 ? 0.8 : 0.5
        }),
        transition: ['shape']
      });
    }
    if (labelRect && labelRect.width > 50) {
      children.push({
        type: 'text',
        style: {
          text: params.data.name,
          x: labelRect.x + labelRect.width / 2,
          y: labelRect.y + labelRect.height / 2,
          textAlign: 'center',
          textVerticalAlign: 'middle',
          fill: '#fff',
          fontSize: 11,
          fontWeight: 600
        }
      });
    }
    return { type: 'group', children: children };
  }

  chartTimeline.setOption({
    animation: false,
    tooltip: {
      formatter: function(params) {
        return params.marker + params.name + '<br>' + params.value[1] + ' ~ ' + params.value[2];
      },
      appendToBody: true
    },
    grid: {
      top: 20,
      bottom: 40,
      left: 160,
      right: 30
    },
    xAxis: {
      type: 'time',
      axisLabel: {
        formatter: '{MM}-{dd}',
        color: muted,
        fontSize: 11
      },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { show: true, lineStyle: { color: rule, type: 'dashed' } }
    },
    yAxis: {
      type: 'category',
      data: categories,
      axisLabel: {
        color: ink,
        fontWeight: 600,
        fontSize: 11
      },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false },
      splitLine: { show: false }
    },
    series: [{
      type: 'custom',
      renderItem: renderItem,
      encode: {
        x: [1, 2],
        y: 0
      },
      data: data
    }],
    graphic: [{
      type: 'text',
      left: 'center',
      bottom: 8,
      style: {
        text: '灰色 = 已完成  |  蓝色 = 当前阶段  |  浅灰 = 规划中',
        fill: muted,
        fontSize: 11
      }
    }]
  });

  window.addEventListener('resize', function() {
    chartTimeline.resize();
  });
})();