(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: 功能模块完成度 (Bar) ---
  var chartModule = echarts.init(document.getElementById('chart-module-progress'), null, { renderer: 'svg' });
  chartModule.setOption({
    animation: false,
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true },
    grid: { left: '3%', right: '8%', bottom: '3%', top: '8%', containLabel: true },
    xAxis: {
      type: 'value',
      max: 100,
      axisLabel: { formatter: '{value}%', color: muted },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: ['用户认证', '脑图模块', '单词详情', '搜索过滤', '关系网络', '级别管理', '词根学习', '学习进度', '学习记录', '智能推荐', '每日复习', '词汇测评', '学习轨迹', '薄弱识别', '标签系统', '全量词库'],
      axisLabel: { color: ink, fontSize: 13 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    series: [{
      type: 'bar',
      data: [
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 85, itemStyle: { color: '#fde68a', borderRadius: [0, 4, 4, 0] } },
        { value: 100, itemStyle: { color: '#86efac', borderRadius: [0, 4, 4, 0] } },
        { value: 75, itemStyle: { color: '#fde68a', borderRadius: [0, 4, 4, 0] } },
        { value: 60, itemStyle: { color: '#fde68a', borderRadius: [0, 4, 4, 0] } },
        { value: 30, itemStyle: { color: '#fca5a5', borderRadius: [0, 4, 4, 0] } },
        { value: 0, itemStyle: { color: '#fca5a5', borderRadius: [0, 4, 4, 0] } },
        { value: 0, itemStyle: { color: '#fca5a5', borderRadius: [0, 4, 4, 0] } },
        { value: 0, itemStyle: { color: '#fca5a5', borderRadius: [0, 4, 4, 0] } },
        { value: 5, itemStyle: { color: '#fca5a5', borderRadius: [0, 4, 4, 0] } }
      ],
      barWidth: '55%',
      label: {
        show: true,
        position: 'right',
        formatter: function(p) { return p.value + '%'; },
        color: ink,
        fontSize: 12,
        fontWeight: 'bold'
      }
    }]
  });
  window.addEventListener('resize', function() { chartModule.resize(); });

  // --- Chart: 功能完成度分布 (Pie) ---
  var chartPie = echarts.init(document.getElementById('chart-pie-completion'), null, { renderer: 'svg' });
  chartPie.setOption({
    animation: false,
    tooltip: { trigger: 'item', formatter: '{b}: {c} 项 ({d}%)', appendToBody: true },
    legend: {
      orient: 'vertical',
      right: '5%',
      top: 'center',
      textStyle: { color: ink, fontSize: 13 },
      itemWidth: 14,
      itemHeight: 14
    },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      center: ['35%', '50%'],
      avoidLabelOverlap: true,
      itemStyle: { borderRadius: 6, borderColor: bg2, borderWidth: 3 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold', color: ink } },
      data: [
        { value: 9, name: '已完成', itemStyle: { color: '#86efac' } },
        { value: 3, name: '部分完成', itemStyle: { color: '#fde68a' } },
        { value: 4, name: '未实现', itemStyle: { color: '#fca5a5' } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chartPie.resize(); });

  // --- Chart: 项目时间线 (Gantt-style Custom) ---
  var chartTimeline = echarts.init(document.getElementById('chart-timeline'), null, { renderer: 'svg' });
  var categories = ['架构设计', '后端开发', '前端开发', '测试', 'Bug修复'];
  var data = [
    { name: '架构设计', value: [0, '2026-07-10', '2026-07-11'], itemStyle: { color: accent } },
    { name: '后端开发', value: [1, '2026-07-11', '2026-07-14'], itemStyle: { color: accent } },
    { name: '前端开发', value: [2, '2026-07-13', '2026-07-14'], itemStyle: { color: accent } },
    { name: '测试', value: [3, '2026-07-13', '2026-07-15'], itemStyle: { color: '#86efac' } },
    { name: 'Bug修复', value: [4, '2026-07-13', '2026-07-15'], itemStyle: { color: '#fde68a' } }
  ];

  function renderGanttItem(params, api) {
    var categoryIndex = api.value(0);
    var start = api.coord([api.value(1), categoryIndex]);
    var end = api.coord([api.value(2), categoryIndex]);
    var height = api.size([0, 1])[1] * 0.5;
    var rectShape = echarts.graphic.clipRectByRect({
      x: start[0], y: start[1] - height / 2, width: end[0] - start[0], height: height
    }, { x: params.coordSys.x, y: params.coordSys.y, width: params.coordSys.width, height: params.coordSys.height });
    return rectShape && {
      type: 'rect',
      transition: ['shape'],
      shape: rectShape,
      style: api.style()
    };
  }

  chartTimeline.setOption({
    animation: false,
    tooltip: {
      formatter: function(p) {
        return p.marker + ' ' + p.name + '<br>' + p.value[1] + ' ~ ' + p.value[2];
      },
      appendToBody: true
    },
    grid: { left: '12%', right: '4%', top: '8%', bottom: '8%' },
    xAxis: {
      type: 'time',
      min: '2026-07-09',
      max: '2026-07-16',
      axisLabel: { color: muted, formatter: '{MM}-{dd}' },
      splitLine: { show: true, lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'category',
      data: categories,
      axisLabel: { color: ink, fontSize: 13 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    series: [{
      type: 'custom',
      renderItem: renderGanttItem,
      itemStyle: { opacity: 0.9, borderRadius: 4 },
      encode: { x: [1, 2], y: 0 },
      data: data
    }]
  });
  window.addEventListener('resize', function() { chartTimeline.resize(); });

  // --- Chart: 后续任务优先级分布 (Bar) ---
  var chartPriority = echarts.init(document.getElementById('chart-priority'), null, { renderer: 'svg' });
  chartPriority.setOption({
    animation: false,
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, appendToBody: true },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '3%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['高优先级', '中优先级', '低优先级'],
      axisLabel: { color: ink, fontSize: 13 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'bar',
      data: [
        { value: 4, itemStyle: { color: '#fca5a5', borderRadius: [4, 4, 0, 0] } },
        { value: 6, itemStyle: { color: '#fde68a', borderRadius: [4, 4, 0, 0] } },
        { value: 3, itemStyle: { color: '#86efac', borderRadius: [4, 4, 0, 0] } }
      ],
      barWidth: '50%',
      label: { show: true, position: 'top', color: ink, fontSize: 14, fontWeight: 'bold' }
    }]
  });
  window.addEventListener('resize', function() { chartPriority.resize(); });

})();
