(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: 遗忘曲线复习间隔 ---
  var chart1 = echarts.init(document.getElementById('chart-forgetting'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      formatter: function(params) {
        var p = params[0];
        return '熟悉度 ' + p.name + '<br/>复习间隔: ' + p.value + ' 天';
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['0\n完全陌生', '1\n略有印象', '2\n基本认识', '3\n比较熟悉', '4\n熟练掌握', '5\n完全掌握'],
      axisLabel: {
        color: muted,
        fontSize: 12,
        interval: 0
      },
      axisLine: {
        lineStyle: { color: rule }
      }
    },
    yAxis: {
      type: 'value',
      name: '复习间隔（天）',
      nameTextStyle: { color: muted, fontSize: 12 },
      axisLabel: { color: muted, fontSize: 12 },
      splitLine: { lineStyle: { color: rule } },
      axisLine: { show: false }
    },
    series: [{
      type: 'line',
      data: [1, 2, 4, 7, 15, 30],
      smooth: true,
      symbol: 'circle',
      symbolSize: 10,
      lineStyle: {
        width: 3,
        color: accent
      },
      itemStyle: {
        color: accent,
        borderColor: bg2,
        borderWidth: 2
      },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: accent + '33' },
            { offset: 1, color: accent + '05' }
          ]
        }
      },
      label: {
        show: true,
        position: 'top',
        formatter: '{c}天',
        color: ink,
        fontSize: 12,
        fontWeight: 600
      }
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart: 测试用例分布 ---
  var chart2 = echarts.init(document.getElementById('chart-testing'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      formatter: '{b}: {c} 个 ({d}%)'
    },
    legend: {
      orient: 'vertical',
      right: '5%',
      top: 'center',
      textStyle: { color: ink, fontSize: 13 },
      itemWidth: 14,
      itemHeight: 14
    },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      center: ['35%', '50%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 6,
        borderColor: bg2,
        borderWidth: 2
      },
      label: {
        show: false
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 14,
          fontWeight: 'bold',
          color: ink
        }
      },
      data: [
        { value: 25, name: '数据库验证', itemStyle: { color: accent } },
        { value: 1, name: '性能测试', itemStyle: { color: accent2 } },
        { value: 10, name: '代码审查', itemStyle: { color: muted } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });
})();
