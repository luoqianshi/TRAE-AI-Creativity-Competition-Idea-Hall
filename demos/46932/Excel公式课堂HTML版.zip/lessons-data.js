const LESSONS = [
  {
    "id": "formula-basic",
    "title": "公式与函数基础",
    "chapter": "第 1 章",
    "description": "覆盖公式输入、引用类型、名称、数组公式、错误检查、公式求值和常用技巧，是学习后续函数的基础。",
    "formula": "=B2*C2",
    "goal": "理解公式由等号、引用、运算符和常量组成，并掌握相对引用与绝对引用。",
    "result": "3600",
    "explanation": "公式先读取单元格引用，再按运算符优先级计算。复制公式时，相对引用会随位置变化，绝对引用会保持固定。",
    "steps": [
      "输入等号开始公式",
      "读取 B2 与 C2",
      "执行乘法运算",
      "返回计算值"
    ],
    "sheet": [
      {
        "A": "商品",
        "B": "单价",
        "C": "数量",
        "D": "金额"
      },
      {
        "A": "键盘",
        "B": 120,
        "C": 30,
        "D": "待计算"
      },
      {
        "A": "鼠标",
        "B": 80,
        "C": 24,
        "D": "待计算"
      }
    ],
    "references": [
      "输入公式",
      "编辑公式",
      "单元格引用",
      "名称",
      "数组公式",
      "错误检查",
      "公式求值器"
    ],
    "functions": [
      "相对引用",
      "绝对引用",
      "混合引用",
      "名称管理器",
      "数组常量",
      "循环引用"
    ],
    "funcDetails": [
      {
        "name": "相对引用",
        "syntax": "=A1",
        "params": "直接使用列标+行号，如 A1、B2",
        "notes": "复制公式时行列会自动偏移。向下复制行号+1，向右复制列标+1。",
        "example": "在 D2 输入 =B2*C2，向下拖拽到 D3，自动变为 =B3*C3",
        "exampleResult": "D3 = B3*C3",
        "relatedFormulas": [
          {
            "name": "绝对引用",
            "relation": "互补函数",
            "desc": "相对引用随位置变化，绝对引用固定不变"
          },
          {
            "name": "混合引用",
            "relation": "扩展版",
            "desc": "混合引用只锁定一个方向"
          }
        ],
        "animation": {
          "formula": "=B2*C2",
          "steps": [
            "输入 =B2*C2",
            "B2 引用键盘单价 120",
            "C2 引用键盘数量 30",
            "计算 120×30=3600",
            "向下复制变为 =B3*C3"
          ],
          "result": "D3 自动变为 =B3*C3",
          "highlight": [
            "B2",
            "C2",
            "复制",
            "偏移"
          ]
        }
      },
      {
        "name": "绝对引用",
        "syntax": "=$A$1",
        "params": "在列标和行号前加 $ 符号，如 $A$1",
        "notes": "复制公式时引用位置固定不变。按 F4 可快速切换引用类型。",
        "example": "在 D2 输入 =B2*$C$1，向下拖拽，$C$1 始终指向 C1",
        "exampleResult": "D3 = B3*$C$1",
        "relatedFormulas": [
          {
            "name": "相对引用",
            "relation": "互补函数",
            "desc": "绝对引用固定位置，相对引用随位置变化"
          },
          {
            "name": "混合引用",
            "relation": "简化版",
            "desc": "混合引用是绝对引用和相对引用的结合"
          }
        ],
        "animation": {
          "formula": "=$B$1*C2",
          "steps": [
            "输入 =$B$1*C2",
            "$B$1 锁定汇率单元格",
            "C2 引用第一个金额",
            "计算汇率×金额",
            "向下复制 $B$1 不变"
          ],
          "result": "$B$1 始终指向固定单元格",
          "highlight": [
            "$",
            "锁定",
            "固定",
            "F4"
          ]
        }
      },
      {
        "name": "混合引用",
        "syntax": "=$A1 或 =A$1",
        "params": "只锁定列或只锁定行，如 $A1 锁定列、A$1 锁定行",
        "notes": "适用于乘法表、九九乘法表等一个维度固定、另一个维度变化的场景。",
        "example": "=$A2*B$1，向右复制时 A 列不变，向下复制时 1 行不变",
        "exampleResult": "灵活生成乘法表",
        "relatedFormulas": [
          {
            "name": "绝对引用",
            "relation": "组合使用",
            "desc": "混合引用是 $A1 或 A$1 形式"
          },
          {
            "name": "相对引用",
            "relation": "组合使用",
            "desc": "理解三种引用类型是公式基础"
          }
        ],
        "animation": {
          "formula": "=$A2*B$1",
          "steps": [
            "输入 =$A2*B$1",
            "$A2 锁定A列，行可变",
            "B$1 锁定第1行，列可变",
            "向右复制 A 列不变",
            "向下复制第1行不变"
          ],
          "result": "灵活生成乘法表或交叉表",
          "highlight": [
            "$A",
            "B$",
            "锁定",
            "变化"
          ]
        }
      },
      {
        "name": "名称管理器",
        "syntax": "名称 → 定义名称",
        "params": "在\"公式\"选项卡 → \"定义名称\"中创建",
        "notes": "名称可代替单元格地址，使公式更易读。名称有工作簿级和工作表级两种作用范围。",
        "example": "将 B2:B10 命名为\"销售额\"，之后用 =SUM(销售额)",
        "exampleResult": "SUM(销售额) = SUM(B2:B10)",
        "relatedFormulas": [
          {
            "name": "绝对引用",
            "relation": "替代方案",
            "desc": "名称可替代复杂的绝对引用地址"
          },
          {
            "name": "数组公式",
            "relation": "组合使用",
            "desc": "名称可简化数组公式的可读性"
          }
        ],
        "animation": {
          "formula": "=SUM(销售额)",
          "steps": [
            "定义名称：销售额 → B2:B10",
            "在公式中使用名称",
            "Excel 自动解析为区域",
            "=SUM(销售额) 等价于 =SUM(B2:B10)",
            "名称使公式更易读"
          ],
          "result": "=SUM(销售额) = SUM(B2:B10)",
          "highlight": [
            "名称",
            "定义",
            "销售额",
            "易读"
          ]
        }
      },
      {
        "name": "数组公式",
        "syntax": "{=公式}",
        "params": "输入公式后按 Ctrl+Shift+Enter",
        "notes": "数组公式可同时计算多值。旧版需 CSE 三键，Excel 365 支持动态数组无需三键。",
        "example": "{=SUM(B2:B6*C2:C6)} 逐行相乘再求和",
        "exampleResult": "等同于 SUMPRODUCT",
        "relatedFormulas": [
          {
            "name": "SUMPRODUCT",
            "relation": "替代方案",
            "desc": "SUMPRODUCT 可替代部分数组公式"
          },
          {
            "name": "名称管理器",
            "relation": "组合使用",
            "desc": "命名区域配合数组公式更易维护"
          }
        ],
        "animation": {
          "formula": "{=SUM(B2:B6*C2:C6)}",
          "steps": [
            "输入 =SUM(B2:B6*C2:C6)",
            "按 Ctrl+Shift+Enter",
            "Excel 添加花括号 {}",
            "逐行相乘：B2*C2, B3*C3...",
            "SUM 汇总所有乘积"
          ],
          "result": "等同于 SUMPRODUCT(B2:B6,C2:C6)",
          "highlight": [
            "数组",
            "Ctrl+Shift+Enter",
            "{}",
            "逐行"
          ]
        }
      }
    ]
  },
  {
    "id": "math-trig",
    "title": "数学和三角函数",
    "chapter": "第 2 章",
    "description": "覆盖求和、舍入、取余、随机数、矩阵、组合、阶乘、三角函数和分类汇总等数学计算场景。",
    "formula": "=SUMIF(B2:B6,\"销售部\",C2:C6)",
    "goal": "按部门汇总员工年薪，理解条件求和的三个参数。",
    "result": "300000",
    "explanation": "SUMIF 用条件区域判断每一行是否满足条件，再把对应求和区域中的数值累加。",
    "steps": [
      "读取条件区域 B2:B6",
      "匹配\"销售部\"",
      "定位 C 列对应薪资",
      "累加并返回结果"
    ],
    "sheet": [
      {
        "A": "员工",
        "B": "部门",
        "C": "年薪"
      },
      {
        "A": "张三",
        "B": "销售部",
        "C": 160000
      },
      {
        "A": "李四",
        "B": "销售部",
        "C": 140000
      },
      {
        "A": "王五",
        "B": "技术部",
        "C": 180000
      },
      {
        "A": "赵六",
        "B": "财务部",
        "C": 130000
      },
      {
        "A": "孙七",
        "B": "技术部",
        "C": 175000
      }
    ],
    "references": [
      "求和",
      "舍入",
      "整数与余数",
      "矩阵",
      "随机数",
      "三角函数",
      "分类汇总"
    ],
    "functions": [
      "SUM",
      "SUMIF",
      "SUMIFS",
      "SUMPRODUCT",
      "ROUND",
      "ROUNDUP",
      "ROUNDDOWN",
      "INT",
      "MOD",
      "QUOTIENT",
      "RAND",
      "RANDBETWEEN",
      "SUBTOTAL",
      "AGGREGATE",
      "ABS",
      "SQRT",
      "POWER",
      "PI",
      "SIN",
      "COS",
      "TAN",
      "MMULT",
      "MINVERSE"
    ],
    "funcDetails": [
      {
        "name": "SUM",
        "syntax": "=SUM(number1, [number2], ...)",
        "params": "number1：必填，第一个数值或区域；number2...：可选，更多数值或区域",
        "notes": "忽略文本和空白单元格。支持 255 个参数。区域引用如 SUM(A1:A100) 最常用。",
        "example": "=SUM(B2:B6) 计算 B2 到 B6 的总和",
        "exampleResult": "所有数值之和",
        "relatedFormulas": [
          {
            "name": "SUMIF",
            "relation": "扩展版",
            "desc": "SUMIF 支持条件求和"
          },
          {
            "name": "SUMPRODUCT",
            "relation": "组合使用",
            "desc": "SUMPRODUCT 可实现条件求和与数组运算"
          },
          {
            "name": "SUBTOTAL",
            "relation": "替代方案",
            "desc": "SUBTOTAL 支持多种聚合方式"
          }
        ],
        "animation": {
          "formula": "=SUM(B2:B6)",
          "steps": [
            "选择求和区域 B2:B6",
            "逐个读取数值",
            "累加所有数值",
            "忽略文本和空值",
            "返回总和"
          ],
          "result": "所有数值之和",
          "highlight": [
            "SUM",
            "求和",
            "累加",
            "区域"
          ]
        }
      },
      {
        "name": "SUMIF",
        "syntax": "=SUMIF(range, criteria, [sum_range])",
        "params": "range：条件区域；criteria：条件（可用通配符 * ?）；sum_range：求和区域（可选）",
        "notes": "条件区域和求和区域的行数必须一致。条件中的文本需加引号，数字可省略引号。",
        "example": "=SUMIF(B2:B6,\"销售部\",C2:C6)",
        "exampleResult": "销售部年薪合计 300000",
        "relatedFormulas": [
          {
            "name": "SUMIFS",
            "relation": "扩展版",
            "desc": "SUMIFS 支持多条件求和"
          },
          {
            "name": "SUM",
            "relation": "简化版",
            "desc": "SUM 是无条件求和"
          },
          {
            "name": "COUNTIF",
            "relation": "互补函数",
            "desc": "COUNTIF 按条件计数而非求和"
          }
        ],
        "animation": {
          "formula": "=SUMIF(B2:B6,\"销售部\",C2:C6)",
          "steps": [
            "读取条件区域 B2:B6",
            "逐行匹配\"销售部\"",
            "第1行：销售部 ✓ → 取 C2",
            "第2行：销售部 ✓ → 取 C3",
            "累加匹配行的薪资"
          ],
          "result": "销售部年薪合计 300000",
          "highlight": [
            "SUMIF",
            "条件",
            "匹配",
            "求和"
          ]
        }
      },
      {
        "name": "SUMIFS",
        "syntax": "=SUMIFS(sum_range, criteria_range1, criteria1, ...)",
        "params": "sum_range：求和区域；criteria_range：条件区域；criteria：条件。可多条件",
        "notes": "参数顺序与 SUMIF 相反，sum_range 在最前面。支持最多 127 个条件对。",
        "example": "=SUMIFS(C2:C6,B2:B6,\"销售部\",C2:C6,\">150000\")",
        "exampleResult": "销售部年薪>15万的总和",
        "relatedFormulas": [
          {
            "name": "SUMIF",
            "relation": "简化版",
            "desc": "SUMIF 只支持单条件"
          },
          {
            "name": "COUNTIFS",
            "relation": "互补函数",
            "desc": "COUNTIFS 按多条件计数"
          },
          {
            "name": "AVERAGEIFS",
            "relation": "互补函数",
            "desc": "AVERAGEIFS 按多条件求平均"
          }
        ],
        "animation": {
          "formula": "=SUMIFS(C2:C6,B2:B6,\"销售部\",C2:C6,\">150000\")",
          "steps": [
            "读取求和区域 C2:C6",
            "条件1：部门=销售部",
            "条件2：薪资>150000",
            "同时满足两个条件",
            "累加匹配结果"
          ],
          "result": "销售部且薪资>15万的合计",
          "highlight": [
            "SUMIFS",
            "多条件",
            "同时满足",
            "求和区域"
          ]
        }
      },
      {
        "name": "ROUND",
        "syntax": "=ROUND(number, num_digits)",
        "params": "number：要舍入的数字；num_digits：保留的小数位数，负数表示向左舍入",
        "notes": "四舍五入。ROUND(2.345,2)=2.35，ROUND(1234,-2)=1200。与格式化不同，ROUND 真正改变数值。",
        "example": "=ROUND(3.14159,2)",
        "exampleResult": "3.14",
        "relatedFormulas": [
          {
            "name": "ROUNDUP / ROUNDDOWN",
            "relation": "扩展版",
            "desc": "ROUNDUP/ROUNDDOWN 控制舍入方向"
          },
          {
            "name": "INT",
            "relation": "替代方案",
            "desc": "INT 向下取整到整数"
          },
          {
            "name": "MOD",
            "relation": "互补函数",
            "desc": "MOD 取余数而非四舍五入"
          }
        ],
        "animation": {
          "formula": "=ROUND(3.14159, 2)",
          "steps": [
            "读取数值 3.14159",
            "读取小数位数 2",
            "判断第3位小数 ≥5",
            "四舍五入到2位",
            "返回 3.14"
          ],
          "result": "3.14",
          "highlight": [
            "ROUND",
            "四舍五入",
            "小数位",
            "精度"
          ]
        }
      },
      {
        "name": "ROUNDUP / ROUNDDOWN",
        "syntax": "=ROUNDUP(number, num_digits)",
        "params": "number：要舍入的数字；num_digits：保留位数",
        "notes": "ROUNDUP 远离零方向进位，ROUNDDOWN 向零方向截断。常用于定价和预算场景。",
        "example": "=ROUNDUP(3.141,2) → 3.15；=ROUNDDOWN(3.149,2) → 3.14",
        "exampleResult": "3.15 / 3.14",
        "relatedFormulas": [
          {
            "name": "ROUND",
            "relation": "简化版",
            "desc": "ROUND 四舍五入到指定位数"
          },
          {
            "name": "INT",
            "relation": "替代方案",
            "desc": "INT 直接截断小数部分"
          }
        ],
        "animation": {
          "formula": "=ROUNDUP(3.141, 2)",
          "steps": [
            "读取数值 3.141",
            "ROUNDUP：无条件向上进位",
            "保留2位小数",
            "第3位是1，仍进位",
            "返回 3.15"
          ],
          "result": "ROUNDUP→3.15, ROUNDDOWN→3.14",
          "highlight": [
            "ROUNDUP",
            "向上",
            "ROUNDDOWN",
            "向下"
          ]
        }
      },
      {
        "name": "MOD",
        "syntax": "=MOD(number, divisor)",
        "params": "number：被除数；divisor：除数（不能为 0）",
        "notes": "返回余数。MOD(10,3)=1。可用于判断奇偶（MOD(n,2)）、分组、周期计算。",
        "example": "=MOD(A2,2) 判断奇偶",
        "exampleResult": "0=偶数, 1=奇数",
        "relatedFormulas": [
          {
            "name": "INT",
            "relation": "组合使用",
            "desc": "INT 和 MOD 常配合处理整数与小数"
          },
          {
            "name": "QUOTIENT",
            "relation": "互补函数",
            "desc": "QUOTIENT 返回商的整数部分"
          }
        ],
        "animation": {
          "formula": "=MOD(10, 3)",
          "steps": [
            "读取被除数 10",
            "读取除数 3",
            "计算 10÷3=3...1",
            "取余数部分",
            "返回 1"
          ],
          "result": "1（10除以3余1）",
          "highlight": [
            "MOD",
            "余数",
            "除数",
            "被除数"
          ]
        }
      },
      {
        "name": "INT",
        "syntax": "=INT(number)",
        "params": "number：要取整的数字",
        "notes": "向下取整到最接近的整数。INT(7.8)=7，INT(-7.8)=-8。与 TRUNC 不同，INT 总是向下。",
        "example": "=INT(7.8) → 7；=INT(-7.8) → -8",
        "exampleResult": "7 / -8",
        "relatedFormulas": [
          {
            "name": "ROUND",
            "relation": "替代方案",
            "desc": "ROUND 可四舍五入而非截断"
          },
          {
            "name": "MOD",
            "relation": "组合使用",
            "desc": "INT 和 MOD 常配合使用"
          }
        ],
        "animation": {
          "formula": "=INT(3.7)",
          "steps": [
            "读取数值 3.7",
            "向零取整",
            "截断小数部分",
            "返回整数",
            "注意：INT(-3.7)=-4（向下取整）"
          ],
          "result": "3",
          "highlight": [
            "INT",
            "取整",
            "截断",
            "向下"
          ]
        }
      },
      {
        "name": "SUBTOTAL",
        "syntax": "=SUBTOTAL(function_num, ref1, ...)",
        "params": "function_num：1-11 或 101-111 代表不同聚合函数；ref：区域",
        "notes": "101-111 版本忽略隐藏行。常用于筛选后的汇总，不会重复计算。",
        "example": "=SUBTOTAL(109,B2:B100) 筛选后求和",
        "exampleResult": "仅统计可见行",
        "relatedFormulas": [
          {
            "name": "SUM",
            "relation": "扩展版",
            "desc": "SUBTOTAL 支持多种聚合函数"
          },
          {
            "name": "AGGREGATE",
            "relation": "扩展版",
            "desc": "AGGREGATE 支持更多函数和忽略错误"
          }
        ],
        "animation": {
          "formula": "=SUBTOTAL(109, B2:B10)",
          "steps": [
            "读取 function_num 109",
            "109=SUM（忽略隐藏行）",
            "读取区域 B2:B10",
            "自动跳过筛选隐藏的行",
            "返回可见行的总和"
          ],
          "result": "仅汇总可见行的数据",
          "highlight": [
            "SUBTOTAL",
            "109",
            "隐藏行",
            "筛选"
          ]
        }
      },
      {
        "name": "ABS",
        "syntax": "=ABS(number)",
        "params": "number：要取绝对值的数字",
        "notes": "返回数字的绝对值。ABS(-5)=5。常用于计算偏差、误差和距离。",
        "example": "=ABS(A2-B2) 计算两数之差",
        "exampleResult": "正数差值",
        "relatedFormulas": [
          {
            "name": "SQRT",
            "relation": "互补函数",
            "desc": "SQRT 计算平方根，ABS 取绝对值"
          },
          {
            "name": "SIGN",
            "relation": "组合使用",
            "desc": "SIGN 返回数值的符号"
          }
        ],
        "animation": {
          "formula": "=ABS(-5)",
          "steps": [
            "读取数值 -5",
            "判断正负号",
            "取绝对值",
            "去掉负号",
            "返回 5"
          ],
          "result": "5",
          "highlight": [
            "ABS",
            "绝对值",
            "负号",
            "正数"
          ]
        }
      },
      {
        "name": "SQRT",
        "syntax": "=SQRT(number)",
        "params": "number：必须 >= 0",
        "notes": "返回正平方根。SQRT(16)=4。负数会返回 #NUM! 错误。",
        "example": "=SQRT(A2) 计算边长",
        "exampleResult": "4",
        "relatedFormulas": [
          {
            "name": "POWER",
            "relation": "扩展版",
            "desc": "POWER 可计算任意次幂"
          },
          {
            "name": "ABS",
            "relation": "互补函数",
            "desc": "ABS 取绝对值，SQRT 开平方根"
          }
        ],
        "animation": {
          "formula": "=SQRT(144)",
          "steps": [
            "读取数值 144",
            "计算平方根",
            "寻找 x 使得 x²=144",
            "x=12",
            "返回 12"
          ],
          "result": "12",
          "highlight": [
            "SQRT",
            "平方根",
            "开方",
            "幂"
          ]
        }
      },
      {
        "name": "RAND / RANDBETWEEN",
        "syntax": "=RAND() / =RANDBETWEEN(bottom, top)",
        "params": "RAND 无参数，返回 0~1 之间随机小数；RANDBETWEEN 返回指定范围的随机整数",
        "notes": "每次工作表重算都会刷新。如需固定结果，复制后粘贴为值。",
        "example": "=RANDBETWEEN(1,100)",
        "exampleResult": "1~100 随机整数",
        "relatedFormulas": [
          {
            "name": "RANDBETWEEN",
            "relation": "组合使用",
            "desc": "RANDBETWEEN 生成指定范围的随机整数"
          },
          {
            "name": "ROUND",
            "relation": "组合使用",
            "desc": "ROUND 可控制随机数精度"
          }
        ],
        "animation": {
          "formula": "=RANDBETWEEN(1, 100)",
          "steps": [
            "读取最小值 1",
            "读取最大值 100",
            "生成随机整数",
            "范围 [1, 100]",
            "每次重算刷新结果"
          ],
          "result": "1到100之间的随机整数",
          "highlight": [
            "RANDBETWEEN",
            "随机",
            "范围",
            "刷新"
          ]
        }
      },
      {
        "name": "SUMPRODUCT",
        "syntax": "=SUMPRODUCT(array1, [array2], ...)",
        "params": "array：数组或区域，各数组尺寸必须相同",
        "notes": "先逐元素相乘再求和。也可用于多条件计数和求和，替代 SUMIFS。",
        "example": "=SUMPRODUCT((B2:B6=\"销售部\")*(C2:C6>150000))",
        "exampleResult": "满足条件的个数",
        "relatedFormulas": [
          {
            "name": "SUMIFS",
            "relation": "替代方案",
            "desc": "SUMPRODUCT 可实现多条件求和"
          },
          {
            "name": "数组公式",
            "relation": "组合使用",
            "desc": "SUMPRODUCT 天然支持数组运算"
          }
        ],
        "animation": {
          "formula": "=SUMPRODUCT(B2:B6, C2:C6)",
          "steps": [
            "读取两个区域",
            "逐行相乘：B2*C2, B3*C3...",
            "汇总所有乘积",
            "支持多条件筛选",
            "天然支持数组运算"
          ],
          "result": "逐行乘积之和",
          "highlight": [
            "SUMPRODUCT",
            "数组",
            "逐行",
            "乘积"
          ]
        }
      }
    ]
  },
  {
    "id": "date-time",
    "title": "日期和时间函数",
    "chapter": "第 3 章",
    "description": "覆盖 Excel 日期系统、日期构造、日期拆分、工作日计算、月份边界、时间提取与格式转换。",
    "formula": "=NETWORKDAYS(B2,C2)",
    "goal": "计算项目开始日期到结束日期之间的工作日天数。",
    "result": "23",
    "explanation": "NETWORKDAYS 会排除周六、周日，也可以扩展节假日参数，适合排期、考勤和工期计算。",
    "steps": [
      "读取开始日期",
      "读取结束日期",
      "排除周末",
      "返回工作日数量"
    ],
    "sheet": [
      {
        "A": "项目",
        "B": "开始日期",
        "C": "结束日期"
      },
      {
        "A": "上线准备",
        "B": "2026/6/1",
        "C": "2026/7/1"
      }
    ],
    "references": [
      "日期系统",
      "日期构造",
      "日期拆分",
      "工作日",
      "周数",
      "日期文本转换"
    ],
    "functions": [
      "TODAY",
      "NOW",
      "DATE",
      "TIME",
      "YEAR",
      "MONTH",
      "DAY",
      "HOUR",
      "MINUTE",
      "SECOND",
      "WEEKDAY",
      "WEEKNUM",
      "DATEVALUE",
      "TIMEVALUE",
      "EDATE",
      "EOMONTH",
      "WORKDAY",
      "NETWORKDAYS",
      "DAYS",
      "YEARFRAC",
      "DATEDIF"
    ],
    "funcDetails": [
      {
        "name": "TODAY / NOW",
        "syntax": "=TODAY() / =NOW()",
        "params": "无参数",
        "notes": "TODAY 返回当前日期，NOW 返回当前日期+时间。每次打开或重算工作表时自动刷新。",
        "example": "=TODAY() → 2026/6/24",
        "exampleResult": "当前日期",
        "relatedFormulas": [
          {
            "name": "DATE",
            "relation": "组合使用",
            "desc": "DATE 可构造特定日期"
          },
          {
            "name": "YEAR / MONTH / DAY",
            "relation": "组合使用",
            "desc": "从日期中提取年月日"
          }
        ],
        "animation": {
          "formula": "=TODAY()",
          "steps": [
            "调用 TODAY 函数",
            "获取系统当前日期",
            "返回日期值",
            "每次打开文件自动刷新",
            "无参数，直接调用"
          ],
          "result": "2026/6/25（当前日期）",
          "highlight": [
            "TODAY",
            "当前日期",
            "自动刷新",
            "系统"
          ]
        }
      },
      {
        "name": "DATE",
        "syntax": "=DATE(year, month, day)",
        "params": "year：年份数字；month：月份数字（可溢出）；day：天数",
        "notes": "month 和 day 允许溢出。DATE(2026,13,1)=2027/1/1。常用于动态构造日期。",
        "example": "=DATE(2026,6,24)",
        "exampleResult": "2026/6/24",
        "relatedFormulas": [
          {
            "name": "TODAY / NOW",
            "relation": "组合使用",
            "desc": "TODAY 获取当前日期"
          },
          {
            "name": "YEAR / MONTH / DAY",
            "relation": "互补函数",
            "desc": "DATE 构造日期，这些函数拆分日期"
          }
        ],
        "animation": {
          "formula": "=DATE(2026, 6, 25)",
          "steps": [
            "读取年 2026",
            "读取月 6",
            "读取日 25",
            "构造日期值",
            "返回 2026/6/25"
          ],
          "result": "2026/6/25",
          "highlight": [
            "DATE",
            "年",
            "月",
            "日"
          ]
        }
      },
      {
        "name": "YEAR / MONTH / DAY",
        "syntax": "=YEAR(date) / =MONTH(date) / =DAY(date)",
        "params": "date：日期值或引用",
        "notes": "从日期中提取年、月、日三个组成部分。返回值为整数。",
        "example": "=YEAR(A2) 提取年份",
        "exampleResult": "2026",
        "relatedFormulas": [
          {
            "name": "DATE",
            "relation": "互补函数",
            "desc": "DATE 构造日期，这些函数提取日期部分"
          },
          {
            "name": "DATEDIF",
            "relation": "组合使用",
            "desc": "DATEDIF 计算日期差"
          }
        ],
        "animation": {
          "formula": "=YEAR(A2)",
          "steps": [
            "读取日期值",
            "提取年份部分",
            "返回四位年份数字",
            "MONTH 提取月份",
            "DAY 提取天数"
          ],
          "result": "2026",
          "highlight": [
            "YEAR",
            "提取",
            "年份",
            "日期"
          ]
        }
      },
      {
        "name": "DATEDIF",
        "syntax": "=DATEDIF(start_date, end_date, unit)",
        "params": "start_date：开始日期；end_date：结束日期；unit：\"Y\"/\"M\"/\"D\"/\"YM\"/\"MD\"",
        "notes": "这是一个\"隐藏函数\"，不在函数提示中出现。unit 为 \"Y\" 算年数，\"M\" 算月数，\"D\" 算天数。",
        "example": "=DATEDIF(A2,B2,\"Y\") 计算工龄",
        "exampleResult": "完整年数",
        "relatedFormulas": [
          {
            "name": "NETWORKDAYS",
            "relation": "替代方案",
            "desc": "NETWORKDAYS 计算工作日数"
          },
          {
            "name": "YEAR / MONTH / DAY",
            "relation": "组合使用",
            "desc": "配合提取函数计算精确差值"
          }
        ],
        "animation": {
          "formula": "=DATEDIF(A2, B2, \"D\")",
          "steps": [
            "读取开始日期",
            "读取结束日期",
            "读取单位 \"D\"",
            "计算日期差",
            "返回天数差"
          ],
          "result": "天数差值",
          "highlight": [
            "DATEDIF",
            "日期差",
            "天",
            "月",
            "年"
          ]
        }
      },
      {
        "name": "NETWORKDAYS",
        "syntax": "=NETWORKDAYS(start_date, end_date, [holidays])",
        "params": "start_date：开始日期；end_date：结束日期；holidays：可选，节假日区域",
        "notes": "自动排除周六日。如需排除特定节假日，传入节假日日期区域。",
        "example": "=NETWORKDAYS(A2,B2)",
        "exampleResult": "工作日天数",
        "relatedFormulas": [
          {
            "name": "WORKDAY",
            "relation": "互补函数",
            "desc": "WORKDAY 计算N个工作日后的日期"
          },
          {
            "name": "DATEDIF",
            "relation": "替代方案",
            "desc": "DATEDIF 计算自然日差"
          }
        ],
        "animation": {
          "formula": "=NETWORKDAYS(A2, B2)",
          "steps": [
            "读取开始日期",
            "读取结束日期",
            "排除所有周末",
            "（可选）排除节假日",
            "返回工作日数"
          ],
          "result": "23 个工作日",
          "highlight": [
            "NETWORKDAYS",
            "工作日",
            "周末",
            "排除"
          ]
        }
      },
      {
        "name": "WORKDAY",
        "syntax": "=WORKDAY(start_date, days, [holidays])",
        "params": "start_date：起始日期；days：工作日天数（正数向后，负数向前）",
        "notes": "与 NETWORKDAYS 互补：一个算天数，一个算日期。",
        "example": "=WORKDAY(A2,10) 从 A2 开始 10 个工作日后的日期",
        "exampleResult": "目标日期",
        "relatedFormulas": [
          {
            "name": "NETWORKDAYS",
            "relation": "互补函数",
            "desc": "NETWORKDAYS 计算工作日数"
          },
          {
            "name": "EDATE",
            "relation": "替代方案",
            "desc": "EDATE 按月偏移日期"
          }
        ],
        "animation": {
          "formula": "=WORKDAY(A2, 10)",
          "steps": [
            "读取开始日期",
            "读取工作日数 10",
            "跳过周末",
            "向后推算10个工作日",
            "返回目标日期"
          ],
          "result": "10个工作日后的日期",
          "highlight": [
            "WORKDAY",
            "推算",
            "工作日",
            "跳过周末"
          ]
        }
      },
      {
        "name": "EOMONTH",
        "syntax": "=EOMONTH(start_date, months)",
        "params": "start_date：基准日期；months：向前(负)或向后(正)的月数",
        "notes": "返回某月最后一天。months=0 返回当月月末。常用于计算账期、结算日。",
        "example": "=EOMONTH(A2,0) 当月最后一天",
        "exampleResult": "月末日期",
        "relatedFormulas": [
          {
            "name": "EDATE",
            "relation": "互补函数",
            "desc": "EDATE 偏移到同日，EOMONTH 到月末"
          },
          {
            "name": "DATE",
            "relation": "组合使用",
            "desc": "DATE 可手动构造月末日期"
          }
        ],
        "animation": {
          "formula": "=EOMONTH(A2, 0)",
          "steps": [
            "读取日期",
            "读取偏移月数 0",
            "定位当月最后一天",
            "返回月末日期",
            "偏移1则返回下月月末"
          ],
          "result": "2026/6/30",
          "highlight": [
            "EOMONTH",
            "月末",
            "最后一天",
            "偏移"
          ]
        }
      },
      {
        "name": "EDATE",
        "syntax": "=EDATE(start_date, months)",
        "params": "start_date：基准日期；months：偏移月数",
        "notes": "返回偏移后的同日日期。常用于到期日、续费日计算。",
        "example": "=EDATE(A2,3) 三个月后的同日",
        "exampleResult": "2026/9/24",
        "relatedFormulas": [
          {
            "name": "EOMONTH",
            "relation": "互补函数",
            "desc": "EOMONTH 偏移到月末"
          },
          {
            "name": "DATE",
            "relation": "替代方案",
            "desc": "DATE 手动加减月份"
          }
        ],
        "animation": {
          "formula": "=EDATE(A2, 3)",
          "steps": [
            "读取日期",
            "读取月偏移量 3",
            "加3个月",
            "返回新日期",
            "自动处理跨年"
          ],
          "result": "3个月后的日期",
          "highlight": [
            "EDATE",
            "月份",
            "偏移",
            "跨年"
          ]
        }
      },
      {
        "name": "WEEKDAY",
        "syntax": "=WEEKDAY(date, [return_type])",
        "params": "date：日期；return_type：1(周日=1) 2(周一=1) 3(周一=0)",
        "notes": "返回星期几的数字。中国习惯用 return_type=2（周一=1，周日=7）。",
        "example": "=WEEKDAY(A2,2)",
        "exampleResult": "1~7（周一~周日）",
        "relatedFormulas": [
          {
            "name": "NETWORKDAYS",
            "relation": "组合使用",
            "desc": "判断工作日需要 WEEKDAY 辅助"
          },
          {
            "name": "DATE",
            "relation": "组合使用",
            "desc": "构造日期后判断星期几"
          }
        ],
        "animation": {
          "formula": "=WEEKDAY(A2, 2)",
          "steps": [
            "读取日期",
            "读取返回类型 2",
            "计算星期几",
            "类型2：周一=1，周日=7",
            "返回数字"
          ],
          "result": "1-7（代表周一到周日）",
          "highlight": [
            "WEEKDAY",
            "星期",
            "工作日",
            "类型"
          ]
        }
      }
    ]
  },
  {
    "id": "logical",
    "title": "逻辑函数",
    "chapter": "第 4 章",
    "description": "覆盖 TRUE/FALSE、AND/OR/XOR、IF、IFERROR 与错误分流，是构建判断规则和容错公式的核心。",
    "formula": "=IF(AND(B2>=80,C2=\"完成\"),\"合格\",\"复核\")",
    "goal": "同时判断分数和任务状态，返回考核结果。",
    "result": "合格",
    "explanation": "AND 会把多个条件合并为一个逻辑结果，IF 再根据逻辑结果返回不同文本。",
    "steps": [
      "判断分数是否达标",
      "判断任务是否完成",
      "AND 合并条件",
      "IF 返回结果"
    ],
    "sheet": [
      {
        "A": "员工",
        "B": "分数",
        "C": "状态"
      },
      {
        "A": "张三",
        "B": 86,
        "C": "完成"
      },
      {
        "A": "李四",
        "B": 76,
        "C": "完成"
      }
    ],
    "references": [
      "逻辑值",
      "条件判断",
      "多条件组合",
      "错误处理"
    ],
    "functions": [
      "TRUE",
      "FALSE",
      "AND",
      "OR",
      "XOR",
      "IF",
      "IFNA",
      "IFERROR",
      "NOT",
      "SWITCH",
      "IFS"
    ],
    "funcDetails": [
      {
        "name": "IF",
        "syntax": "=IF(logical_test, value_if_true, [value_if_false])",
        "params": "logical_test：条件表达式；value_if_true：条件为真时返回的值；value_if_false：条件为假时返回的值",
        "notes": "可嵌套最多 64 层。但嵌套过深不易维护，建议用 IFS 或 SWITCH 替代。",
        "example": "=IF(A2>=60,\"及格\",\"不及格\")",
        "exampleResult": "根据分数返回等级",
        "relatedFormulas": [
          {
            "name": "IFS",
            "relation": "扩展版",
            "desc": "IFS 支持多条件判断，无需嵌套"
          },
          {
            "name": "IFERROR",
            "relation": "互补函数",
            "desc": "IFERROR 专门处理错误"
          },
          {
            "name": "AND / OR",
            "relation": "组合使用",
            "desc": "AND/OR 组合多个条件"
          }
        ],
        "animation": {
          "formula": "=IF(B2>=80, \"合格\", \"不合格\")",
          "steps": [
            "读取条件 B2>=80",
            "判断真假",
            "TRUE → 返回\"合格\"",
            "FALSE → 返回\"不合格\"",
            "条件决定分支"
          ],
          "result": "根据条件返回不同结果",
          "highlight": [
            "IF",
            "条件",
            "TRUE",
            "FALSE",
            "分支"
          ]
        }
      },
      {
        "name": "AND / OR",
        "syntax": "=AND(logical1, [logical2], ...)",
        "params": "logical：逻辑表达式或条件。AND 全部为真才返回 TRUE；OR 任一为真即返回 TRUE",
        "notes": "最多 255 个参数。常与 IF 嵌套使用。AND 用于\"同时满足\"，OR 用于\"满足其一\"。",
        "example": "=IF(AND(A2>=60,B2>=60),\"双科及格\",\"需补考\")",
        "exampleResult": "多条件判断",
        "relatedFormulas": [
          {
            "name": "IF",
            "relation": "组合使用",
            "desc": "AND/OR 常作为 IF 的条件参数"
          },
          {
            "name": "NOT",
            "relation": "互补函数",
            "desc": "NOT 取反逻辑条件"
          }
        ],
        "animation": {
          "formula": "=AND(B2>=80, C2=\"完成\")",
          "steps": [
            "读取条件1：B2>=80",
            "读取条件2：C2=\"完成\"",
            "AND：全部为TRUE才返回TRUE",
            "OR：任一为TRUE即返回TRUE",
            "常与IF配合使用"
          ],
          "result": "TRUE 或 FALSE",
          "highlight": [
            "AND",
            "OR",
            "全部",
            "任一",
            "TRUE"
          ]
        }
      },
      {
        "name": "IFERROR",
        "syntax": "=IFERROR(value, value_if_error)",
        "params": "value：可能出错的公式或值；value_if_error：出错时返回的替代值",
        "notes": "捕获所有错误类型（#N/A、#VALUE!、#DIV/0! 等）。比 IF(ISERROR()) 更简洁。",
        "example": "=IFERROR(VLOOKUP(A2,B:C,2,0),\"未找到\")",
        "exampleResult": "容错查找",
        "relatedFormulas": [
          {
            "name": "IFNA",
            "relation": "简化版",
            "desc": "IFNA 只处理 #N/A 错误"
          },
          {
            "name": "ISERROR",
            "relation": "组合使用",
            "desc": "ISERROR 检测错误类型"
          }
        ],
        "animation": {
          "formula": "=IFERROR(A2/B2, \"计算错误\")",
          "steps": [
            "先计算 A2/B2",
            "检测是否出错",
            "无错 → 返回计算结果",
            "有错 → 返回\"计算错误\"",
            "优雅处理错误值"
          ],
          "result": "错误时显示友好提示",
          "highlight": [
            "IFERROR",
            "错误",
            "捕获",
            "友好"
          ]
        }
      },
      {
        "name": "IFNA",
        "syntax": "=IFNA(value, value_if_na)",
        "params": "value：可能返回 #N/A 的公式；value_if_na：#N/A 时的替代值",
        "notes": "只捕获 #N/A 错误，其他错误仍会显示。比 IFERROR 更精确，适合 VLOOKUP/INDEX-MATCH 场景。",
        "example": "=IFNA(VLOOKUP(A2,B:C,2,0),\"\")",
        "exampleResult": "找不到时显示空白",
        "relatedFormulas": [
          {
            "name": "IFERROR",
            "relation": "扩展版",
            "desc": "IFERROR 处理所有错误类型"
          },
          {
            "name": "ISNA",
            "relation": "组合使用",
            "desc": "ISNA 检测 #N/A 错误"
          }
        ],
        "animation": {
          "formula": "=IFNA(VLOOKUP(...), \"未找到\")",
          "steps": [
            "先计算 VLOOKUP",
            "检测是否为 #N/A",
            "不是 #N/A → 返回查找结果",
            "是 #N/A → 返回\"未找到\"",
            "只处理 #N/A 错误"
          ],
          "result": "未找到时显示默认值",
          "highlight": [
            "IFNA",
            "#N/A",
            "查找",
            "默认值"
          ]
        }
      },
      {
        "name": "IFS",
        "syntax": "=IFS(logical_test1, value1, [logical_test2, value2], ...)",
        "params": "成对的条件+结果，最多 127 对",
        "notes": "Excel 2016+ 新增。替代多层嵌套 IF。条件按顺序判断，第一个为真即返回对应值。",
        "example": "=IFS(A2>=90,\"优秀\",A2>=80,\"良好\",A2>=60,\"及格\",TRUE,\"不及格\")",
        "exampleResult": "多等级判断",
        "relatedFormulas": [
          {
            "name": "IF",
            "relation": "简化版",
            "desc": "IF 需要嵌套实现多条件"
          },
          {
            "name": "AND / OR",
            "relation": "组合使用",
            "desc": "IFS 中可配合 AND/OR"
          }
        ],
        "animation": {
          "formula": "=IFS(B2>=90,\"A\",B2>=80,\"B\",B2>=60,\"C\")",
          "steps": [
            "判断 B2>=90",
            "TRUE → 返回\"A\"",
            "FALSE → 判断 B2>=80",
            "TRUE → 返回\"B\"",
            "无需嵌套IF"
          ],
          "result": "根据分数返回等级",
          "highlight": [
            "IFS",
            "多条件",
            "无需嵌套",
            "等级"
          ]
        }
      },
      {
        "name": "NOT",
        "syntax": "=NOT(logical)",
        "params": "logical：逻辑值或表达式",
        "notes": "取反。NOT(TRUE)=FALSE。常用于反转条件。",
        "example": "=IF(NOT(A2=\"\"),\"有内容\",\"为空\")",
        "exampleResult": "条件取反",
        "relatedFormulas": [
          {
            "name": "AND / OR",
            "relation": "互补函数",
            "desc": "NOT 取反，AND/OR 组合条件"
          },
          {
            "name": "IF",
            "relation": "组合使用",
            "desc": "NOT 常与 IF 配合反转判断"
          }
        ],
        "animation": {
          "formula": "=NOT(A2=\"已完成\")",
          "steps": [
            "读取条件 A2=\"已完成\"",
            "取反逻辑",
            "TRUE → FALSE",
            "FALSE → TRUE",
            "常与IF配合反转判断"
          ],
          "result": "逻辑取反",
          "highlight": [
            "NOT",
            "取反",
            "反转",
            "逻辑"
          ]
        }
      }
    ]
  },
  {
    "id": "text",
    "title": "文本函数",
    "chapter": "第 5 章",
    "description": "覆盖字符编码、文本提取、连接、格式转换、查找替换、清洗和比较等文本处理任务。",
    "formula": "=LEFT(A2,FIND(\"-\",A2)-1)",
    "goal": "从\"部门-姓名\"格式中提取部门名称。",
    "result": "销售部",
    "explanation": "FIND 找到分隔符位置，LEFT 根据位置从左侧提取字符。组合函数是文本清洗的常见方法。",
    "steps": [
      "查找\"-\"的位置",
      "位置减 1 得到长度",
      "从左侧截取",
      "返回部门名称"
    ],
    "sheet": [
      {
        "A": "原始文本",
        "B": "提取结果"
      },
      {
        "A": "销售部-张三",
        "B": "待提取"
      },
      {
        "A": "技术部-王五",
        "B": "待提取"
      },
      {
        "A": "财务部-赵六",
        "B": "待提取"
      }
    ],
    "references": [
      "字符编码",
      "提取文本",
      "合并文本",
      "转换格式",
      "查找替换",
      "文本清洗"
    ],
    "functions": [
      "CHAR",
      "CODE",
      "LEFT",
      "RIGHT",
      "MID",
      "LEN",
      "LENB",
      "CONCATENATE",
      "CONCAT",
      "TEXTJOIN",
      "TEXT",
      "VALUE",
      "FIXED",
      "EXACT",
      "FIND",
      "SEARCH",
      "REPLACE",
      "SUBSTITUTE",
      "TRIM",
      "CLEAN",
      "LOWER",
      "UPPER",
      "PROPER",
      "REPT"
    ],
    "funcDetails": [
      {
        "name": "LEFT / RIGHT / MID",
        "syntax": "=LEFT(text, [num_chars]) / =MID(text, start_num, num_chars)",
        "params": "text：源文本；num_chars：提取字符数；start_num：起始位置（MID 专用，从 1 开始）",
        "notes": "LEFT 从左取，RIGHT 从右取，MID 从中间取。中文字符算 1 个字符。",
        "example": "=LEFT(\"销售部-张三\",FIND(\"-\",A2)-1)",
        "exampleResult": "销售部",
        "relatedFormulas": [
          {
            "name": "LEN / LENB",
            "relation": "组合使用",
            "desc": "LEN 获取长度后用 LEFT/MID 截取"
          },
          {
            "name": "FIND / SEARCH",
            "relation": "组合使用",
            "desc": "FIND 定位后用 MID 截取子串"
          },
          {
            "name": "SUBSTITUTE",
            "relation": "互补函数",
            "desc": "SUBSTITUTE 替换而非截取"
          }
        ],
        "animation": {
          "formula": "=LEFT(A2, 3)",
          "steps": [
            "读取文本 A2",
            "读取字符数 3",
            "从左侧截取3个字符",
            "RIGHT 从右侧截取",
            "MID 从中间截取"
          ],
          "result": "左侧前3个字符",
          "highlight": [
            "LEFT",
            "RIGHT",
            "MID",
            "截取",
            "字符"
          ]
        }
      },
      {
        "name": "LEN / LENB",
        "syntax": "=LEN(text) / =LENB(text)",
        "params": "text：要计算长度的文本",
        "notes": "LEN 按字符计数（中文=1），LENB 按字节计数（中文=2）。可用来判断全角半角混合。",
        "example": "=LEN(A2) 计算字符数",
        "exampleResult": "字符总数",
        "relatedFormulas": [
          {
            "name": "LEFT / RIGHT / MID",
            "relation": "组合使用",
            "desc": "LEN 确定长度后截取文本"
          },
          {
            "name": "TRIM",
            "relation": "组合使用",
            "desc": "TRIM 清理后 LEN 计算有效长度"
          }
        ],
        "animation": {
          "formula": "=LEN(A2)",
          "steps": [
            "读取文本",
            "计算字符数",
            "LEN 计算字符数",
            "LENB 计算字节数",
            "中文字符占2字节"
          ],
          "result": "文本长度",
          "highlight": [
            "LEN",
            "长度",
            "字符",
            "字节"
          ]
        }
      },
      {
        "name": "FIND / SEARCH",
        "syntax": "=FIND(find_text, within_text, [start_num])",
        "params": "find_text：要查找的文本；within_text：在哪里找；start_num：起始位置",
        "notes": "FIND 区分大小写，SEARCH 不区分。SEARCH 支持通配符 * ?。找不到返回 #VALUE!。",
        "example": "=FIND(\"-\",A2) 找分隔符位置",
        "exampleResult": "位置编号",
        "relatedFormulas": [
          {
            "name": "LEFT / RIGHT / MID",
            "relation": "组合使用",
            "desc": "FIND 定位后截取子串"
          },
          {
            "name": "SUBSTITUTE",
            "relation": "互补函数",
            "desc": "FIND 查找位置，SUBSTITUTE 替换内容"
          }
        ],
        "animation": {
          "formula": "=FIND(\"-\", A2)",
          "steps": [
            "读取要查找的文本 \"-\"",
            "读取被搜索文本 A2",
            "从左向右搜索",
            "返回找到的位置编号",
            "FIND 区分大小写，SEARCH 不区分"
          ],
          "result": "分隔符所在位置",
          "highlight": [
            "FIND",
            "位置",
            "搜索",
            "区分大小写"
          ]
        }
      },
      {
        "name": "SUBSTITUTE",
        "syntax": "=SUBSTITUTE(text, old_text, new_text, [instance_num])",
        "params": "text：源文本；old_text：被替换文本；new_text：新文本；instance_num：替换第几个（省略则全部替换）",
        "notes": "按文本内容替换。REPLACE 按位置替换。SUBSTITUTE 更灵活，常用于删除特定字符。",
        "example": "=SUBSTITUTE(A2,\" \",\"\") 删除所有空格",
        "exampleResult": "清洗后的文本",
        "relatedFormulas": [
          {
            "name": "REPLACE",
            "relation": "替代方案",
            "desc": "REPLACE 按位置替换，SUBSTITUTE 按内容替换"
          },
          {
            "name": "FIND / SEARCH",
            "relation": "组合使用",
            "desc": "FIND 定位后用 REPLACE 替换"
          }
        ],
        "animation": {
          "formula": "=SUBSTITUTE(A2, \"旧\", \"新\")",
          "steps": [
            "读取原文本",
            "读取旧文本",
            "读取新文本",
            "替换所有匹配项",
            "可选第4参数指定替换第几个"
          ],
          "result": "替换后的文本",
          "highlight": [
            "SUBSTITUTE",
            "替换",
            "旧",
            "新"
          ]
        }
      },
      {
        "name": "TEXT",
        "syntax": "=TEXT(value, format_text)",
        "params": "value：数值或日期；format_text：格式代码",
        "notes": "将数值转换为指定格式的文本。日期常用 \"yyyy-mm-dd\"，数字常用 \"#,##0.00\"。",
        "example": "=TEXT(A2,\"yyyy年m月d日\")",
        "exampleResult": "2026年6月24日",
        "relatedFormulas": [
          {
            "name": "VALUE",
            "relation": "互补函数",
            "desc": "VALUE 将文本转为数值，TEXT 将数值转为文本"
          },
          {
            "name": "CONCATENATE / CONCAT / TEXTJOIN",
            "relation": "组合使用",
            "desc": "TEXT 格式化后拼接显示"
          }
        ],
        "animation": {
          "formula": "=TEXT(A2, \"#,##0.00\")",
          "steps": [
            "读取数值",
            "读取格式代码",
            "按格式转换",
            "添加千分符和小数",
            "返回格式化文本"
          ],
          "result": "\"1,234.56\"",
          "highlight": [
            "TEXT",
            "格式",
            "千分符",
            "小数"
          ]
        }
      },
      {
        "name": "CONCATENATE / CONCAT / TEXTJOIN",
        "syntax": "=TEXTJOIN(delimiter, ignore_empty, text1, ...)",
        "params": "delimiter：分隔符；ignore_empty：是否忽略空值；text：文本或区域",
        "notes": "TEXTJOIN 是最强文本合并函数，支持分隔符和忽略空值。CONCAT/CONCATENATE 不支持分隔符。",
        "example": "=TEXTJOIN(\",\",TRUE,A2:A10)",
        "exampleResult": "用逗号连接所有姓名",
        "relatedFormulas": [
          {
            "name": "TEXT",
            "relation": "组合使用",
            "desc": "TEXT 格式化数值后拼接"
          },
          {
            "name": "LEFT / RIGHT / MID",
            "relation": "组合使用",
            "desc": "截取子串后拼接"
          }
        ],
        "animation": {
          "formula": "=TEXTJOIN(\",\", TRUE, A2:A5)",
          "steps": [
            "读取分隔符 \",\"",
            "读取忽略空值 TRUE",
            "读取区域 A2:A5",
            "用逗号连接所有值",
            "跳过空单元格"
          ],
          "result": "\"值1,值2,值3,值4\"",
          "highlight": [
            "TEXTJOIN",
            "连接",
            "分隔符",
            "合并"
          ]
        }
      },
      {
        "name": "TRIM",
        "syntax": "=TRIM(text)",
        "params": "text：要清洗的文本",
        "notes": "删除单词之间的多余空格，保留单个空格。不会删除不换行空格。",
        "example": "=TRIM(\"  你好   世界  \")",
        "exampleResult": "\"你好 世界\"",
        "relatedFormulas": [
          {
            "name": "SUBSTITUTE",
            "relation": "组合使用",
            "desc": "SUBSTITUTE 可替换多余空格"
          },
          {
            "name": "LEN / LENB",
            "relation": "组合使用",
            "desc": "TRIM 后用 LEN 计算有效长度"
          }
        ],
        "animation": {
          "formula": "=TRIM(A2)",
          "steps": [
            "读取文本",
            "删除开头空格",
            "删除结尾空格",
            "合并中间多余空格",
            "保留单个空格"
          ],
          "result": "清理后的文本",
          "highlight": [
            "TRIM",
            "空格",
            "清理",
            "多余"
          ]
        }
      },
      {
        "name": "VALUE",
        "syntax": "=VALUE(text)",
        "params": "text：表示数字的文本",
        "notes": "将文本型数字转换为数值。如 VALUE(\"123\")=123。常用于从系统导出的数据清洗。",
        "example": "=VALUE(A2) 将文本数字转为数值",
        "exampleResult": "数值类型",
        "relatedFormulas": [
          {
            "name": "TEXT",
            "relation": "互补函数",
            "desc": "TEXT 将数值转文本，VALUE 反向操作"
          },
          {
            "name": "NUMBERVALUE",
            "relation": "扩展版",
            "desc": "NUMBERVALUE 支持指定小数和千分符"
          }
        ],
        "animation": {
          "formula": "=VALUE(\"123.45\")",
          "steps": [
            "读取文本 \"123.45\"",
            "识别数字格式",
            "转换为数值类型",
            "返回 123.45",
            "可用于数学计算"
          ],
          "result": "数值 123.45",
          "highlight": [
            "VALUE",
            "转换",
            "文本",
            "数值"
          ]
        }
      }
    ]
  },
  {
    "id": "lookup-reference",
    "title": "查找和引用函数",
    "chapter": "第 6 章",
    "description": "覆盖 LOOKUP、VLOOKUP、HLOOKUP、INDEX、MATCH、OFFSET、INDIRECT、地址和行列引用。",
    "formula": "=INDEX(C2:C6,MATCH(E2,A2:A6,0))",
    "goal": "使用 INDEX + MATCH 根据姓名查找绩效分数。",
    "result": "91",
    "explanation": "MATCH 负责找到目标所在位置，INDEX 根据位置返回对应区域的值，比单独 VLOOKUP 更灵活。",
    "steps": [
      "MATCH 找到姓名位置",
      "INDEX 接收位置编号",
      "进入 C 列区域",
      "返回分数"
    ],
    "sheet": [
      {
        "A": "员工",
        "B": "部门",
        "C": "分数",
        "E": "查找"
      },
      {
        "A": "张三",
        "B": "销售部",
        "C": 86,
        "E": "王五"
      },
      {
        "A": "李四",
        "B": "销售部",
        "C": 72,
        "E": ""
      },
      {
        "A": "王五",
        "B": "技术部",
        "C": 91,
        "E": ""
      },
      {
        "A": "赵六",
        "B": "财务部",
        "C": 78,
        "E": ""
      },
      {
        "A": "孙七",
        "B": "人事部",
        "C": 88,
        "E": ""
      }
    ],
    "references": [
      "查找",
      "引用",
      "动态区域",
      "行列定位",
      "超链接"
    ],
    "functions": [
      "CHOOSE",
      "LOOKUP",
      "VLOOKUP",
      "HLOOKUP",
      "INDEX",
      "MATCH",
      "OFFSET",
      "INDIRECT",
      "ADDRESS",
      "ROW",
      "ROWS",
      "COLUMN",
      "COLUMNS",
      "TRANSPOSE",
      "HYPERLINK",
      "XLOOKUP"
    ],
    "funcDetails": [
      {
        "name": "VLOOKUP",
        "syntax": "=VLOOKUP(lookup_value, table_array, col_index_num, [range_lookup])",
        "params": "lookup_value：查找值；table_array：查找区域；col_index_num：返回第几列；range_lookup：FALSE=精确匹配",
        "notes": "查找区域第一列必须是查找列。返回列号从左到右计数。查找方向固定向右，不能向左查找。",
        "example": "=VLOOKUP(E2,A2:C6,3,FALSE)",
        "exampleResult": "91",
        "relatedFormulas": [
          {
            "name": "XLOOKUP",
            "relation": "扩展版",
            "desc": "XLOOKUP 支持向左查找和多条件"
          },
          {
            "name": "INDEX",
            "relation": "组合使用",
            "desc": "INDEX+MATCH 组合是 VLOOKUP 的替代"
          },
          {
            "name": "MATCH",
            "relation": "组合使用",
            "desc": "MATCH 查找位置配合 INDEX 取值"
          }
        ],
        "animation": {
          "formula": "=VLOOKUP(E2, A2:C6, 3, 0)",
          "steps": [
            "读取查找值 E2",
            "在 A 列中垂直搜索",
            "找到匹配行",
            "向右移动到第3列",
            "返回该列的值"
          ],
          "result": "找到对应的成绩",
          "highlight": [
            "VLOOKUP",
            "垂直",
            "查找",
            "列",
            "匹配"
          ]
        }
      },
      {
        "name": "INDEX",
        "syntax": "=INDEX(array, row_num, [column_num])",
        "params": "array：数据区域；row_num：行号；column_num：列号（可选）",
        "notes": "根据行列号返回区域中的值。与 MATCH 组合可替代 VLOOKUP，支持向左查找。",
        "example": "=INDEX(C2:C6,3) 返回 C 列第 3 个值",
        "exampleResult": "91",
        "relatedFormulas": [
          {
            "name": "MATCH",
            "relation": "组合使用",
            "desc": "INDEX+MATCH 是经典查找组合"
          },
          {
            "name": "VLOOKUP",
            "relation": "替代方案",
            "desc": "INDEX+MATCH 可替代 VLOOKUP"
          },
          {
            "name": "XLOOKUP",
            "relation": "替代方案",
            "desc": "XLOOKUP 整合了 INDEX+MATCH"
          }
        ],
        "animation": {
          "formula": "=INDEX(C2:C6, 3)",
          "steps": [
            "读取区域 C2:C6",
            "读取行号 3",
            "定位到第3行",
            "返回该位置的值",
            "可配合 MATCH 动态定位"
          ],
          "result": "区域中第3行的值",
          "highlight": [
            "INDEX",
            "索引",
            "行号",
            "定位"
          ]
        }
      },
      {
        "name": "MATCH",
        "syntax": "=MATCH(lookup_value, lookup_array, [match_type])",
        "params": "lookup_value：查找值；lookup_array：查找区域（单行/列）；match_type：0=精确，1=小于，-1=大于",
        "notes": "返回位置编号（非值本身）。常与 INDEX 配对使用。精确匹配用 0。",
        "example": "=MATCH(\"王五\",A2:A6,0)",
        "exampleResult": "3",
        "relatedFormulas": [
          {
            "name": "INDEX",
            "relation": "组合使用",
            "desc": "INDEX+MATCH 是经典查找组合"
          },
          {
            "name": "XLOOKUP",
            "relation": "替代方案",
            "desc": "XLOOKUP 整合了 MATCH 的查找功能"
          }
        ],
        "animation": {
          "formula": "=MATCH(E2, A2:A6, 0)",
          "steps": [
            "读取查找值 E2",
            "读取查找区域 A2:A6",
            "精确匹配模式 0",
            "返回匹配位置编号",
            "配合 INDEX 取值"
          ],
          "result": "匹配项在第几行",
          "highlight": [
            "MATCH",
            "匹配",
            "位置",
            "精确"
          ]
        }
      },
      {
        "name": "XLOOKUP",
        "syntax": "=XLOOKUP(lookup_value, lookup_array, return_array, [if_not_found], ...)",
        "params": "lookup_value：查找值；lookup_array：查找区域；return_array：返回区域；if_not_found：找不到时的值",
        "notes": "Excel 365 新函数。比 VLOOKUP 更强大：可向左查找、支持多条件、有默认值参数。",
        "example": "=XLOOKUP(E2,A2:A6,C2:C6,\"未找到\")",
        "exampleResult": "91",
        "relatedFormulas": [
          {
            "name": "VLOOKUP",
            "relation": "替代方案",
            "desc": "XLOOKUP 功能更强大，支持向左查找"
          },
          {
            "name": "INDEX",
            "relation": "组合使用",
            "desc": "XLOOKUP 内部类似 INDEX+MATCH"
          }
        ],
        "animation": {
          "formula": "=XLOOKUP(E2, A2:A6, C2:C6)",
          "steps": [
            "读取查找值 E2",
            "读取查找区域",
            "读取返回区域",
            "自动匹配并返回",
            "支持向左查找"
          ],
          "result": "查找结果（支持向左）",
          "highlight": [
            "XLOOKUP",
            "查找",
            "返回",
            "向左",
            "默认值"
          ]
        }
      },
      {
        "name": "OFFSET",
        "syntax": "=OFFSET(reference, rows, cols, [height], [width])",
        "params": "reference：基准单元格；rows/cols：偏移行/列数；height/width：返回区域大小",
        "notes": "返回偏移后的区域引用。常用于动态图表数据源。是易失性函数，会频繁重算。",
        "example": "=OFFSET(A1,2,1) 返回 B3 的值",
        "exampleResult": "偏移后的值",
        "relatedFormulas": [
          {
            "name": "INDEX",
            "relation": "替代方案",
            "desc": "INDEX 返回值而非引用，更稳定"
          },
          {
            "name": "INDIRECT",
            "relation": "组合使用",
            "desc": "INDIRECT 构造地址，OFFSET 偏移引用"
          }
        ],
        "animation": {
          "formula": "=OFFSET(A1, 2, 1)",
          "steps": [
            "读取基准单元格 A1",
            "向下偏移2行",
            "向右偏移1列",
            "返回新位置的引用",
            "是易失性函数"
          ],
          "result": "B3 单元格的引用",
          "highlight": [
            "OFFSET",
            "偏移",
            "基准",
            "行",
            "列"
          ]
        }
      },
      {
        "name": "INDIRECT",
        "syntax": "=INDIRECT(ref_text, [a1])",
        "params": "ref_text：文本形式的单元格地址或名称；a1：TRUE=A1样式，FALSE=R1C1样式",
        "notes": "将文本转为单元格引用。可动态拼接地址。是易失性函数。",
        "example": "=INDIRECT(\"A\"&B1) 动态引用",
        "exampleResult": "动态单元格值",
        "relatedFormulas": [
          {
            "name": "OFFSET",
            "relation": "互补函数",
            "desc": "OFFSET 偏移引用，INDIRECT 构造引用"
          },
          {
            "name": "ADDRESS",
            "relation": "组合使用",
            "desc": "ADDRESS 生成地址文本供 INDIRECT 使用"
          }
        ],
        "animation": {
          "formula": "=INDIRECT(\"A\"&B1)",
          "steps": [
            "读取地址文本 \"A\"&B1",
            "拼接得到 \"A5\"",
            "将文本转为单元格引用",
            "返回 A5 的值",
            "是易失性函数"
          ],
          "result": "动态引用的单元格值",
          "highlight": [
            "INDIRECT",
            "文本",
            "引用",
            "动态",
            "拼接"
          ]
        }
      },
      {
        "name": "ROW / COLUMN",
        "syntax": "=ROW([reference]) / =COLUMN([reference])",
        "params": "reference：可选，单元格或区域引用",
        "notes": "返回行号或列号。无参数时返回当前单元格的行/列号。常用于生成序列和条件公式。",
        "example": "=ROW(A5) → 5",
        "exampleResult": "行号/列号",
        "relatedFormulas": [
          {
            "name": "INDEX",
            "relation": "组合使用",
            "desc": "ROW/COLUMN 提供行号列号给 INDEX"
          },
          {
            "name": "OFFSET",
            "relation": "组合使用",
            "desc": "ROW/COLUMN 指定偏移量"
          }
        ],
        "animation": {
          "formula": "=ROW()",
          "steps": [
            "获取当前行号",
            "COLUMN 获取当前列号",
            "ROW(A5) 返回 5",
            "常用于生成序列号",
            "配合 INDIRECT 构造动态引用"
          ],
          "result": "当前行号",
          "highlight": [
            "ROW",
            "行号",
            "COLUMN",
            "列号",
            "序列"
          ]
        }
      }
    ]
  },
  {
    "id": "information",
    "title": "信息函数",
    "chapter": "第 7 章",
    "description": "覆盖单元格信息、错误类型、数据类型判断和公式检测，用于公式诊断和动态提示。",
    "formula": "=IF(ISERROR(B2/C2),\"请检查数据\",B2/C2)",
    "goal": "在除数为 0 时返回友好提示，而不是错误值。",
    "result": "请检查数据",
    "explanation": "ISERROR 判断公式是否产生错误，IF 根据判断结果决定显示提示还是显示计算结果。",
    "steps": [
      "执行 B2/C2",
      "检测是否为错误",
      "错误时走提示分支",
      "返回友好文本"
    ],
    "sheet": [
      {
        "A": "项目",
        "B": "收入",
        "C": "人数"
      },
      {
        "A": "A 组",
        "B": 12000,
        "C": 0
      },
      {
        "A": "B 组",
        "B": 18000,
        "C": 6
      }
    ],
    "references": [
      "单元格信息",
      "错误类型",
      "数据类型",
      "公式检测"
    ],
    "functions": [
      "CELL",
      "INFO",
      "ERROR.TYPE",
      "ISBLANK",
      "ISNUMBER",
      "ISTEXT",
      "ISLOGICAL",
      "ISFORMULA",
      "ISEVEN",
      "ISODD",
      "ISNA",
      "ISERR",
      "ISERROR",
      "N",
      "TYPE",
      "NA"
    ],
    "funcDetails": [
      {
        "name": "ISBLANK",
        "syntax": "=ISBLANK(value)",
        "params": "value：要检查的单元格或值",
        "notes": "判断单元格是否为空白。注意：含公式的空字符串 \"\" 不算空白。",
        "example": "=IF(ISBLANK(A2),\"请填写\",\"已填写\")",
        "exampleResult": "空白检测",
        "relatedFormulas": [
          {
            "name": "ISNUMBER / ISTEXT",
            "relation": "互补函数",
            "desc": "不同类型检测函数"
          },
          {
            "name": "IF",
            "relation": "组合使用",
            "desc": "ISBLANK 常与 IF 配合判断空值"
          }
        ],
        "animation": {
          "formula": "=ISBLANK(A2)",
          "steps": [
            "读取单元格 A2",
            "检测是否为空",
            "空 → TRUE",
            "非空 → FALSE",
            "常与IF配合处理空值"
          ],
          "result": "TRUE 或 FALSE",
          "highlight": [
            "ISBLANK",
            "空值",
            "检测",
            "空白"
          ]
        }
      },
      {
        "name": "ISNUMBER / ISTEXT",
        "syntax": "=ISNUMBER(value) / =ISTEXT(value)",
        "params": "value：要检查的值",
        "notes": "判断数据类型。ISNUMBER 检查是否为数字，ISTEXT 检查是否为文本。",
        "example": "=ISNUMBER(A2) 判断是否为数字",
        "exampleResult": "TRUE/FALSE",
        "relatedFormulas": [
          {
            "name": "ISBLANK",
            "relation": "互补函数",
            "desc": "不同类型检测函数"
          },
          {
            "name": "VALUE",
            "relation": "组合使用",
            "desc": "ISNUMBER 检测转换结果"
          }
        ],
        "animation": {
          "formula": "=ISNUMBER(A2)",
          "steps": [
            "读取单元格 A2",
            "检测数据类型",
            "是数字 → TRUE",
            "是文本 → FALSE",
            "ISTEXT 检测是否为文本"
          ],
          "result": "TRUE 或 FALSE",
          "highlight": [
            "ISNUMBER",
            "类型",
            "数字",
            "文本"
          ]
        }
      },
      {
        "name": "ISERROR / ISERR / ISNA",
        "syntax": "=ISERROR(value)",
        "params": "value：要检查的值或公式",
        "notes": "ISERROR 捕获所有错误；ISERR 不捕获 #N/A；ISNA 只捕获 #N/A。",
        "example": "=ISERROR(A2/B2)",
        "exampleResult": "TRUE/FALSE",
        "relatedFormulas": [
          {
            "name": "IFERROR",
            "relation": "组合使用",
            "desc": "IFERROR 简化了 ISERROR+IF 的写法"
          },
          {
            "name": "ERROR.TYPE",
            "relation": "组合使用",
            "desc": "ERROR.TYPE 返回错误类型编号"
          }
        ],
        "animation": {
          "formula": "=ISERROR(A2)",
          "steps": [
            "读取单元格 A2",
            "检测是否为错误值",
            "任何错误 → TRUE",
            "正常值 → FALSE",
            "ISERR 排除 #N/A，ISNA 只检测 #N/A"
          ],
          "result": "TRUE 或 FALSE",
          "highlight": [
            "ISERROR",
            "错误",
            "检测",
            "#N/A"
          ]
        }
      },
      {
        "name": "CELL",
        "syntax": "=CELL(info_type, [reference])",
        "params": "info_type：信息类型（如 \"address\"、\"format\"、\"type\" 等）；reference：单元格",
        "notes": "返回单元格的格式、位置或内容信息。\"type\" 返回 \"b\"=空白、\"l\"=文本常量、\"v\"=其他值。",
        "example": "=CELL(\"address\",A2)",
        "exampleResult": "\"$A$2\"",
        "relatedFormulas": [
          {
            "name": "ISBLANK",
            "relation": "组合使用",
            "desc": "CELL 获取单元格信息后判断"
          },
          {
            "name": "ADDRESS",
            "relation": "组合使用",
            "desc": "CELL 获取地址信息"
          }
        ],
        "animation": {
          "formula": "=CELL(\"address\", A2)",
          "steps": [
            "读取信息类型 \"address\"",
            "读取目标单元格 A2",
            "返回单元格地址",
            "支持多种信息类型",
            "常用于动态获取单元格信息"
          ],
          "result": "\"$A$2\"",
          "highlight": [
            "CELL",
            "信息",
            "地址",
            "类型"
          ]
        }
      },
      {
        "name": "ERROR.TYPE",
        "syntax": "=ERROR.TYPE(error_val)",
        "params": "error_val：错误值",
        "notes": "返回对应错误类型的数字：1=#NULL!, 2=#DIV/0!, 3=#VALUE!, 7=#N/A 等。无错误返回 #N/A。",
        "example": "=ERROR.TYPE(A2/B2)",
        "exampleResult": "2（#DIV/0!）",
        "relatedFormulas": [
          {
            "name": "ISERROR / ISERR / ISNA",
            "relation": "组合使用",
            "desc": "先检测错误再用 ERROR.TYPE 分类"
          },
          {
            "name": "IFERROR",
            "relation": "替代方案",
            "desc": "IFERROR 直接处理错误更简洁"
          }
        ],
        "animation": {
          "formula": "=ERROR.TYPE(A2)",
          "steps": [
            "读取单元格 A2",
            "检测错误类型",
            "#NULL! → 1, #DIV/0! → 2",
            "#VALUE! → 3, #REF! → 4",
            "无错误返回 #N/A"
          ],
          "result": "错误类型编号",
          "highlight": [
            "ERROR.TYPE",
            "错误类型",
            "编号",
            "分类"
          ]
        }
      }
    ]
  },
  {
    "id": "statistics",
    "title": "统计函数",
    "chapter": "第 8 章",
    "description": "覆盖数量统计、平均值、极值、排名、频率、分布、相关性和预测分析。",
    "formula": "=COUNTIF(C2:C8,\">=90\")",
    "goal": "统计分数大于等于 90 的人数。",
    "result": "3",
    "explanation": "COUNTIF 接收一个统计区域和一个条件，返回符合条件的单元格数量。",
    "steps": [
      "读取 C2:C8",
      "应用条件 >=90",
      "逐个判断",
      "返回符合数量"
    ],
    "sheet": [
      {
        "A": "员工",
        "C": "分数"
      },
      {
        "A": "张三",
        "C": 86
      },
      {
        "A": "李四",
        "C": 92
      },
      {
        "A": "王五",
        "C": 91
      },
      {
        "A": "赵六",
        "C": 78
      },
      {
        "A": "孙七",
        "C": 95
      },
      {
        "A": "周八",
        "C": 83
      },
      {
        "A": "吴九",
        "C": 69
      }
    ],
    "references": [
      "数量与频率",
      "平均值",
      "排名",
      "分布",
      "预测",
      "相关性"
    ],
    "functions": [
      "COUNT",
      "COUNTA",
      "COUNTBLANK",
      "COUNTIF",
      "COUNTIFS",
      "AVERAGE",
      "AVERAGEIF",
      "AVERAGEIFS",
      "MAX",
      "MIN",
      "LARGE",
      "SMALL",
      "RANK",
      "PERCENTRANK",
      "QUARTILE",
      "MEDIAN",
      "MODE",
      "FREQUENCY",
      "STDEV",
      "VAR",
      "CORREL",
      "FORECAST",
      "TREND",
      "LINEST"
    ],
    "funcDetails": [
      {
        "name": "COUNT / COUNTA / COUNTBLANK",
        "syntax": "=COUNT(value1, ...) / =COUNTA(value1, ...)",
        "params": "value：数值或区域",
        "notes": "COUNT 只统计数字；COUNTA 统计非空值（含文本）；COUNTBLANK 统计空白单元格。",
        "example": "=COUNTA(A2:A100) 统计已填写行数",
        "exampleResult": "非空单元格数",
        "relatedFormulas": [
          {
            "name": "COUNTIF / COUNTIFS",
            "relation": "扩展版",
            "desc": "COUNTIF 支持条件计数"
          },
          {
            "name": "SUMPRODUCT",
            "relation": "替代方案",
            "desc": "SUMPRODUCT 可实现复杂计数"
          }
        ],
        "animation": {
          "formula": "=COUNTA(A2:A10)",
          "steps": [
            "读取区域 A2:A10",
            "COUNT 只计数字",
            "COUNTA 计所有非空",
            "COUNTBLANK 计空单元格",
            "返回计数结果"
          ],
          "result": "非空单元格数量",
          "highlight": [
            "COUNT",
            "COUNTA",
            "计数",
            "空白"
          ]
        }
      },
      {
        "name": "COUNTIF / COUNTIFS",
        "syntax": "=COUNTIF(range, criteria) / =COUNTIFS(criteria_range1, criteria1, ...)",
        "params": "range：统计区域；criteria：条件（支持通配符）",
        "notes": "COUNTIF 单条件，COUNTIFS 多条件。条件中用引号包裹文本和比较运算符。",
        "example": "=COUNTIFS(B2:B10,\"销售部\",C2:C10,\">80\")",
        "exampleResult": "多条件计数",
        "relatedFormulas": [
          {
            "name": "SUMIF / SUMIFS",
            "relation": "互补函数",
            "desc": "SUMIF 按条件求和，COUNTIF 按条件计数"
          },
          {
            "name": "COUNT / COUNTA",
            "relation": "简化版",
            "desc": "COUNT 无条件计数"
          }
        ],
        "animation": {
          "formula": "=COUNTIF(C2:C8, \">=90\")",
          "steps": [
            "读取条件区域",
            "读取条件 \">=90\"",
            "逐行判断是否满足",
            "统计满足条件的行数",
            "COUNTIFS 支持多条件"
          ],
          "result": "满足条件的个数",
          "highlight": [
            "COUNTIF",
            "条件",
            "计数",
            "满足"
          ]
        }
      },
      {
        "name": "AVERAGE / AVERAGEIF",
        "syntax": "=AVERAGE(number1, ...) / =AVERAGEIF(range, criteria, [average_range])",
        "params": "同 SUMIF 结构",
        "notes": "AVERAGEIF 条件平均。注意：空白单元格不参与计算。",
        "example": "=AVERAGEIF(B2:B10,\"销售部\",C2:C10)",
        "exampleResult": "销售部平均分",
        "relatedFormulas": [
          {
            "name": "SUMIF",
            "relation": "互补函数",
            "desc": "SUMIF 求和，AVERAGEIF 求平均"
          },
          {
            "name": "COUNTIF",
            "relation": "组合使用",
            "desc": "AVERAGEIF 内部类似 SUMIF/COUNTIF"
          }
        ],
        "animation": {
          "formula": "=AVERAGE(B2:B10)",
          "steps": [
            "读取区域 B2:B10",
            "求所有数值之和",
            "除以数值个数",
            "忽略文本和空值",
            "AVERAGEIF 支持条件平均"
          ],
          "result": "算术平均值",
          "highlight": [
            "AVERAGE",
            "平均",
            "求和",
            "个数"
          ]
        }
      },
      {
        "name": "MAX / MIN / LARGE / SMALL",
        "syntax": "=LARGE(array, k) / =SMALL(array, k)",
        "params": "array：数据区域；k：第几大/小",
        "notes": "LARGE(A1:A10,1)=MAX，LARGE(A1:A10,2)=第二大值。",
        "example": "=LARGE(C2:C8,2) 第二高分",
        "exampleResult": "92",
        "relatedFormulas": [
          {
            "name": "RANK",
            "relation": "组合使用",
            "desc": "RANK 排名依赖 MAX/MIN 比较"
          },
          {
            "name": "COUNTIF",
            "relation": "组合使用",
            "desc": "配合 COUNTIF 统计超过某值的个数"
          }
        ],
        "animation": {
          "formula": "=LARGE(B2:B10, 2)",
          "steps": [
            "读取区域 B2:B10",
            "读取名次 k=2",
            "排序所有数值",
            "返回第2大的值",
            "LARGE 取第k大，SMALL 取第k小"
          ],
          "result": "第2大的值",
          "highlight": [
            "LARGE",
            "最大",
            "最小",
            "排名"
          ]
        }
      },
      {
        "name": "RANK",
        "syntax": "=RANK(number, ref, [order])",
        "params": "number：要排名的数值；ref：数据区域；order：0=降序，1=升序",
        "notes": "返回数值在区域中的排名。相同值排名相同。Excel 2010+ 推荐用 RANK.EQ。",
        "example": "=RANK(C2,$C$2:$C$8)",
        "exampleResult": "排名数字",
        "relatedFormulas": [
          {
            "name": "MAX / MIN / LARGE / SMALL",
            "relation": "组合使用",
            "desc": "RANK 排名基于值的大小比较"
          },
          {
            "name": "COUNTIF",
            "relation": "替代方案",
            "desc": "COUNTIF 可统计排名"
          }
        ],
        "animation": {
          "formula": "=RANK(A2, A2:A10)",
          "steps": [
            "读取数值 A2",
            "读取排名区域",
            "比较所有数值大小",
            "计算名次",
            "返回排名数字"
          ],
          "result": "在区域中的排名",
          "highlight": [
            "RANK",
            "排名",
            "大小",
            "名次"
          ]
        }
      },
      {
        "name": "MEDIAN",
        "syntax": "=MEDIAN(number1, ...)",
        "params": "数值或区域",
        "notes": "返回中位数。奇数个取中间值，偶数个取中间两个的平均。不受极端值影响。",
        "example": "=MEDIAN(C2:C8)",
        "exampleResult": "中位数",
        "relatedFormulas": [
          {
            "name": "AVERAGE / AVERAGEIF",
            "relation": "互补函数",
            "desc": "AVERAGE 算平均，MEDIAN 算中位数"
          },
          {
            "name": "QUARTILE",
            "relation": "扩展版",
            "desc": "QUARTILE 计算四分位数"
          }
        ],
        "animation": {
          "formula": "=MEDIAN(B2:B10)",
          "steps": [
            "读取区域 B2:B10",
            "排序所有数值",
            "取中间值",
            "奇数个取中间，偶数取平均",
            "不受极端值影响"
          ],
          "result": "中位数",
          "highlight": [
            "MEDIAN",
            "中位数",
            "中间",
            "排序"
          ]
        }
      },
      {
        "name": "FREQUENCY",
        "syntax": "=FREQUENCY(data_array, bins_array)",
        "params": "data_array：数据区域；bins_array：分组区间",
        "notes": "数组公式，需选中结果区域后按 Ctrl+Shift+Enter。返回各区间的频次分布。",
        "example": "=FREQUENCY(C2:C8,{60,70,80,90})",
        "exampleResult": "各区间人数",
        "relatedFormulas": [
          {
            "name": "COUNTIF",
            "relation": "替代方案",
            "desc": "COUNTIF 可实现简单频率统计"
          },
          {
            "name": "MEDIAN",
            "relation": "组合使用",
            "desc": "FREQUENCY 构建分布后计算中位数"
          }
        ],
        "animation": {
          "formula": "=FREQUENCY(A2:A20, B2:B5)",
          "steps": [
            "读取数据区域",
            "读取分组区间",
            "统计各区间的频次",
            "返回数组结果",
            "需选中区域后 Ctrl+Shift+Enter"
          ],
          "result": "各区间频次数组",
          "highlight": [
            "FREQUENCY",
            "频次",
            "区间",
            "分组"
          ]
        }
      }
    ]
  },
  {
    "id": "financial",
    "title": "财务函数",
    "chapter": "第 9 章",
    "description": "覆盖贷款、利率、现金流、折旧、投资收益和证券计算，适合预算、融资和投资分析。",
    "formula": "=PMT(B2/12,C2,-A2)",
    "goal": "计算等额本息贷款的月供金额。",
    "result": "1887.12",
    "explanation": "PMT 根据利率、期数和本金计算每期支付额，利率需要与期数单位保持一致。",
    "steps": [
      "月利率换算",
      "读取还款期数",
      "读取贷款本金",
      "返回月供"
    ],
    "sheet": [
      {
        "A": "贷款本金",
        "B": "年利率",
        "C": "月数"
      },
      {
        "A": 200000,
        "B": "5%",
        "C": 120
      }
    ],
    "references": [
      "贷款",
      "利率",
      "现金流",
      "折旧",
      "投资收益"
    ],
    "functions": [
      "PMT",
      "IPMT",
      "PPMT",
      "RATE",
      "NPER",
      "PV",
      "FV",
      "NPV",
      "IRR",
      "MIRR",
      "XNPV",
      "XIRR",
      "SLN",
      "DB",
      "DDB",
      "SYD",
      "PRICE",
      "YIELD",
      "ACCRINT"
    ],
    "funcDetails": [
      {
        "name": "PMT",
        "syntax": "=PMT(rate, nper, pv, [fv], [type])",
        "params": "rate：每期利率；nper：总期数；pv：现值（本金）；fv：终值（可选）；type：0=期末还款，1=期初还款",
        "notes": "利率和期数单位必须一致。年利率 5% 按月还则 rate=5%/12。pv 用负数表示支出。",
        "example": "=PMT(5%/12,120,-200000)",
        "exampleResult": "1887.12",
        "relatedFormulas": [
          {
            "name": "IPMT / PPMT",
            "relation": "组合使用",
            "desc": "IPMT+PPMT 分解 PMT 的利息和本金"
          },
          {
            "name": "PV / FV",
            "relation": "组合使用",
            "desc": "PV/FV 计算现值终值，PMT 计算每期还款"
          }
        ],
        "animation": {
          "formula": "=PMT(B2/12, C2, -A2)",
          "steps": [
            "读取年利率并转月利率",
            "读取还款期数",
            "读取贷款本金（负数）",
            "计算每期还款额",
            "包含本金和利息"
          ],
          "result": "每期还款额",
          "highlight": [
            "PMT",
            "还款",
            "利率",
            "期数",
            "本金"
          ]
        }
      },
      {
        "name": "IPMT / PPMT",
        "syntax": "=IPMT(rate, per, nper, pv)",
        "params": "per：当前期数；其余同 PMT",
        "notes": "IPMT 返回某期利息，PPMT 返回某期本金。IPMT+PPMT=PMT。",
        "example": "=IPMT(5%/12,1,120,-200000) 首月利息",
        "exampleResult": "833.33",
        "relatedFormulas": [
          {
            "name": "PMT",
            "relation": "组合使用",
            "desc": "IPMT+PPMT 之和等于 PMT"
          },
          {
            "name": "PV / FV",
            "relation": "组合使用",
            "desc": "基于现值计算各期利息和本金"
          }
        ],
        "animation": {
          "formula": "=IPMT(B2/12, 1, C2, -A2)",
          "steps": [
            "读取月利率",
            "读取当前期数",
            "读取总期数",
            "读取本金",
            "IPMT 返回利息部分，PPMT 返回本金部分"
          ],
          "result": "第1期利息额",
          "highlight": [
            "IPMT",
            "PPMT",
            "利息",
            "本金",
            "分期"
          ]
        }
      },
      {
        "name": "PV / FV",
        "syntax": "=PV(rate, nper, pmt, [fv], [type])",
        "params": "rate：利率；nper：期数；pmt：每期支付额",
        "notes": "PV 计算现值（现在值多少钱），FV 计算终值（未来值多少钱）。",
        "example": "=PV(5%/12,120,-1887)",
        "exampleResult": "约 200000",
        "relatedFormulas": [
          {
            "name": "PMT",
            "relation": "组合使用",
            "desc": "PMT 基于现值计算每期还款"
          },
          {
            "name": "IRR / NPV",
            "relation": "组合使用",
            "desc": "NPV 计算现值，FV 计算终值"
          }
        ],
        "animation": {
          "formula": "=PV(B2, C2, -A2)",
          "steps": [
            "读取每期利率",
            "读取期数",
            "读取每期支付额",
            "计算现值",
            "FV 计算终值"
          ],
          "result": "现值金额",
          "highlight": [
            "PV",
            "FV",
            "现值",
            "终值",
            "利率"
          ]
        }
      },
      {
        "name": "IRR / NPV",
        "syntax": "=IRR(values, [guess]) / =NPV(rate, value1, ...)",
        "params": "values：现金流序列（IRR）；rate：折现率（NPV）",
        "notes": "IRR 求内部收益率（使 NPV=0 的利率）；NPV 计算净现值。投资分析核心函数。",
        "example": "=IRR({-100000,30000,35000,40000,45000})",
        "exampleResult": "内部收益率",
        "relatedFormulas": [
          {
            "name": "PV / FV",
            "relation": "组合使用",
            "desc": "NPV 类似 PV 的多期版本"
          },
          {
            "name": "PMT",
            "relation": "组合使用",
            "desc": "NPV 评估投资，PMT 计算还款"
          }
        ],
        "animation": {
          "formula": "=NPV(B2, C2:C6)",
          "steps": [
            "读取折现率",
            "读取各期现金流",
            "逐期折现到现值",
            "汇总所有现值",
            "IRR 求使 NPV=0 的收益率"
          ],
          "result": "净现值",
          "highlight": [
            "NPV",
            "IRR",
            "折现",
            "现金流",
            "收益率"
          ]
        }
      },
      {
        "name": "SLN / DDB",
        "syntax": "=SLN(cost, salvage, life) / =DDB(cost, salvage, life, period, [factor])",
        "params": "cost：原值；salvage：残值；life：使用年限；period：当前期数",
        "notes": "SLN 直线法折旧（每年相同）；DDB 双倍余额递减法（前期折旧多）。",
        "example": "=SLN(100000,10000,5)",
        "exampleResult": "每年 18000",
        "relatedFormulas": [
          {
            "name": "PMT",
            "relation": "互补函数",
            "desc": "PMT 计算还款，SLN/DDB 计算折旧"
          },
          {
            "name": "PV",
            "relation": "组合使用",
            "desc": "PV 计算资产现值用于折旧"
          }
        ],
        "animation": {
          "formula": "=SLN(A2, B2, C2)",
          "steps": [
            "读取资产原值",
            "读取残值",
            "读取使用年限",
            "SLN：直线法折旧",
            "DDB：双倍余额递减法"
          ],
          "result": "每年折旧额",
          "highlight": [
            "SLN",
            "DDB",
            "折旧",
            "直线法",
            "余额递减"
          ]
        }
      }
    ]
  },
  {
    "id": "database",
    "title": "数据库函数",
    "chapter": "第 10 章",
    "description": "覆盖按条件对表格记录进行求和、计数、平均、最大最小值和字段抽取。",
    "formula": "=DSUM(A1:D8,\"销售额\",F1:G2)",
    "goal": "按条件区域汇总数据库表中的销售额。",
    "result": "86000",
    "explanation": "数据库函数由数据库区域、字段名和条件区域组成，适合结构化清单式数据统计。",
    "steps": [
      "读取数据库区域",
      "定位字段\"销售额\"",
      "应用条件区域",
      "汇总匹配记录"
    ],
    "sheet": [
      {
        "A": "地区",
        "B": "品类",
        "C": "销售额",
        "F": "地区",
        "G": "品类"
      },
      {
        "A": "华东",
        "B": "办公",
        "C": 38000,
        "F": "华东",
        "G": "办公"
      },
      {
        "A": "华东",
        "B": "办公",
        "C": 48000,
        "F": "",
        "G": ""
      },
      {
        "A": "华南",
        "B": "设备",
        "C": 52000,
        "F": "",
        "G": ""
      }
    ],
    "references": [
      "数据库区域",
      "字段",
      "条件区域",
      "记录统计"
    ],
    "functions": [
      "DSUM",
      "DCOUNT",
      "DCOUNTA",
      "DAVERAGE",
      "DMAX",
      "DMIN",
      "DGET",
      "DPRODUCT",
      "DSTDEV",
      "DVAR"
    ],
    "funcDetails": [
      {
        "name": "DSUM",
        "syntax": "=DSUM(database, field, criteria)",
        "params": "database：包含标题行的数据区域；field：字段名或列号；criteria：条件区域（含标题行）",
        "notes": "条件区域必须包含与数据库相同的列标题。多行条件为 OR 关系，同行多列为 AND 关系。",
        "example": "=DSUM(A1:D8,\"销售额\",F1:G2)",
        "exampleResult": "86000",
        "relatedFormulas": [
          {
            "name": "DCOUNT / DAVERAGE",
            "relation": "互补函数",
            "desc": "不同数据库聚合函数"
          },
          {
            "name": "SUMIF",
            "relation": "替代方案",
            "desc": "SUMIF 可实现类似条件求和"
          }
        ],
        "animation": {
          "formula": "=DSUM(A1:D8, \"销售额\", F1:G2)",
          "steps": [
            "读取数据库区域 A1:D8",
            "定位字段\"销售额\"",
            "读取条件区域 F1:G2",
            "筛选满足条件的行",
            "对销售额列求和"
          ],
          "result": "符合条件的销售额合计",
          "highlight": [
            "DSUM",
            "数据库",
            "条件",
            "字段",
            "求和"
          ]
        }
      },
      {
        "name": "DCOUNT / DAVERAGE",
        "syntax": "=DCOUNT(database, field, criteria)",
        "params": "同 DSUM",
        "notes": "DCOUNT 统计满足条件的数值记录数；DAVERAGE 计算满足条件的平均值。",
        "example": "=DAVERAGE(A1:D8,\"销售额\",F1:F2)",
        "exampleResult": "条件平均值",
        "relatedFormulas": [
          {
            "name": "DSUM",
            "relation": "互补函数",
            "desc": "不同数据库聚合函数"
          },
          {
            "name": "COUNTIF / AVERAGEIF",
            "relation": "替代方案",
            "desc": "普通条件函数可替代数据库函数"
          }
        ],
        "animation": {
          "formula": "=DCOUNT(A1:D8, \"年龄\", F1:F2)",
          "steps": [
            "读取数据库区域",
            "定位字段\"年龄\"",
            "读取条件区域",
            "统计满足条件的记录数",
            "DAVERAGE 计算平均值"
          ],
          "result": "符合条件的记录数",
          "highlight": [
            "DCOUNT",
            "DAVERAGE",
            "数据库",
            "计数",
            "平均"
          ]
        }
      },
      {
        "name": "DGET",
        "syntax": "=DGET(database, field, criteria)",
        "params": "同 DSUM",
        "notes": "返回唯一匹配记录的字段值。多条匹配或无匹配会返回错误。适合精确查找。",
        "example": "=DGET(A1:D8,\"销售额\",F1:G2)",
        "exampleResult": "唯一匹配值",
        "relatedFormulas": [
          {
            "name": "VLOOKUP",
            "relation": "替代方案",
            "desc": "VLOOKUP 可实现类似精确查找"
          },
          {
            "name": "DSUM",
            "relation": "互补函数",
            "desc": "DGET 取单值，DSUM 求和"
          }
        ],
        "animation": {
          "formula": "=DGET(A1:D8, \"姓名\", F1:F2)",
          "steps": [
            "读取数据库区域",
            "定位字段\"姓名\"",
            "读取条件区域",
            "精确匹配一条记录",
            "提取该记录的字段值"
          ],
          "result": "符合条件的唯一值",
          "highlight": [
            "DGET",
            "数据库",
            "唯一",
            "提取",
            "精确"
          ]
        }
      }
    ]
  },
  {
    "id": "engineering",
    "title": "工程函数",
    "chapter": "第 11 章",
    "description": "覆盖进制转换、复数、贝塞尔函数、误差函数和单位换算等工程计算。",
    "formula": "=CONVERT(A2,\"m\",\"ft\")",
    "goal": "把米转换为英尺。",
    "result": "32.8084",
    "explanation": "CONVERT 用于不同单位之间的换算，需要提供数值、原单位和目标单位。",
    "steps": [
      "读取数值",
      "识别原单位 m",
      "识别目标单位 ft",
      "返回换算结果"
    ],
    "sheet": [
      {
        "A": "长度",
        "B": "原单位",
        "C": "目标单位"
      },
      {
        "A": 10,
        "B": "m",
        "C": "ft"
      }
    ],
    "references": [
      "单位换算",
      "进制转换",
      "复数",
      "工程统计"
    ],
    "functions": [
      "CONVERT",
      "BIN2DEC",
      "DEC2BIN",
      "DEC2HEX",
      "HEX2DEC",
      "OCT2DEC",
      "COMPLEX",
      "IMSUM",
      "IMPRODUCT",
      "IMDIV",
      "IMABS",
      "BESSELJ",
      "ERF",
      "DELTA",
      "GESTEP"
    ],
    "funcDetails": [
      {
        "name": "CONVERT",
        "syntax": "=CONVERT(number, from_unit, to_unit)",
        "params": "number：数值；from_unit：原单位；to_unit：目标单位",
        "notes": "支持长度、重量、温度、时间、压力等数十种单位。单位代码需精确匹配。",
        "example": "=CONVERT(100,\"kg\",\"lbm\")",
        "exampleResult": "220.46",
        "relatedFormulas": [
          {
            "name": "VALUE",
            "relation": "组合使用",
            "desc": "VALUE 转数值，CONVERT 转单位"
          },
          {
            "name": "TEXT",
            "relation": "组合使用",
            "desc": "TEXT 格式化数值后转换单位"
          }
        ],
        "animation": {
          "formula": "=CONVERT(A2, \"m\", \"ft\")",
          "steps": [
            "读取数值",
            "读取原单位 \"m\"",
            "读取目标单位 \"ft\"",
            "查询单位换算系数",
            "返回换算结果"
          ],
          "result": "32.8084 英尺",
          "highlight": [
            "CONVERT",
            "单位",
            "换算",
            "米",
            "英尺"
          ]
        }
      },
      {
        "name": "BIN2DEC / DEC2HEX",
        "syntax": "=BIN2DEC(number) / =DEC2HEX(number, [places])",
        "params": "number：要转换的数值；places：结果位数（可选）",
        "notes": "二进制、十进制、十六进制、八进制互转。注意位数限制。",
        "example": "=DEC2HEX(255)",
        "exampleResult": "\"FF\"",
        "relatedFormulas": [
          {
            "name": "CONVERT",
            "relation": "互补函数",
            "desc": "CONVERT 转度量单位，这些转进制"
          },
          {
            "name": "HEX2DEC",
            "relation": "互补函数",
            "desc": "不同进制间互转"
          }
        ],
        "animation": {
          "formula": "=BIN2DEC(\"1010\")",
          "steps": [
            "读取二进制字符串",
            "逐位解析",
            "转换为十进制",
            "DEC2HEX 转十六进制",
            "支持多种进制互转"
          ],
          "result": "10",
          "highlight": [
            "BIN2DEC",
            "进制",
            "二进制",
            "十进制",
            "十六进制"
          ]
        }
      },
      {
        "name": "DELTA / GESTEP",
        "syntax": "=DELTA(number1, [number2]) / =GESTEP(number, step)",
        "params": "DELTA：比较两数是否相等；GESTEP：判断是否 >= 阈值",
        "notes": "DELTA 返回 1（相等）或 0（不等）。GESTEP 返回 1（>=step）或 0（<step）。",
        "example": "=DELTA(A2,B2) 比较两数",
        "exampleResult": "0 或 1",
        "relatedFormulas": [
          {
            "name": "IF",
            "relation": "替代方案",
            "desc": "IF 可实现类似条件判断"
          },
          {
            "name": "ABS",
            "relation": "组合使用",
            "desc": "DELTA 判断是否相等，ABS 比较差值"
          }
        ],
        "animation": {
          "formula": "=DELTA(A2, B2)",
          "steps": [
            "读取两个数值",
            "比较是否相等",
            "相等 → 返回 1",
            "不等 → 返回 0",
            "GESTEP 判断是否 ≥ 阈值"
          ],
          "result": "1 或 0",
          "highlight": [
            "DELTA",
            "GESTEP",
            "比较",
            "相等",
            "阈值"
          ]
        }
      }
    ]
  },
  {
    "id": "cube-web",
    "title": "多维数据集与 Web 函数",
    "chapter": "第 12 章",
    "description": "覆盖从数据模型、多维数据集或网络接口中提取成员、值、属性和网页数据。",
    "formula": "=WEBSERVICE(A2)",
    "goal": "从指定接口或网页地址读取文本结果。",
    "result": "返回网页文本",
    "explanation": "WEBSERVICE 会向 URL 发出请求并返回文本内容，常与 FILTERXML 等函数组合处理结构化数据。",
    "steps": [
      "读取 URL",
      "发送请求",
      "接收文本",
      "返回结果"
    ],
    "sheet": [
      {
        "A": "URL",
        "B": "说明"
      },
      {
        "A": "https://example.com/api",
        "B": "演示地址"
      }
    ],
    "references": [
      "多维数据集",
      "成员",
      "属性",
      "Web 数据"
    ],
    "functions": [
      "CUBEVALUE",
      "CUBEMEMBER",
      "CUBESET",
      "CUBESETCOUNT",
      "CUBERANKEDMEMBER",
      "CUBEMEMBERPROPERTY",
      "WEBSERVICE",
      "FILTERXML",
      "ENCODEURL"
    ],
    "funcDetails": [
      {
        "name": "WEBSERVICE",
        "syntax": "=WEBSERVICE(url)",
        "params": "url：网页地址或 API 接口",
        "notes": "返回 URL 的文本内容。需要网络连接。返回结果为文本，可用 FILTERXML 解析 XML/JSON。",
        "example": "=WEBSERVICE(\"https://api.example.com/data\")",
        "exampleResult": "API 返回文本",
        "relatedFormulas": [
          {
            "name": "FILTERXML",
            "relation": "组合使用",
            "desc": "WEBSERVICE 获取数据，FILTERXML 解析 XML"
          },
          {
            "name": "ENCODEURL",
            "relation": "组合使用",
            "desc": "ENCODEURL 编码 URL 后请求"
          }
        ],
        "animation": {
          "formula": "=WEBSERVICE(A2)",
          "steps": [
            "读取 URL 地址",
            "发送 HTTP 请求",
            "接收响应文本",
            "返回网页内容",
            "需网络连接"
          ],
          "result": "网页文本内容",
          "highlight": [
            "WEBSERVICE",
            "URL",
            "HTTP",
            "请求",
            "响应"
          ]
        }
      },
      {
        "name": "FILTERXML",
        "syntax": "=FILTERXML(xml, xpath)",
        "params": "xml：XML 文本；xpath：XPath 表达式",
        "notes": "用 XPath 从 XML 中提取数据。可解析 WEBSERVICE 返回的 XML 结构。",
        "example": "=FILTERXML(A2,\"//price\")",
        "exampleResult": "XML 中的 price 值",
        "relatedFormulas": [
          {
            "name": "WEBSERVICE",
            "relation": "组合使用",
            "desc": "WEBSERVICE 获取数据后用 FILTERXML 解析"
          },
          {
            "name": "SUBSTITUTE",
            "relation": "组合使用",
            "desc": "SUBSTITUTE 预处理文本再解析"
          }
        ],
        "animation": {
          "formula": "=FILTERXML(B1, \"//item/title\")",
          "steps": [
            "读取 XML 文本",
            "读取 XPath 表达式",
            "解析 XML 结构",
            "匹配节点路径",
            "返回节点内容"
          ],
          "result": "XML 节点中的文本",
          "highlight": [
            "FILTERXML",
            "XML",
            "XPath",
            "解析",
            "节点"
          ]
        }
      },
      {
        "name": "ENCODEURL",
        "syntax": "=ENCODEURL(text)",
        "params": "text：要编码的文本",
        "notes": "将文本进行 URL 编码。中文会转为 %XX 格式。",
        "example": "=ENCODEURL(\"你好世界\")",
        "exampleResult": "%E4%BD%A0%E5%A5%BD...",
        "relatedFormulas": [
          {
            "name": "WEBSERVICE",
            "relation": "组合使用",
            "desc": "ENCODEURL 编码后传给 WEBSERVICE"
          },
          {
            "name": "SUBSTITUTE",
            "relation": "替代方案",
            "desc": "SUBSTITUTE 可手动编码特殊字符"
          }
        ],
        "animation": {
          "formula": "=ENCODEURL(A2)",
          "steps": [
            "读取 URL 字符串",
            "识别特殊字符",
            "转换为 % 编码",
            "空格 → %20",
            "中文 → %XX%XX 格式"
          ],
          "result": "编码后的 URL",
          "highlight": [
            "ENCODEURL",
            "编码",
            "URL",
            "特殊字符"
          ]
        }
      }
    ]
  },
  {
    "id": "data-validation",
    "title": "在数据有效性中使用公式",
    "chapter": "第 13 章",
    "description": "覆盖用公式限制输入、制作动态下拉列表、校验身份证、日期、重复值和业务规则。",
    "formula": "=COUNTIF($A:$A,A2)=1",
    "goal": "限制 A 列不能录入重复编号。",
    "result": "允许或拒绝输入",
    "explanation": "数据有效性公式需要返回 TRUE 或 FALSE，TRUE 允许输入，FALSE 阻止输入。",
    "steps": [
      "读取当前输入值",
      "统计整列出现次数",
      "判断是否等于 1",
      "决定是否允许输入"
    ],
    "sheet": [
      {
        "A": "员工编号",
        "B": "校验"
      },
      {
        "A": "E001",
        "B": "通过"
      },
      {
        "A": "E002",
        "B": "通过"
      },
      {
        "A": "E001",
        "B": "重复"
      }
    ],
    "references": [
      "输入限制",
      "自定义公式",
      "动态下拉",
      "重复值校验"
    ],
    "functions": [
      "COUNTIF",
      "INDIRECT",
      "OFFSET",
      "MATCH",
      "LEN",
      "ISNUMBER",
      "AND",
      "OR",
      "TODAY"
    ],
    "funcDetails": [
      {
        "name": "重复值校验",
        "syntax": "=COUNTIF($A:$A,A2)=1",
        "params": "在\"数据\"→\"数据验证\"→\"自定义\"中输入",
        "notes": "COUNTIF 统计当前值在整列出现的次数。等于 1 表示首次输入，允许通过。",
        "example": "设置数据验证 → 自定义 → =COUNTIF($A:$A,A1)=1",
        "exampleResult": "重复时阻止输入",
        "relatedFormulas": [
          {
            "name": "COUNTIF",
            "relation": "组合使用",
            "desc": "COUNTIF 统计出现次数判断重复"
          },
          {
            "name": "动态下拉列表",
            "relation": "互补函数",
            "desc": "数据有效性中的不同应用"
          }
        ],
        "animation": {
          "formula": "=COUNTIF($A:$A, A2)=1",
          "steps": [
            "读取当前输入值 A2",
            "COUNTIF 统计整列出现次数",
            "判断次数是否等于 1",
            "=1 → 允许输入",
            ">1 → 拒绝输入"
          ],
          "result": "允许或拒绝输入",
          "highlight": [
            "COUNTIF",
            "重复",
            "校验",
            "数据有效性"
          ]
        }
      },
      {
        "name": "动态下拉列表",
        "syntax": "=INDIRECT(\"列表\"&A1)",
        "params": "在\"数据验证\"→\"序列\"→\"来源\"中输入公式",
        "notes": "根据另一个单元格的值动态切换下拉选项来源。需要预先定义多个名称。",
        "example": "=INDIRECT(\"部门\"&B1) 根据类别切换列表",
        "exampleResult": "动态选项",
        "relatedFormulas": [
          {
            "name": "重复值校验",
            "relation": "互补函数",
            "desc": "数据有效性中的不同应用"
          },
          {
            "name": "OFFSET",
            "relation": "组合使用",
            "desc": "OFFSET 创建动态区域作为列表源"
          }
        ],
        "animation": {
          "formula": "=OFFSET($A$1,0,0,COUNTA($A:$A)-1)",
          "steps": [
            "COUNTA 统计非空行数",
            "OFFSET 创建动态区域",
            "区域随数据增减自动调整",
            "设置为数据有效性来源",
            "下拉列表自动更新"
          ],
          "result": "动态更新的下拉选项",
          "highlight": [
            "OFFSET",
            "动态",
            "下拉",
            "COUNTA",
            "数据有效性"
          ]
        }
      },
      {
        "name": "身份证校验",
        "syntax": "=AND(LEN(A2)=18,ISNUMBER(VALUE(LEFT(A2,17))))",
        "params": "在数据验证自定义公式中使用",
        "notes": "检查长度是否为 18 位，且前 17 位是否为数字。实际校验还需验证校验码。",
        "example": "数据验证 → 自定义 → =AND(LEN(A1)=18,...)",
        "exampleResult": "格式校验",
        "relatedFormulas": [
          {
            "name": "LEN / LENB",
            "relation": "组合使用",
            "desc": "LEN 检查身份证长度"
          },
          {
            "name": "MID",
            "relation": "组合使用",
            "desc": "MID 提取身份证各部分"
          }
        ],
        "animation": {
          "formula": "=IF(LEN(A2)=18, MID(A2,7,8), \"错误\")",
          "steps": [
            "LEN 检查长度是否18位",
            "MID 提取出生日期",
            "检查日期格式是否有效",
            "验证校验位",
            "全部通过则合法"
          ],
          "result": "身份证是否合法",
          "highlight": [
            "LEN",
            "MID",
            "身份证",
            "校验",
            "18位"
          ]
        }
      }
    ]
  },
  {
    "id": "chart-formula",
    "title": "在图表中使用公式",
    "chapter": "第 14 章",
    "description": "覆盖动态图表、辅助列、命名区域、条件高亮和图表数据源联动。",
    "formula": "=OFFSET($B$2,0,0,COUNTA($B:$B)-1,1)",
    "goal": "创建随数据增长自动扩展的动态图表区域。",
    "result": "动态数据源",
    "explanation": "OFFSET 配合 COUNTA 可以返回可变高度区域，再把该区域定义为名称并用于图表数据源。",
    "steps": [
      "统计已有数据行数",
      "从 B2 开始定位",
      "生成动态区域",
      "驱动图表更新"
    ],
    "sheet": [
      {
        "A": "月份",
        "B": "销售额"
      },
      {
        "A": "1月",
        "B": 12000
      },
      {
        "A": "2月",
        "B": 18500
      },
      {
        "A": "3月",
        "B": 16400
      },
      {
        "A": "4月",
        "B": 21200
      }
    ],
    "references": [
      "辅助列",
      "命名区域",
      "动态图表",
      "条件高亮"
    ],
    "functions": [
      "OFFSET",
      "COUNTA",
      "INDEX",
      "MATCH",
      "IF",
      "NA",
      "MAX",
      "MIN",
      "SERIES",
      "名称管理器"
    ],
    "funcDetails": [
      {
        "name": "动态数据源",
        "syntax": "=OFFSET($B$2,0,0,COUNTA($B:$B)-1,1)",
        "params": "在\"公式\"→\"名称管理器\"中定义名称，再用于图表数据源",
        "notes": "COUNTA 统计非空行数，OFFSET 返回等高区域。新增数据后图表自动扩展。",
        "example": "定义名称\"动态数据\"=OFFSET($B$2,0,0,COUNTA($B:$B)-1,1)",
        "exampleResult": "自动扩展区域",
        "relatedFormulas": [
          {
            "name": "OFFSET",
            "relation": "组合使用",
            "desc": "OFFSET 创建动态区域"
          },
          {
            "name": "COUNTA",
            "relation": "组合使用",
            "desc": "COUNTA 统计数据行数确定范围"
          }
        ],
        "animation": {
          "formula": "=OFFSET($B$2,0,0,COUNTA($B:$B)-1,1)",
          "steps": [
            "COUNTA 统计B列数据行数",
            "OFFSET 从B2开始",
            "高度=数据行数，宽度=1",
            "生成动态区域引用",
            "图表数据源自动扩展"
          ],
          "result": "自动扩展的数据区域",
          "highlight": [
            "OFFSET",
            "动态",
            "COUNTA",
            "图表",
            "数据源"
          ]
        }
      },
      {
        "name": "辅助列技巧",
        "syntax": "=IF(A2=MAX($A$2:$A$10),A2,NA())",
        "params": "在图表数据旁添加辅助列",
        "notes": "用 NA() 让不需要显示的数据点在图表中留空。可用于高亮最大值、条件显示等。",
        "example": "辅助列 =IF(A2>=目标值,A2,NA())",
        "exampleResult": "条件高亮",
        "relatedFormulas": [
          {
            "name": "IF",
            "relation": "组合使用",
            "desc": "IF 创建条件辅助列"
          },
          {
            "name": "ROW / COLUMN",
            "relation": "组合使用",
            "desc": "ROW/COLUMN 生成序号辅助列"
          }
        ],
        "animation": {
          "formula": "=IF(B2>100, \"高\", \"低\")",
          "steps": [
            "创建辅助列",
            "用 IF 分类数据",
            "辅助列驱动图表",
            "排序或筛选辅助列",
            "简化复杂公式"
          ],
          "result": "分类后的辅助数据",
          "highlight": [
            "辅助列",
            "IF",
            "分类",
            "图表",
            "简化"
          ]
        }
      },
      {
        "name": "SERIES 函数",
        "syntax": "=SERIES(name, category_labels, values, order)",
        "params": "图表内部使用的函数，可在公式栏中查看和编辑",
        "notes": "每个图表系列都对应一个 SERIES 公式。可在公式栏直接修改引用区域。",
        "example": "在图表中选中系列，查看编辑栏中的 SERIES",
        "exampleResult": "图表系列公式",
        "relatedFormulas": [
          {
            "name": "OFFSET",
            "relation": "组合使用",
            "desc": "OFFSET 动态调整 SERIES 数据范围"
          },
          {
            "name": "NAME",
            "relation": "组合使用",
            "desc": "命名公式简化 SERIES 引用"
          }
        ],
        "animation": {
          "formula": "=SERIES(名称, 分类, 值, 顺序)",
          "steps": [
            "图表自动生成 SERIES",
            "名称：图例名称",
            "分类：X轴标签区域",
            "值：数据区域",
            "可在公式栏编辑"
          ],
          "result": "图表数据系列引用",
          "highlight": [
            "SERIES",
            "图表",
            "名称",
            "分类",
            "数据"
          ]
        }
      }
    ]
  },
  {
    "id": "scenario-lookup",
    "title": "函数使用场景速查",
    "chapter": "第 15 章",
    "description": "按常见工作场景对 Excel 函数进行分类与组合应用。通过场景搜索和筛选，快速找到最适合的函数组合，覆盖日常办公、销售分析、库存管理、人事管理、财务分析、项目管理、数据清洗和报表自动化等 8 大场景。",
    "goal": "根据具体工作场景快速定位并掌握最适合的函数组合，提升实际工作效率。",
    "sheet": [
      {"A": "场景", "B": "常用函数组合", "C": "难度"},
      {"A": "工资计算", "B": "SUM, SUMIF, IF, VLOOKUP", "C": "中级"},
      {"A": "客户分级", "B": "IF, AND, VLOOKUP, COUNTIF", "C": "中级"},
      {"A": "库存预警", "B": "IF, SUMIFS, COUNTIFS, TEXT", "C": "高级"},
      {"A": "合同到期提醒", "B": "DATEDIF, TODAY, IF, TEXT", "C": "初级"},
      {"A": "销售提成", "B": "IF, VLOOKUP, SUMPRODUCT", "C": "中级"},
      {"A": "项目进度", "B": "NETWORKDAYS, IF, COUNTIF", "C": "中级"},
      {"A": "数据去重", "B": "COUNTIF, IF, FILTER", "C": "中级"},
      {"A": "动态报表", "B": "OFFSET, COUNTA, INDEX, MATCH", "C": "高级"}
    ],
    "references": ["日常办公", "销售分析", "库存管理", "人事管理", "财务分析", "项目管理", "数据清洗", "报表自动化"],
    "functions": ["SUMIF", "VLOOKUP", "IF", "COUNTIF", "DATEDIF", "TEXTJOIN", "FILTER", "SUBTOTAL", "SUMPRODUCT", "NETWORKDAYS", "OFFSET", "COUNTA", "INDEX", "MATCH", "TEXT", "TODAY", "AND", "SUMIFS", "COUNTIFS"],
    "funcDetails": [
      {
        "name": "工资计算",
        "scene": "日常办公",
        "syntax": "=SUM(基本工资)+SUMIF(补贴类型,\"餐补\",补贴金额)-SUMIF(扣款项,\"个税\",扣款金额)",
        "params": "SUM 汇总固定项，SUMIF 按条件汇总变动项",
        "notes": "工资表通常包含固定项（基本工资）和变动项（补贴、扣款）。用 SUMIF 可以按补贴类型和扣款项分别汇总。",
        "example": "=SUM(B2:B10)+SUMIF(C2:C10,\"餐补\",D2:D10)-SUMIF(E2:E10,\"个税\",F2:F10)",
        "exampleResult": "12850",
        "relatedFormulas": [
          {"name": "SUMIFS", "relation": "扩展版", "desc": "多条件汇总不同补贴类型"},
          {"name": "IF", "relation": "组合使用", "desc": "判断是否有补贴或扣款"},
          {"name": "VLOOKUP", "relation": "组合使用", "desc": "从员工信息表查找税率和社保基数"}
        ],
        "animation": {
          "formula": "=SUM(B2:B10)+SUMIF(C2:C10,\"餐补\",D2:D10)-SUMIF(E2:E10,\"个税\",F2:F10)",
          "steps": [
            "SUM 汇总基本工资区域 B2:B10",
            "SUMIF 在补贴表中筛选\"餐补\"并汇总金额",
            "SUMIF 在扣款表中筛选\"个税\"并汇总金额",
            "执行加减运算：基本+餐补-个税",
            "返回最终实发工资"
          ],
          "result": "12850",
          "highlight": ["SUM", "SUMIF", "餐补", "个税", "实发工资"]
        }
      },
      {
        "name": "考勤迟到统计",
        "scene": "日常办公",
        "syntax": "=COUNTIF(考勤状态,\"迟到\")",
        "params": "考勤状态区域，条件为\"迟到\"",
        "notes": "每月考勤表中，用 COUNTIF 统计迟到次数。可结合 IF 判断迟到次数是否超过阈值。",
        "example": "=COUNTIF(B2:B31,\"迟到\")",
        "exampleResult": "3",
        "relatedFormulas": [
          {"name": "COUNTIFS", "relation": "扩展版", "desc": "按月份和部门多条件统计迟到"},
          {"name": "IF", "relation": "组合使用", "desc": "判断迟到次数是否超阈值扣款"},
          {"name": "SUMPRODUCT", "relation": "替代方案", "desc": "多条件统计迟到并加权"}
        ],
        "animation": {
          "formula": "=COUNTIF(B2:B31,\"迟到\")",
          "steps": [
            "读取考勤状态区域 B2:B31",
            "逐个检查每个单元格是否为\"迟到\"",
            "每找到一个\"迟到\"计数器+1",
            "遍历完成后返回总计数"
          ],
          "result": "3",
          "highlight": ["COUNTIF", "迟到", "统计"]
        }
      },
      {
        "name": "客户分级",
        "scene": "销售分析",
        "syntax": "=IF(AND(消费金额>50000,购买次数>5),\"VIP\",IF(消费金额>10000,\"普通\",\"新客\"))",
        "params": "多层 IF 嵌套，AND 组合多个条件",
        "notes": "根据消费金额和购买次数自动分级。VIP客户享受更高折扣。",
        "example": "=IF(AND(B2>50000,C2>5),\"VIP\",IF(B2>10000,\"普通\",\"新客\"))",
        "exampleResult": "VIP",
        "relatedFormulas": [
          {"name": "IFS", "relation": "简化版", "desc": "Excel 2016+ 可用 IFS 替代多层嵌套"},
          {"name": "VLOOKUP", "relation": "替代方案", "desc": "建立分级对照表后用 VLOOKUP 查找"},
          {"name": "AND", "relation": "组合使用", "desc": "同时判断消费金额和购买次数"}
        ],
        "animation": {
          "formula": "=IF(AND(B2>50000,C2>5),\"VIP\",IF(B2>10000,\"普通\",\"新客\"))",
          "steps": [
            "检查消费金额 B2 是否大于 50000",
            "检查购买次数 C2 是否大于 5",
            "AND 合并两个条件，同时满足才为真",
            "条件为真返回\"VIP\"，否则进入下一层 IF",
            "第二层判断消费金额是否大于 10000，返回\"普通\"或\"新客\""
          ],
          "result": "VIP",
          "highlight": ["IF", "AND", "VIP", "消费金额", "购买次数"]
        }
      },
      {
        "name": "销售额排名",
        "scene": "销售分析",
        "syntax": "=RANK(销售额, 销售额区域, 0)",
        "params": "要排名的数值，排名区域，0=降序",
        "notes": "对销售人员的月销售额进行排名。0 表示降序（数值越大排名越靠前）。",
        "example": "=RANK(B2,$B$2:$B$20,0)",
        "exampleResult": "3",
        "relatedFormulas": [
          {"name": "RANK.EQ", "relation": "扩展版", "desc": "Excel 2010+ 推荐使用的排名函数"},
          {"name": "LARGE", "relation": "互补函数", "desc": "返回第 N 大的销售额"},
          {"name": "PERCENTRANK", "relation": "扩展版", "desc": "返回百分比排名"}
        ],
        "animation": {
          "formula": "=RANK(B2,$B$2:$B$20,0)",
          "steps": [
            "读取当前员工销售额 B2",
            "在整个销售区域 $B$2:$B$20 中定位",
            "按降序比较所有数值大小",
            "确定 B2 在该区域中的排名位置",
            "返回排名数字"
          ],
          "result": "3",
          "highlight": ["RANK", "销售额", "排名", "降序"]
        }
      },
      {
        "name": "库存预警",
        "scene": "库存管理",
        "syntax": "=IF(库存量<安全库存,\"补货\",\"正常\")",
        "params": "库存量与安全库存比较，返回状态提示",
        "notes": "库存管理中常用的预警公式。当实际库存低于安全库存时提示补货。",
        "example": "=IF(B2<C2,\"补货\",\"正常\")",
        "exampleResult": "补货",
        "relatedFormulas": [
          {"name": "SUMIFS", "relation": "组合使用", "desc": "按仓库和品类汇总库存"},
          {"name": "COUNTIF", "relation": "组合使用", "desc": "统计需要补货的商品数量"},
          {"name": "TEXT", "relation": "组合使用", "desc": "格式化预警信息显示颜色"}
        ],
        "animation": {
          "formula": "=IF(B2<C2,\"补货\",\"正常\")",
          "steps": [
            "读取当前库存量 B2",
            "读取安全库存阈值 C2",
            "比较 B2 是否小于 C2",
            "小于阈值返回\"补货\"",
            "大于等于阈值返回\"正常\""
          ],
          "result": "补货",
          "highlight": ["IF", "库存量", "安全库存", "补货"]
        }
      },
      {
        "name": "合同到期提醒",
        "scene": "人事管理",
        "syntax": "=IF(DATEDIF( TODAY(), 到期日, \"D\")<30,\"即将到期\",\"正常\")",
        "params": "DATEDIF 计算天数差，IF 判断是否小于 30 天",
        "notes": "人事管理中用于监控劳动合同、租赁合同等到期时间。提前 30 天预警。",
        "example": "=IF(DATEDIF(TODAY(),B2,\"D\")<30,\"即将到期\",\"正常\")",
        "exampleResult": "即将到期",
        "relatedFormulas": [
          {"name": "NETWORKDAYS", "relation": "扩展版", "desc": "计算剩余工作日而非自然日"},
          {"name": "TEXT", "relation": "组合使用", "desc": "格式化显示\"还剩 X 天\""},
          {"name": "CONDITIONAL FORMATTING", "relation": "组合使用", "desc": "到期行自动标红"}
        ],
        "animation": {
          "formula": "=IF(DATEDIF(TODAY(),B2,\"D\")<30,\"即将到期\",\"正常\")",
          "steps": [
            "TODAY() 获取当前日期",
            "DATEDIF 计算今天到到期日 B2 的天数差",
            "判断天数差是否小于 30",
            "小于 30 返回\"即将到期\"",
            "大于等于 30 返回\"正常\""
          ],
          "result": "即将到期",
          "highlight": ["DATEDIF", "TODAY", "到期日", "即将到期"]
        }
      },
      {
        "name": "销售提成计算",
        "scene": "财务分析",
        "syntax": "=IF(销售额>100000,销售额*0.05,IF(销售额>50000,销售额*0.03,销售额*0.01))",
        "params": "多层 IF 分段计算提成比例",
        "notes": "阶梯式提成计算：超过10万提成5%，5-10万提成3%，低于5万提成1%。",
        "example": "=IF(B2>100000,B2*0.05,IF(B2>50000,B2*0.03,B2*0.01))",
        "exampleResult": "3500",
        "relatedFormulas": [
          {"name": "VLOOKUP", "relation": "替代方案", "desc": "建立提成比例对照表后用 VLOOKUP 查找"},
          {"name": "SUMPRODUCT", "relation": "替代方案", "desc": "数组公式实现阶梯提成"},
          {"name": "ROUND", "relation": "组合使用", "desc": "提成金额保留两位小数"}
        ],
        "animation": {
          "formula": "=IF(B2>100000,B2*0.05,IF(B2>50000,B2*0.03,B2*0.01))",
          "steps": [
            "读取销售额 B2",
            "判断 B2 是否大于 100000",
            "大于则按 5% 计算提成",
            "否则判断 B2 是否大于 50000",
            "按对应比例计算并返回提成金额"
          ],
          "result": "3500",
          "highlight": ["IF", "销售额", "提成", "阶梯"]
        }
      },
      {
        "name": "项目工期计算",
        "scene": "项目管理",
        "syntax": "=NETWORKDAYS(开始日期, 结束日期, 节假日)",
        "params": "开始日期、结束日期，可选节假日区域",
        "notes": "计算项目的工作日天数，排除周末。可传入节假日列表进一步排除。",
        "example": "=NETWORKDAYS(B2,C2,$F$2:$F$5)",
        "exampleResult": "23",
        "relatedFormulas": [
          {"name": "WORKDAY", "relation": "互补函数", "desc": "从起始日期推算 N 个工作日后的日期"},
          {"name": "DATEDIF", "relation": "替代方案", "desc": "计算自然日天数（含周末）"},
          {"name": "IF", "relation": "组合使用", "desc": "判断工期是否超期并预警"}
        ],
        "animation": {
          "formula": "=NETWORKDAYS(B2,C2,$F$2:$F$5)",
          "steps": [
            "读取项目开始日期 B2",
            "读取项目结束日期 C2",
            "排除周六和周日的休息日",
            "排除节假日列表 $F$2:$F$5",
            "返回实际工作日天数"
          ],
          "result": "23",
          "highlight": ["NETWORKDAYS", "开始日期", "结束日期", "工作日"]
        }
      },
      {
        "name": "数据去重",
        "scene": "数据清洗",
        "syntax": "=IF(COUNTIF($A$1:A1,A1)=1,\"保留\",\"重复\")",
        "params": "COUNTIF 统计当前值在已遍历区域中的出现次数",
        "notes": "在数据清洗时标记重复值。只保留第一次出现的记录，后续重复标记为删除。",
        "example": "=IF(COUNTIF($A$1:A1,A1)=1,\"保留\",\"重复\")",
        "exampleResult": "保留",
        "relatedFormulas": [
          {"name": "COUNTIFS", "relation": "扩展版", "desc": "多列组合去重（如姓名+电话）"},
          {"name": "FILTER", "relation": "替代方案", "desc": "Excel 365 可直接过滤唯一值"},
          {"name": "UNIQUE", "relation": "替代方案", "desc": "Excel 365 直接返回唯一值列表"}
        ],
        "animation": {
          "formula": "=IF(COUNTIF($A$1:A1,A1)=1,\"保留\",\"重复\")",
          "steps": [
            "读取当前行 A1 的值",
            "COUNTIF 统计该值在 $A$1:A1 中的出现次数",
            "次数为 1 表示首次出现",
            "返回\"保留\"",
            "次数大于 1 则返回\"重复\""
          ],
          "result": "保留",
          "highlight": ["COUNTIF", "去重", "保留", "重复"]
        }
      },
      {
        "name": "动态销售报表",
        "scene": "报表自动化",
        "syntax": "=SUM(OFFSET($B$2,0,0,COUNTA($B:$B)-1,1))",
        "params": "OFFSET 配合 COUNTA 生成动态区域，SUM 汇总",
        "notes": "当销售数据不断增加时，报表自动扩展统计范围，无需手动修改公式。",
        "example": "=SUM(OFFSET($B$2,0,0,COUNTA($B:$B)-1,1))",
        "exampleResult": "动态汇总",
        "relatedFormulas": [
          {"name": "INDEX", "relation": "替代方案", "desc": "INDEX+COUNTA 实现动态区域"},
          {"name": "SUBTOTAL", "relation": "组合使用", "desc": "筛选后的动态汇总"},
          {"name": "图表数据源", "relation": "组合使用", "desc": "动态区域作为图表数据源"}
        ],
        "animation": {
          "formula": "=SUM(OFFSET($B$2,0,0,COUNTA($B:$B)-1,1))",
          "steps": [
            "COUNTA 统计 B 列非空行数",
            "OFFSET 从 B2 开始向下生成动态区域",
            "区域高度随数据量自动调整",
            "SUM 对动态区域求和",
            "新增数据后自动更新汇总结果"
          ],
          "result": "动态汇总",
          "highlight": ["OFFSET", "COUNTA", "动态", "SUM"]
        }
      }
    ]
  }

];
