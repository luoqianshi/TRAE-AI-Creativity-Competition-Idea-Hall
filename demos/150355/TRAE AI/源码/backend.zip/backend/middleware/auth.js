const { verifyToken } = require('../utils/jwt');
const pool = require('../models/db');

const authenticate = async (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ code: 401, message: '未登录' });
  }

  const decoded = verifyToken(token);
  
  if (!decoded) {
    return res.status(401).json({ code: 401, message: '登录已过期' });
  }

  const [users] = await pool.query('SELECT * FROM users WHERE id = ?', [decoded.id]);
  
  if (!users.length) {
    return res.status(401).json({ code: 401, message: '用户不存在' });
  }

  req.user = users[0];
  next();
};

const requireFaceVerified = async (req, res, next) => {
  if (!req.user.face_verified) {
    return res.status(403).json({ code: 403, message: '请先完成人脸核验' });
  }
  next();
};

module.exports = { authenticate, requireFaceVerified };