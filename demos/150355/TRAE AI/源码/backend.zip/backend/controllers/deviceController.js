const db = require('../models/db')

// 获取插座信息
exports.getDevice = (req, res) => {
    const sql = `SELECT * FROM device`
    db.query(sql, (err, result) => {
        if (err) return res.json({ code: 500, msg: '查询失败' })
        res.json({ code: 200, data: result })
    })
}

// 插座通电检测功率
exports.checkPower = (req, res) => {
    const { power } = req.body
    // 功率超标判断
    if (power > 2200) {
        return res.json({
            code: 400,
            msg: "功率过载！请勿额外插接排插、飞线，仅本机设备使用"
        })
    }
    res.json({ code: 200, msg: "功率正常，可以使用" })
}

// 租借插座
exports.rentDevice = (req, res) => {
    const { deviceId, userId } = req.body
    const sql = `UPDATE device SET status = 1, userId = ? WHERE id = ?`
    db.query(sql, [userId, deviceId], (err) => {
        if (err) return res.json({ code: 500, msg: '租借失败' })
        res.json({
            code: 200,
            msg: "插座租借成功，本校学生教师免费使用"
        })
    })
}