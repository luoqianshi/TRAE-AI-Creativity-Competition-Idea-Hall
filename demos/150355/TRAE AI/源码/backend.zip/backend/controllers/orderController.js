const db = require('../models/db')

// 查询个人租借记录
exports.getOrderList = (req, res) => {
    const { userId } = req.body
    const sql = `SELECT * FROM orders WHERE userId = ?`
    db.query(sql, [userId], (err, result) => {
        if (err) return res.json({ code: 500, msg: '查询记录失败' })
        res.json({ code: 200, data: result })
    })
}

// 归还插座
exports.returnDevice = (req, res) => {
    const { deviceId } = req.body
    const sql = `UPDATE device SET status = 0, userId = null WHERE id = ?`
    db.query(sql, [deviceId], (err) => {
        if (err) return res.json({ code: 500, msg: '归还失败' })
        res.json({ code: 200, msg: "插座已归还，使用全程免费" })
    })
}