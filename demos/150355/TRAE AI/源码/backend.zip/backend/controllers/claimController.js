const db = require('../models/db')

// 提交损坏赔付
exports.submitClaim = (req, res) => {
    const { deviceId, userId } = req.body
    const sql = `INSERT INTO claim (deviceId, userId, createTime) VALUES (?,?,NOW())`
    db.query(sql, [deviceId, userId], (err) => {
        if (err) return res.json({ code: 500, msg: '提交失败' })
        res.json({
            code: 200,
            msg: "检测到插座人为损坏，需支付维修赔付费用；正常使用全程免费"
        })
    })
}

// 查询赔付记录
exports.getClaimList = (req, res) => {
    const { userId } = req.body
    const sql = `SELECT * FROM claim WHERE userId = ?`
    db.query(sql, [userId], (err, result) => {
        if (err) return res.json({ code: 500, msg: '查询赔付记录失败' })
        res.json({ code: 200, data: result })
    })
}