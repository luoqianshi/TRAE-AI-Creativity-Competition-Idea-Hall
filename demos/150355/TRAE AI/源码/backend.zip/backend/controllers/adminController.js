const pool = require('../models/db');

const getDashboardStats = async (req, res) => {
  const [userCount] = await pool.query('SELECT COUNT(*) as count FROM users');
  const [deviceCount] = await pool.query('SELECT COUNT(*) as count FROM devices');
  const [activeDeviceCount] = await pool.query('SELECT COUNT(*) as count FROM devices WHERE status = 1');
  const [orderCount] = await pool.query('SELECT COUNT(*) as count FROM orders');
  const [todayOrderCount] = await pool.query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()");
  const [totalRevenue] = await pool.query('SELECT SUM(paid_amount) as total FROM orders WHERE status = 1');
  const [claimCount] = await pool.query('SELECT COUNT(*) as count FROM claims');

  res.json({
    code: 200,
    message: '获取成功',
    data: {
      userCount: userCount[0].count,
      deviceCount: deviceCount[0].count,
      activeDeviceCount: activeDeviceCount[0].count,
      orderCount: orderCount[0].count,
      todayOrderCount: todayOrderCount[0].count,
      totalRevenue: totalRevenue[0].total || 0,
      claimCount: claimCount[0].count
    }
  });
};

const getDeviceStats = async (req, res) => {
  const [stats] = await pool.query(`
    SELECT floor, COUNT(*) as total, 
           SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as available,
           SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as unavailable
    FROM devices 
    GROUP BY floor 
    ORDER BY floor
  `);

  res.json({ code: 200, message: '获取成功', data: stats });
};

const getOrderStats = async (req, res) => {
  const [dailyOrders] = await pool.query(`
    SELECT DATE(created_at) as date, COUNT(*) as count, SUM(paid_amount) as revenue
    FROM orders 
    WHERE status = 1 
    GROUP BY DATE(created_at) 
    ORDER BY date DESC 
    LIMIT 7
  `);

  res.json({ code: 200, message: '获取成功', data: dailyOrders.reverse() });
};

const getDeviceList = async (req, res) => {
  const { page = 1, pageSize = 20 } = req.query;
  const offset = (page - 1) * pageSize;

  const [devices] = await pool.query('SELECT * FROM devices ORDER BY floor, location LIMIT ? OFFSET ?', [pageSize, offset]);
  const [countResult] = await pool.query('SELECT COUNT(*) as total FROM devices');

  res.json({ code: 200, message: '获取成功', data: { devices, total: countResult[0].total } });
};

const getUserList = async (req, res) => {
  const { page = 1, pageSize = 20 } = req.query;
  const offset = (page - 1) * pageSize;

  const [users] = await pool.query('SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?', [pageSize, offset]);
  const [countResult] = await pool.query('SELECT COUNT(*) as total FROM users');

  res.json({ code: 200, message: '获取成功', data: { users, total: countResult[0].total } });
};

const getOrderList = async (req, res) => {
  const { page = 1, pageSize = 20 } = req.query;
  const offset = (page - 1) * pageSize;

  const [orders] = await pool.query(`
    SELECT o.*, d.device_code, d.floor, d.location, u.student_id, u.real_name
    FROM orders o 
    JOIN devices d ON o.device_id = d.id 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC 
    LIMIT ? OFFSET ?
  `, [pageSize, offset]);

  const [countResult] = await pool.query('SELECT COUNT(*) as total FROM orders');

  res.json({ code: 200, message: '获取成功', data: { orders, total: countResult[0].total } });
};

const getClaimList = async (req, res) => {
  const { page = 1, pageSize = 20 } = req.query;
  const offset = (page - 1) * pageSize;

  const [claims] = await pool.query(`
    SELECT c.*, o.order_no, d.device_code, u.real_name
    FROM claims c 
    JOIN orders o ON c.order_id = o.id 
    JOIN devices d ON c.device_id = d.id 
    JOIN users u ON c.user_id = u.id 
    ORDER BY c.created_at DESC 
    LIMIT ? OFFSET ?
  `, [pageSize, offset]);

  const [countResult] = await pool.query('SELECT COUNT(*) as total FROM claims');

  res.json({ code: 200, message: '获取成功', data: { claims, total: countResult[0].total } });
};

const updateClaimStatus = async (req, res) => {
  const { id } = req.params;
  const { status, reply } = req.body;

  await pool.query('UPDATE claims SET status = ?, reply = ? WHERE id = ?', [status, reply, id]);

  const [claims] = await pool.query('SELECT * FROM claims WHERE id = ?', [id]);

  res.json({ code: 200, message: '更新成功', data: claims[0] });
};

module.exports = { getDashboardStats, getDeviceStats, getOrderStats, getDeviceList, getUserList, getOrderList, getClaimList, updateClaimStatus };