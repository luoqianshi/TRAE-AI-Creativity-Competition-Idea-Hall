const db = require('../models/db')

// 登录接口
exports.login = async (req, res) => {
    const { account, password } = req.body
    const sql = `SELECT * FROM user WHERE account = ? AND password = ?`
    db.query(sql, [account, password], (err, result) => {
        if (err) return res.json({ code: 500, msg: '服务器错误' })
        if (result.length === 0) return res.json({ code: 401, msg: '账号或密码错误' })

        const user = result[0]
        // 身份校验，仅学生、教师可用
        if(user.userType !== "学生" && user.userType !== "教师"){
            return res.json({
                code:403,
                msg:"仅本校师生可使用共享插座，外来人员禁止登录"
            })
        }
        res.json({
            code: 200,
            msg: "登录成功",
            data: user
        })
    })
}