from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import uuid
import time
import json

app = Flask(__name__)
CORS(app)

DATABASE = 'hbut_library_socket.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            openid TEXT UNIQUE NOT NULL,
            student_id TEXT,
            real_name TEXT,
            department TEXT,
            face_verified INTEGER DEFAULT 0,
            balance REAL DEFAULT 0.00,
            status INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_code TEXT UNIQUE NOT NULL,
            floor INTEGER NOT NULL,
            location TEXT NOT NULL,
            status INTEGER DEFAULT 1,
            power_level INTEGER DEFAULT 100,
            last_used_at TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_no TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            device_id INTEGER NOT NULL,
            status INTEGER DEFAULT 0,
            start_time TEXT DEFAULT CURRENT_TIMESTAMP,
            end_time TEXT,
            duration INTEGER DEFAULT 0,
            total_amount REAL DEFAULT 0.00,
            paid_amount REAL DEFAULT 0.00,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS claims (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            order_id INTEGER NOT NULL,
            device_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            description TEXT,
            images TEXT,
            amount REAL DEFAULT 0.00,
            status INTEGER DEFAULT 0,
            reply TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (order_id) REFERENCES orders(id),
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS device_status_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER NOT NULL,
            status INTEGER NOT NULL,
            power_level INTEGER DEFAULT 100,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    cursor.execute('SELECT COUNT(*) FROM devices')
    if cursor.fetchone()[0] == 0:
        devices_data = [
            ('SK-001', 1, 'A区-1排-01', 1, 100),
            ('SK-002', 1, 'A区-1排-02', 1, 85),
            ('SK-003', 1, 'A区-1排-03', 0, 20),
            ('SK-004', 1, 'B区-2排-01', 1, 90),
            ('SK-005', 1, 'B区-2排-02', 1, 75),
            ('SK-006', 2, 'A区-1排-01', 1, 100),
            ('SK-007', 2, 'A区-1排-02', 1, 60),
            ('SK-008', 2, 'B区-2排-01', 0, 10),
            ('SK-009', 2, 'B区-2排-02', 1, 95),
            ('SK-010', 2, 'C区-3排-01', 1, 80),
            ('SK-011', 3, 'A区-1排-01', 1, 100),
            ('SK-012', 3, 'A区-1排-02', 1, 70),
            ('SK-013', 3, 'B区-2排-01', 1, 88),
            ('SK-014', 3, 'B区-2排-02', 0, 5),
            ('SK-015', 3, 'C区-3排-01', 1, 92),
            ('SK-016', 4, 'A区-1排-01', 1, 100),
            ('SK-017', 4, 'A区-1排-02', 1, 65),
            ('SK-018', 4, 'B区-2排-01', 1, 78),
            ('SK-019', 4, 'B区-2排-02', 1, 85),
            ('SK-020', 4, 'C区-3排-01', 0, 15),
            ('SK-021', 5, 'A区-1排-01', 1, 90),
            ('SK-022', 5, 'A区-1排-02', 1, 72),
            ('SK-023', 5, 'B区-2排-01', 1, 88),
            ('SK-024', 5, 'B区-2排-02', 1, 95),
            ('SK-025', 5, 'C区-3排-01', 1, 68),
            ('SK-026', 6, 'A区-1排-01', 1, 100),
            ('SK-027', 6, 'A区-1排-02', 0, 25),
            ('SK-028', 6, 'B区-2排-01', 1, 75),
            ('SK-029', 6, 'B区-2排-02', 1, 82),
            ('SK-030', 6, 'C区-3排-01', 1, 90),
            ('SK-031', 7, 'A区-1排-01', 1, 100),
            ('SK-032', 7, 'A区-1排-02', 1, 85),
            ('SK-033', 7, 'B区-2排-01', 1, 70),
            ('SK-034', 7, 'B区-2排-02', 0, 30),
            ('SK-035', 7, 'C区-3排-01', 1, 95)
        ]
        cursor.executemany('INSERT INTO devices (device_code, floor, location, status, power_level) VALUES (?, ?, ?, ?, ?)', devices_data)
    
    conn.commit()
    conn.close()

init_db()

def row_to_dict(row):
    return dict(row) if row else None

def rows_to_list(rows):
    return [dict(row) for row in rows]

@app.route('/')
def index():
    return jsonify({'message': '湖北工业大学图书馆共享插座租借系统'})

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    openid = data.get('openid', '')
    
    if not openid:
        return jsonify({'code': 400, 'message': '缺少openid'})
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (openid,))
    user = cursor.fetchone()
    
    if user:
        return jsonify({'code': 200, 'message': '登录成功', 'data': {'user': row_to_dict(user), 'token': openid}})
    
    cursor.execute('INSERT INTO users (openid) VALUES (?)', (openid,))
    conn.commit()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (openid,))
    new_user = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '注册并登录成功', 'data': {'user': row_to_dict(new_user), 'token': openid}})

@app.route('/api/auth/realNameAuth', methods=['POST'])
def real_name_auth():
    data = request.get_json()
    student_id = data.get('student_id', '')
    real_name = data.get('real_name', '')
    department = data.get('department', '')
    
    if not student_id or not real_name or not department:
        return jsonify({'code': 400, 'message': '请填写完整信息'})
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE student_id = ?', (student_id,))
    if cursor.fetchone():
        conn.close()
        return jsonify({'code': 400, 'message': '该学号已被绑定'})
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('UPDATE users SET student_id = ?, real_name = ?, department = ? WHERE id = ?', 
                   (student_id, real_name, department, user['id']))
    conn.commit()
    
    cursor.execute('SELECT * FROM users WHERE id = ?', (user['id'],))
    updated_user = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '实名认证成功', 'data': row_to_dict(updated_user)})

@app.route('/api/auth/faceVerify', methods=['POST'])
def face_verify():
    data = request.get_json()
    image = data.get('image', '')
    
    if not image:
        return jsonify({'code': 400, 'message': '请上传人脸照片'})
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('UPDATE users SET face_verified = 1 WHERE id = ?', (user['id'],))
    conn.commit()
    
    cursor.execute('SELECT * FROM users WHERE id = ?', (user['id'],))
    updated_user = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '人脸核验成功', 'data': row_to_dict(updated_user)})

@app.route('/api/auth/userInfo', methods=['GET'])
def get_user_info():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    conn.close()
    
    if not user:
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': row_to_dict(user)})

@app.route('/api/devices/floor', methods=['GET'])
def get_devices_by_floor():
    floor = request.args.get('floor', '')
    
    if not floor:
        return jsonify({'code': 400, 'message': '请指定楼层'})
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM devices WHERE floor = ? ORDER BY location', (int(floor),))
    devices = cursor.fetchall()
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': rows_to_list(devices)})

@app.route('/api/devices', methods=['GET'])
def get_all_devices():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM devices ORDER BY floor, location')
    devices = cursor.fetchall()
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': rows_to_list(devices)})

@app.route('/api/devices/code/<code>', methods=['GET'])
def get_device_by_code(code):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM devices WHERE device_code = ?', (code,))
    device = cursor.fetchone()
    conn.close()
    
    if not device:
        return jsonify({'code': 404, 'message': '设备不存在'})
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': row_to_dict(device)})

@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.get_json()
    device_id = data.get('device_id', '')
    
    if not device_id:
        return jsonify({'code': 400, 'message': '缺少设备ID'})
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    if user['face_verified'] == 0:
        conn.close()
        return jsonify({'code': 403, 'message': '请先完成人脸核验'})
    
    cursor.execute('SELECT * FROM devices WHERE id = ?', (device_id,))
    device = cursor.fetchone()
    
    if not device:
        conn.close()
        return jsonify({'code': 404, 'message': '设备不存在'})
    
    if device['status'] != 1:
        conn.close()
        return jsonify({'code': 400, 'message': '设备不可用'})
    
    cursor.execute('SELECT * FROM orders WHERE user_id = ? AND status = 0', (user['id'],))
    if cursor.fetchone():
        conn.close()
        return jsonify({'code': 400, 'message': '您已有未结束的订单'})
    
    order_no = 'ORD' + str(int(time.time()))[-10:] + str(uuid.uuid4())[-4:].upper()
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    
    cursor.execute('INSERT INTO orders (order_no, user_id, device_id, status, start_time) VALUES (?, ?, ?, 0, ?)', 
                   (order_no, user['id'], device_id, now))
    cursor.execute('UPDATE devices SET status = 0 WHERE id = ?', (device_id,))
    conn.commit()
    
    cursor.execute('SELECT * FROM orders WHERE order_no = ?', (order_no,))
    order = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '租借成功', 'data': row_to_dict(order)})

@app.route('/api/orders/return', methods=['POST'])
def return_device():
    data = request.get_json()
    order_id = data.get('order_id', '')
    
    if not order_id:
        return jsonify({'code': 400, 'message': '缺少订单ID'})
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('SELECT * FROM orders WHERE id = ? AND user_id = ?', (order_id, user['id']))
    order = cursor.fetchone()
    
    if not order:
        conn.close()
        return jsonify({'code': 404, 'message': '订单不存在'})
    
    if order['status'] != 0:
        conn.close()
        return jsonify({'code': 400, 'message': '订单状态异常'})
    
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    start_time = time.strptime(order['start_time'], '%Y-%m-%d %H:%M:%S')
    end_time = time.strptime(now, '%Y-%m-%d %H:%M:%S')
    duration = int((time.mktime(end_time) - time.mktime(start_time)) / 60)
    
    unit_price = 1
    total_amount = max(unit_price, duration * unit_price)
    
    cursor.execute('UPDATE orders SET status = 1, end_time = ?, duration = ?, total_amount = ?, paid_amount = ? WHERE id = ?', 
                   (now, duration, total_amount, total_amount, order_id))
    cursor.execute('UPDATE devices SET status = 1 WHERE id = ?', (order['device_id'],))
    cursor.execute('UPDATE users SET balance = balance - ? WHERE id = ?', (total_amount, user['id']))
    conn.commit()
    
    cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
    updated_order = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '归还成功', 'data': row_to_dict(updated_order)})

@app.route('/api/orders', methods=['GET'])
def get_user_orders():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 10))
    offset = (page - 1) * page_size
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('''
        SELECT o.*, d.device_code, d.floor, d.location 
        FROM orders o 
        JOIN devices d ON o.device_id = d.id 
        WHERE o.user_id = ? 
        ORDER BY o.created_at DESC 
        LIMIT ? OFFSET ?
    ''', (user['id'], page_size, offset))
    orders = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM orders WHERE user_id = ?', (user['id'],))
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'orders': rows_to_list(orders), 'total': total}})

@app.route('/api/claims', methods=['POST'])
def create_claim():
    data = request.get_json()
    order_id = data.get('order_id', '')
    device_id = data.get('device_id', '')
    type = data.get('type', '')
    description = data.get('description', '')
    amount = data.get('amount', 0)
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('INSERT INTO claims (user_id, order_id, device_id, type, description, amount, images) VALUES (?, ?, ?, ?, ?, ?, ?)', 
                   (user['id'], order_id, device_id, type, description, amount, json.dumps([])))
    conn.commit()
    
    cursor.execute('SELECT * FROM claims WHERE user_id = ? ORDER BY created_at DESC LIMIT 1', (user['id'],))
    claim = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '申请提交成功', 'data': row_to_dict(claim)})

@app.route('/api/claims', methods=['GET'])
def get_user_claims():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 10))
    offset = (page - 1) * page_size
    
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE openid = ?', (token,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'code': 401, 'message': '用户不存在'})
    
    cursor.execute('''
        SELECT c.*, o.order_no, d.device_code 
        FROM claims c 
        JOIN orders o ON c.order_id = o.id 
        JOIN devices d ON c.device_id = d.id 
        WHERE c.user_id = ? 
        ORDER BY c.created_at DESC 
        LIMIT ? OFFSET ?
    ''', (user['id'], page_size, offset))
    claims = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM claims WHERE user_id = ?', (user['id'],))
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'claims': rows_to_list(claims), 'total': total}})

@app.route('/api/admin/dashboard', methods=['GET'])
def get_dashboard_stats():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) as count FROM users')
    user_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM devices')
    device_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM devices WHERE status = 1')
    active_device_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM orders')
    order_count = cursor.fetchone()['count']
    
    cursor.execute("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = DATE('now')")
    today_order_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COALESCE(SUM(paid_amount), 0) as total FROM orders WHERE status = 1')
    total_revenue = cursor.fetchone()['total']
    
    cursor.execute('SELECT COUNT(*) as count FROM claims')
    claim_count = cursor.fetchone()['count']
    
    conn.close()
    
    return jsonify({
        'code': 200,
        'message': '获取成功',
        'data': {
            'userCount': user_count,
            'deviceCount': device_count,
            'activeDeviceCount': active_device_count,
            'orderCount': order_count,
            'todayOrderCount': today_order_count,
            'totalRevenue': total_revenue,
            'claimCount': claim_count
        }
    })

@app.route('/api/admin/deviceStats', methods=['GET'])
def get_device_stats():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT floor, COUNT(*) as total, 
               SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as available,
               SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as unavailable
        FROM devices 
        GROUP BY floor 
        ORDER BY floor
    ''')
    stats = cursor.fetchall()
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': rows_to_list(stats)})

@app.route('/api/admin/orderStats', methods=['GET'])
def get_order_stats():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT DATE(created_at) as date, COUNT(*) as count, SUM(paid_amount) as revenue
        FROM orders 
        WHERE status = 1 
        GROUP BY DATE(created_at) 
        ORDER BY date DESC 
        LIMIT 7
    ''')
    stats = cursor.fetchall()
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': list(reversed(rows_to_list(stats)))})

@app.route('/api/admin/devices', methods=['GET'])
def get_device_list():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM devices ORDER BY floor, location LIMIT ? OFFSET ?', (page_size, offset))
    devices = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM devices')
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'devices': rows_to_list(devices), 'total': total}})

@app.route('/api/admin/users', methods=['GET'])
def get_user_list():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?', (page_size, offset))
    users = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM users')
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'users': rows_to_list(users), 'total': total}})

@app.route('/api/admin/orders', methods=['GET'])
def get_order_list():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT o.*, d.device_code, d.floor, d.location, u.student_id, u.real_name
        FROM orders o 
        JOIN devices d ON o.device_id = d.id 
        JOIN users u ON o.user_id = u.id 
        ORDER BY o.created_at DESC 
        LIMIT ? OFFSET ?
    ''', (page_size, offset))
    orders = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM orders')
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'orders': rows_to_list(orders), 'total': total}})

@app.route('/api/admin/claims', methods=['GET'])
def get_claim_list():
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT c.*, o.order_no, d.device_code, u.real_name
        FROM claims c 
        JOIN orders o ON c.order_id = o.id 
        JOIN devices d ON c.device_id = d.id 
        JOIN users u ON c.user_id = u.id 
        ORDER BY c.created_at DESC 
        LIMIT ? OFFSET ?
    ''', (page_size, offset))
    claims = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as total FROM claims')
    total = cursor.fetchone()['total']
    conn.close()
    
    return jsonify({'code': 200, 'message': '获取成功', 'data': {'claims': rows_to_list(claims), 'total': total}})

@app.route('/api/admin/claims/<int:id>', methods=['PUT'])
def update_claim_status(id):
    data = request.get_json()
    status = data.get('status', '')
    reply = data.get('reply', '')
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('UPDATE claims SET status = ?, reply = ? WHERE id = ?', (status, reply, id))
    conn.commit()
    
    cursor.execute('SELECT * FROM claims WHERE id = ?', (id,))
    claim = cursor.fetchone()
    conn.close()
    
    return jsonify({'code': 200, 'message': '更新成功', 'data': row_to_dict(claim)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)