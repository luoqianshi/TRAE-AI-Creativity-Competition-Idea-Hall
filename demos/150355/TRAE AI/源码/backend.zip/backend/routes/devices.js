const express = require('express');
const router = express.Router();
const { getDevicesByFloor, getAllDevices, getDeviceById, getDeviceByCode, updateDeviceStatus, reportDeviceIssue } = require('../controllers/deviceController');
const { authenticate } = require('../middleware/auth');

router.get('/floor', getDevicesByFloor);
router.get('/', getAllDevices);
router.get('/:id', getDeviceById);
router.get('/code/:code', getDeviceByCode);
router.put('/:id/status', authenticate, updateDeviceStatus);
router.post('/report', authenticate, reportDeviceIssue);

module.exports = router;