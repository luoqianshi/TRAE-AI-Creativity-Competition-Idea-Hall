const express = require('express');
const router = express.Router();
const { login, realNameAuth, faceVerify, getUserInfo, updateUserInfo } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

router.post('/login', login);
router.post('/realNameAuth', authenticate, realNameAuth);
router.post('/faceVerify', authenticate, faceVerify);
router.get('/userInfo', authenticate, getUserInfo);
router.put('/userInfo', authenticate, updateUserInfo);

module.exports = router;