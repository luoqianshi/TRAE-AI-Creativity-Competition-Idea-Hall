const express = require('express');
const router = express.Router();
const { createOrder, returnDevice, getUserOrders, getOrderById } = require('../controllers/orderController');
const { authenticate, requireFaceVerified } = require('../middleware/auth');

router.post('/', authenticate, requireFaceVerified, createOrder);
router.post('/return', authenticate, returnDevice);
router.get('/', authenticate, getUserOrders);
router.get('/:id', authenticate, getOrderById);

module.exports = router;