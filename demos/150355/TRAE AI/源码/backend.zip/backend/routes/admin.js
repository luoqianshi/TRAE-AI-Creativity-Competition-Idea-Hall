const express = require('express');
const router = express.Router();
const { getDashboardStats, getDeviceStats, getOrderStats, getDeviceList, getUserList, getOrderList, getClaimList, updateClaimStatus } = require('../controllers/adminController');

router.get('/dashboard', getDashboardStats);
router.get('/deviceStats', getDeviceStats);
router.get('/orderStats', getOrderStats);
router.get('/devices', getDeviceList);
router.get('/users', getUserList);
router.get('/orders', getOrderList);
router.get('/claims', getClaimList);
router.put('/claims/:id', updateClaimStatus);

module.exports = router;