const express = require('express');
const router = express.Router();
const { createClaim, getUserClaims, getClaimById } = require('../controllers/claimController');
const { authenticate } = require('../middleware/auth');

router.post('/', authenticate, createClaim);
router.get('/', authenticate, getUserClaims);
router.get('/:id', authenticate, getClaimById);

module.exports = router;