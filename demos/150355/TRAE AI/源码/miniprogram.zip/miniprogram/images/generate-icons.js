const fs = require('fs');
const path = require('path');

const icons = {
  'home': createSimpleIcon('#999999'),
  'home-active': createSimpleIcon('#1E88E5'),
  'scan': createSimpleIcon('#999999'),
  'scan-active': createSimpleIcon('#1E88E5'),
  'record': createSimpleIcon('#999999'),
  'record-active': createSimpleIcon('#1E88E5'),
  'pay': createSimpleIcon('#999999'),
  'pay-active': createSimpleIcon('#1E88E5')
};

function createSimpleIcon(color) {
  const size = 48;
  const png = createPNG(size, size);
  return png;
}

function createPNG(width, height) {
  const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  
  const ihdr = createChunk('IHDR', Buffer.alloc(13));
  ihdr.data.writeUInt32BE(width, 0);
  ihdr.data.writeUInt32BE(height, 4);
  ihdr.data[8] = 8;
  ihdr.data[9] = 6;
  ihdr.data[10] = 0;
  ihdr.data[11] = 0;
  ihdr.data[12] = 0;
  
  const rawData = [];
  for (let y = 0; y < height; y++) {
    rawData.push(0);
    for (let x = 0; x < width; x++) {
      const cx = width / 2, cy = height / 2;
      const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
      if (dist < Math.min(width, height) / 3) {
        rawData.push(255, 255, 255, 255);
      } else {
        rawData.push(0, 0, 0, 0);
      }
    }
  }
  
  const { deflateSync } = require('zlib');
  const compressed = deflateSync(Buffer.from(rawData));
  const idat = createChunk('IDAT', compressed);
  
  const iend = createChunk('IEND', Buffer.alloc(0));
  
  return Buffer.concat([signature, ihdr.buffer, idat.buffer, iend.buffer]);
}

function createChunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  
  const typeBuffer = Buffer.from(type);
  const crcData = Buffer.concat([typeBuffer, data]);
  
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcData), 0);
  
  return {
    buffer: Buffer.concat([length, typeBuffer, data, crc]),
    data
  };
}

function crc32(data) {
  let crc = 0xFFFFFFFF;
  const table = [];
  
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  
  for (let i = 0; i < data.length; i++) {
    crc = table[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
  }
  
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

const imagesDir = path.dirname(__filename);
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}

Object.entries(icons).forEach(([name, buffer]) => {
  fs.writeFileSync(path.join(imagesDir, `${name}.png`), buffer);
  console.log(`Created ${name}.png`);
});

console.log('All icons created successfully!');