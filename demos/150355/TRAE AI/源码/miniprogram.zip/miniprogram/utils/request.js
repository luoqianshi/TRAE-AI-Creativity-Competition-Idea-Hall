const app = getApp();

const request = (options) => {
  return new Promise((resolve, reject) => {
    const { url, method = 'GET', data = {}, header = {} } = options;

    const token = app.globalData.token;
    if (token) {
      header['Authorization'] = `Bearer ${token}`;
    }

    wx.request({
      url: app.globalData.baseUrl + url,
      method: method.toUpperCase(),
      data: data,
      header: {
        'content-type': 'application/json',
        ...header
      },
      success: (res) => {
        if (res.data.code === 200) {
          resolve(res.data);
        } else if (res.data.code === 401) {
          app.clearUserInfo();
          wx.navigateTo({ url: '/pages/auth/index' });
          reject(res.data);
        } else {
          wx.showToast({ title: res.data.message, icon: 'none' });
          reject(res.data);
        }
      },
      fail: (err) => {
        wx.showToast({ title: '网络请求失败', icon: 'none' });
        reject(err);
      }
    });
  });
};

const get = (url, data = {}) => request({ url, method: 'GET', data });
const post = (url, data = {}) => request({ url, method: 'POST', data });
const put = (url, data = {}) => request({ url, method: 'PUT', data });

module.exports = { request, get, post, put };