const { get } = require('../../utils/request');

Page({
  data: {
    activeTab: 'all',
    orders: [],
    page: 1,
    pageSize: 10,
    total: 0,
    hasMore: false
  },

  onLoad() {
    this.loadOrders();
  },

  onShow() {
    this.setData({ page: 1, orders: [] });
    this.loadOrders();
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab, page: 1, orders: [] });
    this.loadOrders();
  },

  loadOrders() {
    get(`/orders?page=${this.data.page}&pageSize=${this.data.pageSize}`).then(res => {
      const { orders, total } = res.data;
      let filteredOrders = orders;

      if (this.data.activeTab === 'active') {
        filteredOrders = orders.filter(o => o.status === 0);
      } else if (this.data.activeTab === 'completed') {
        filteredOrders = orders.filter(o => o.status === 1);
      }

      this.setData({
        orders: [...this.data.orders, ...filteredOrders],
        total,
        hasMore: this.data.orders.length + filteredOrders.length < total
      });
    }).catch(() => {
      this.setData({ orders: [] });
    });
  },

  loadMore() {
    if (this.data.hasMore) {
      this.setData({ page: this.data.page + 1 });
      this.loadOrders();
    }
  },

  goToOrderDetail(e) {
    const order = e.currentTarget.dataset.order;
    wx.showModal({
      title: '订单详情',
      content: `订单号：${order.order_no}\n设备：${order.device_code}\n位置：${order.floor}楼 ${order.location}\n状态：${order.status === 0 ? '进行中' : '已完成'}\n开始时间：${order.start_time}\n${order.end_time ? '结束时间：' + order.end_time : ''}\n${order.duration ? '时长：' + order.duration + '分钟' : ''}\n费用：¥${order.total_amount.toFixed(2)}`,
      showCancel: false
    });
  }
});