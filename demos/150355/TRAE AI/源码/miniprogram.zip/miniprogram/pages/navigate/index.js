Page({
  data: {
    userFloor: "",
    nearSocket: null
  },
  onLoad(options) {
    // 获取当前用户所在楼层
    let user = wx.getStorageSync("userInfo")
    this.setData({
      userFloor: options.floor || "一楼自习区"
    })
    this.searchNearSocket()
  },
  // 匹配最近空闲插座
  searchNearSocket() {
    this.setData({
      nearSocket: {
        id: 1,
        floor: this.data.userFloor,
        position: "距离你最近插座：东侧电梯柜",
        state: "可借用，支持多人共用插孔"
      }
    })
  },
  // 前往插座扫码页
  goUseSocket() {
    wx.navigateTo({
      url: `/pages/scan/scan?id=${this.data.nearSocket.id}`
    })
  }
})