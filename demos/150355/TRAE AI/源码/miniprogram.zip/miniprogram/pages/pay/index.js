Page({
  data: {
    damageDesc: "",
    repairCost: 80, // 损坏统一赔付80元
    tipText: "正常借用插座全程免费，仅人为损坏需支付维修赔偿金"
  },
  // 输入插座损坏描述
  inputDesc(e) {
    this.setData({
      damageDesc: e.detail.value
    })
  },
  // 提交损坏赔付确认
  submitPay() {
    // 判断是否填写损坏情况
    if (!this.data.damageDesc) {
      wx.showToast({
        title: "请填写设备损坏情况",
        icon: "none"
      })
      return
    }
    wx.showModal({
      title: "损坏赔付确认",
      content: `图书馆共享插座正常使用完全免费，因人为损坏需一次性赔付维修费80元，确认提交赔付申请？`,
      confirmText: "确认赔付80元",
      cancelText: "取消",
      success: res => {
        if (res.confirm) {
          wx.showToast({ title: "赔付申请提交成功" })
          // 提交后跳转使用记录页面
          wx.navigateTo({ url: "/pages/record/record" })
        }
      }
    })
  },
  // 取消报修，返回扫码页面
  cancelReport() {
    wx.navigateBack()
  }
})