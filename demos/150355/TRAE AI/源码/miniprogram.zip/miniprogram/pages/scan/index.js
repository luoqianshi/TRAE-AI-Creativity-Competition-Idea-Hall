Page({
  data: {
    socketId: "",
    maxPower: 2500,
    currentPower: 0
  },
  onLoad(options) {
    this.setData({
      socketId: options.id
    })
  },
  // 扫码启动插座
  startScan() {
    wx.scanCode({
      success: () => {
        wx.showModal({
          title: "使用须知",
          content: "禁止外接额外插排，可与周边同学协商共用插孔，功率超标自动断电",
          confirmText: "确认使用",
          success: res => {
            if (res.confirm) this.checkPowerSafety()
          }
        })
      }
    })
  },
  // 功率安全检测
  checkPowerSafety() {
    let randomPower = Math.floor(Math.random() * 3000)
    this.setData({ currentPower: randomPower })
    if (randomPower > this.data.maxPower) {
      wx.showModal({
        title: "功率过载警告",
        content: "检测到外接排插，插座已断电，请移除多余设备",
        showCancel: false
      })
    } else {
      wx.showToast({ title: "供电正常" })
    }
  },
  // 归还插座，跳转缴费记录页
  returnSocket() {
    wx.showToast({ title: "插座已归还" })
    wx.navigateTo({ url: "/pages/record/record" })
  },
  // 设备损坏报修，跳转支付赔付页
  damageReport() {
    wx.navigateTo({ url: "/pages/pay/pay" })
  }
})