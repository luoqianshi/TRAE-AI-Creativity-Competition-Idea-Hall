Page({
  data: {
    floorList: [
      { floor: "一楼自习区", socketNum: 3 },
      { floor: "二楼阅览室", socketNum: 4 },
      { floor: "三楼藏书区", socketNum: 2 }
    ],
    selectFloor: "",
    socketList: []
  },
  // 选择楼层筛选插座
  chooseFloor(e) {
    const floorName = e.currentTarget.dataset.floor
    this.setData({
      selectFloor: floorName
    })
    // 模拟对应楼层插座数据
    this.setData({
      socketList: [
        { id: 1, pos: "东侧电梯旁", status: "空闲" },
        { id: 2, pos: "中庭过道", status: "使用中" }
      ]
    })
  },
  // 跳转扫码页面
  goScanPage(e) {
    const socketId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/scan/scan?id=${socketId}&floor=${this.data.selectFloor}`
    })
  }
})