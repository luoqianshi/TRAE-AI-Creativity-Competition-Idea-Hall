Page({
  data: {
    studentId: "",
    userName: "",
    loginTip: ""
  },
  // 输入学号
  inputStuId(e) {
    this.setData({
      studentId: e.detail.value
    })
  },
  // 输入姓名
  inputName(e) {
    this.setData({
      userName: e.detail.value
    })
  },
  // 登录校验
  loginCheck() {
    const { studentId, userName } = this.data
    if (!studentId || !userName) {
      wx.showToast({
        title: "学号和姓名不能为空",
        icon: "none"
      })
      return
    }
    // 本地存储用户信息
    wx.setStorageSync("userInfo", {
      id: studentId,
      name: userName
    })
    wx.switchTab({
      url: "/pages/home/home"
    })
    wx.showToast({
      title: "登录成功"
    })
  }
})