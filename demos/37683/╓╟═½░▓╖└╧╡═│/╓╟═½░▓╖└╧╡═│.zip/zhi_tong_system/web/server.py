#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Web服务器模块
提供实时视频流和监控面板
"""

import cv2
import base64
import numpy as np
from flask import Flask, render_template_string, Response, jsonify
from threading import Lock

# 全局变量
current_frame = None
frame_lock = Lock()
alert_status = "normal"
alert_status_lock = Lock()
log_messages = []
log_lock = Lock()
MAX_LOGS = 100

# 创建Flask应用
app = Flask(__name__)


# HTML模板
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智瞳安全预警系统 - 宿管监控大屏</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', 'SimHei', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            color: #00d4ff;
            margin-bottom: 20px;
            font-size: 28px;
            text-shadow: 0 0 10px rgba(0,212,255,0.5);
        }

        .subtitle {
            text-align: center;
            color: #888;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .dashboard {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 20px;
            margin-bottom: 20px;
        }

        .video-panel {
            background: #000;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }

        .video-panel img {
            width: 100%;
            height: auto;
            display: block;
        }

        .status-panel {
            background: rgba(30,30,50,0.95);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }

        .status-title {
            color: #aaa;
            font-size: 14px;
            margin-bottom: 10px;
            border-bottom: 1px solid #333;
            padding-bottom: 5px;
        }

        .status-value {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .status-normal {
            background: rgba(0,255,0,0.2);
            color: #0f0;
            border: 1px solid #0f0;
        }

        .status-alert {
            background: rgba(255,255,0,0.2);
            color: #ff0;
            border: 1px solid #ff0;
            animation: pulse 1s infinite;
        }

        .status-critical {
            background: rgba(255,0,0,0.3);
            color: #f00;
            border: 1px solid #f00;
            animation: pulse 0.5s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .info-card {
            margin-bottom: 20px;
            
        }

        .info-card .value {
            font-size: 32px;
            font-weight: bold;
            color: #00d4ff;
        }

        .logs-panel {
            background: rgba(0,0,0,0.8);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }

        .logs-title {
            color: #aaa;
            font-size: 14px;
            margin-bottom: 10px;
            border-bottom: 1px solid #333;
            padding-bottom: 5px;
        }

        .log-list {
            height: 590px;
            overflow-y: auto;
            font-family: 'Consolas', monospace;
            font-size: 12px;
        }

        .log-item {
            padding: 5px;
            border-bottom: 1px solid #222;
            color: #ddd;
        }

        .log-info {
            color: #0f0;
        }

        .log-warning {
            color: #ff0;
        }

        .log-error {
            color: #f00;
        }

        .log-critical {
            color: #f00;
            font-weight: bold;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            color: #555;
            font-size: 12px;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }

        .stat-item {
            text-align: center;
            flex: 1;
        }

        .stat-label {
            font-size: 12px;
            color: #888;
        }

        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #00d4ff;
            # color:#000000;
        }

        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #222;
        }

        ::-webkit-scrollbar-thumb {
            background: #555;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 "智瞳" 厂区宿舍边缘计算安全预警系统</h1>
        <div class="subtitle">边缘计算 | 实时预警 | 视觉自检 | Windows版 |数据本地处理 · 不依赖公网</div>
        <div class="dashboard">
  
            <div class="video-panel">
                <img id="video-feed" src="{{ url_for('video_feed') }}" alt="视频流">
            </div>

            <div class="status-panel">
                <div class="status-title">系统状态</div>
                <div id="status-display" class="status-value status-normal">System Healthy</div>

                <div class="info-card" hidden>
                    <div class="status-title">当前时间</div>
                    <div class="value" id="current-time">{{ time }}</div>
                </div>
                  <div class="logs-panel">
            <div class="logs-title">📋 实时日志滚动</div>
            <div class="log-list" id="log-list">
                <div class="log-item log-info">系统初始化完成</div>
                <div class="log-item log-info">等待视频流接入...</div>
                </div>
                </div>
            </div>
        </div>
        <div class="footer">
            智瞳系统 v1.0 | 边缘计算安全预警 | 具备视觉传感器自我诊断能力
        </div>
    </div>

    <script>
        // 更新时间显示
        function updateTime() {
            const now = new Date();
            const timeStr = now.toLocaleString('zh-CN');
            document.getElementById('current-time').innerText = timeStr;
        }
        updateTime();
        setInterval(updateTime, 1000);

        // 更新系统状态
        function updateStatus() {
            fetch('/api/status')
                .then(response => response.json())
                .then(data => {
                    const statusDiv = document.getElementById('status-display');
                    statusDiv.innerText = data.message;
                    statusDiv.className = 'status-value status-' + data.status;
                });
        }
        setInterval(updateStatus, 500);

        // 更新日志
        function updateLogs() {
            fetch('/api/logs')
                .then(response => response.json())
                .then(data => {
                    const logList = document.getElementById('log-list');
                    logList.innerHTML = '';
                    data.logs.forEach(log => {
                        const div = document.createElement('div');
                        div.className = 'log-item log-' + log.level;
                        div.innerText = log.timestamp + ' - ' + log.message;
                        logList.appendChild(div);
                    });
                    // 自动滚动到底部
                    logList.scrollTop = logList.scrollHeight;
                });
        }
        setInterval(updateLogs, 1000);

        // 更新统计数据
        function updateStats() {
            fetch('/api/stats')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('uptime').innerText = data.uptime;

                    
                });
        }
        setInterval(updateStats, 1000);
    </script>
</body>
</html>
'''


def update_frame(frame):
    """更新当前帧"""
    global current_frame
    with frame_lock:
        current_frame = frame.copy() if frame is not None else None


def set_alert_status(status):
    """设置警报状态"""
    global alert_status
    with alert_status_lock:
        alert_status = status


def add_log(message, level='info'):
    """添加日志消息"""
    global log_messages
    from datetime import datetime

    timestamp = datetime.now().strftime("%H:%M:%S")

    # 确定日志级别
    log_level = 'info'
    if '入侵' in message or 'Alert' in message:
        log_level = 'warning'
    elif '遮挡' in message or 'Occluded' in message or 'Critical' in message:
        log_level = 'critical'
    elif '错误' in message or 'Error' in message:
        log_level = 'error'

    log_entry = {
        'timestamp': timestamp,
        'message': message,
        'level': log_level
    }

    with log_lock:
        log_messages.append(log_entry)
        # 保持最多MAX_LOGS条记录
        while len(log_messages) > MAX_LOGS:
            log_messages.pop(0)


def generate_frames():
    """生成视频帧"""
    global current_frame

    while True:
        with frame_lock:
            if current_frame is not None:
                # 编码为JPEG
                _, buffer = cv2.imencode('.jpg', current_frame)
                frame_bytes = buffer.tobytes()

                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            else:
                # 发送占位图像
                placeholder_image = (
                    cv2.imread('placeholder.jpg')
                    if cv2.haveImageReader('placeholder.jpg')
                    else 255 * np.ones((480, 640, 3), dtype=np.uint8)
                )
                placeholder = cv2.imencode('.jpg', placeholder_image)[1].tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + placeholder + b'\r\n')


@app.route('/')
def index():
    """主页"""
    from datetime import datetime
    return render_template_string(HTML_TEMPLATE, time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


@app.route('/video_feed')
def video_feed():
    """视频流"""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/api/status')
def api_status():
    """状态API"""
    with alert_status_lock:
        status = alert_status

    messages = {
        'normal': 'System Healthy',
        'alert': 'ALERT: Intrusion Detected!',
        'critical': 'CRITICAL ERROR: Camera Occluded!'
    }

    return jsonify({
        'status': status,
        'message': messages.get(status, 'System Healthy')
    })


@app.route('/api/logs')
def api_logs():
    """日志API"""
    with log_lock:
        logs = list(log_messages)
    return jsonify({'logs': logs})


@app.route('/api/stats')
def api_stats():
    """统计API"""
    import time
    global start_time

    if 'start_time' not in globals():
        globals()['start_time'] = time.time()

    elapsed = int(time.time() - globals()['start_time'])
    hours = elapsed // 3600
    minutes = (elapsed % 3600) // 60
    seconds = elapsed % 60

    # 从数据库获取统计数据
    try:
        import sqlite3
        conn = sqlite3.connect('security.db')
        cursor = conn.cursor()

        # 获取今日入侵次数
        cursor.execute('SELECT COUNT(*) FROM events WHERE event_type="Intrusion" AND date(timestamp)=date("now")')
        intrusion_count = cursor.fetchone()[0]

        # 获取今日遮挡次数
        cursor.execute('SELECT COUNT(*) FROM events WHERE event_type="Occlusion" AND date(timestamp)=date("now")')
        occlusion_count = cursor.fetchone()[0]

        conn.close()
    except:
        intrusion_count = 0
        occlusion_count = 0

    return jsonify({
        # 'intrusion_count': intrusion_count,
        # 'occlusion_count': occlusion_count,
        'uptime': f'{hours:02d}:{minutes:02d}:{seconds:02d}'
    })


def start_web_server(host='0.0.0.0', port=5000):
    """启动Web服务器"""
    import time
    globals()['start_time'] = time.time()
    app.run(host=host, port=port, debug=False, threaded=True)


