#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
FastAPI Web服务器 - Windows专用版
完全兼容Windows环境，无uvloop依赖
"""

import asyncio
import time
import cv2
import platform
from collections import deque
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse, JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

# 创建应用
app = FastAPI(title="智瞳安全预警系统", version="2.0")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
r

# ========== Windows性能优化 ==========
class FrameBuffer:
    """双缓冲帧缓冲区"""

    def __init__(self):
        self._frames = [None, None]
        self._current = 0
        self._timestamps = [0, 0]

    def update(self, frame):
        next_idx = 1 - self._current
        self._frames[next_idx] = frame.copy() if frame is not None else None
        self._timestamps[next_idx] = time.time()
        self._current = next_idx

    def get(self):
        idx = self._current
        return self._frames[idx], self._timestamps[idx]


class JPEGEncoder:
    """JPEG编码器（带缓存）"""

    def __init__(self, quality=70):
        self.quality = quality
        self._params = [int(cv2.IMWRITE_JPEG_QUALITY), quality]

    def encode(self, frame):
        if frame is None:
            return None
        _, buffer = cv2.imencode('.jpg', frame, self._params)
        return buffer.tobytes()


# 全局状态
frame_buffer = FrameBuffer()
encoder = JPEGEncoder(quality=70)
alert_status = {"status": "normal", "message": "System Healthy"}
log_queue = deque(maxlen=200)
event_counter = {"intrusion": 0, "occlusion": 0}
start_time = time.time()

# 线程池（Windows下使用）
executor = ThreadPoolExecutor(max_workers=2)


def add_log(message: str, level: str = "info"):
    timestamp = time.strftime("%H:%M:%S")
    log_queue.append({
        "timestamp": timestamp,
        "message": message,
        "level": level
    })
    print(f"[{timestamp}] [{level.upper()}] {message}")


def update_frame(frame):
    frame_buffer.update(frame)


def set_alert_status(status: str, message: str = None):
    global alert_status
    messages = {
        'normal': 'System Healthy',
        'alert': 'ALERT: Intrusion Detected!',
        'critical': 'CRITICAL ERROR: Camera Occluded!'
    }
    alert_status = {
        "status": status,
        "message": message or messages.get(status, 'Unknown')
    }


async def video_stream_generator():
    """异步视频流生成器"""
    last_frame_time = 0
    min_interval = 1.0 / 20  # 限制20fps

    while True:
        current_time = time.time()

        if current_time - last_frame_time < min_interval:
            await asyncio.sleep(0.001)
            continue

        frame, timestamp = frame_buffer.get()

        if frame is not None:
            # 在线程池中编码
            loop = asyncio.get_event_loop()
            jpeg_data = await loop.run_in_executor(executor, encoder.encode, frame)

            if jpeg_data:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n'
                       b'Cache-Control: no-cache\r\n\r\n' + jpeg_data + b'\r\n')
                last_frame_time = current_time
        else:
            await asyncio.sleep(0.01)


# ========== API路由 ==========
@app.get("/")
async def index():
    html = get_html_template()
    return HTMLResponse(content=html)


@app.get("/video_feed")
async def video_feed():
    return StreamingResponse(
        video_stream_generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={"Cache-Control": "no-cache"}
    )


@app.get("/api/status")
async def api_status():
    return JSONResponse(content=alert_status)


@app.get("/api/logs")
async def api_logs():
    return JSONResponse(content={"logs": list(log_queue)})


@app.get("/api/stats")
async def api_stats():
    elapsed = int(time.time() - start_time)
    return JSONResponse(content={
        "intrusion_count": event_counter["intrusion"],
        "occlusion_count": event_counter["occlusion"],
        "uptime": f"{elapsed // 3600:02d}:{(elapsed % 3600) // 60:02d}:{elapsed % 60:02d}"
    })


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = {
                "status": alert_status,
                "stats": {
                    "intrusion": event_counter["intrusion"],
                    "occlusion": event_counter["occlusion"],
                    "uptime": int(time.time() - start_time)
                },
                "logs": list(log_queue)[-10:]
            }
            await websocket.send_json(data)
            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass


def get_html_template():
    """HTML模板"""
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>智瞳安全预警系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 { text-align: center; color: #00d4ff; margin-bottom: 10px; font-size: 28px; }
        .subtitle { text-align: center; color: #888; margin-bottom: 20px; font-size: 12px; }
        .dashboard {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 20px;
            margin-bottom: 20px;
        }
        .video-panel {
            background: #000;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        .video-panel img { width: 100%; height: auto; display: block; }
        .status-panel {
            background: rgba(30,30,50,0.95);
            border-radius: 10px;
            padding: 20px;
        }
        .status-value {
            font-size: 20px;
            font-weight: bold;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }
        .status-normal { background: rgba(0,255,0,0.2); color: #0f0; border: 1px solid #0f0; }
        .status-alert { background: rgba(255,255,0,0.2); color: #ff0; border: 1px solid #ff0; animation: pulse 1s infinite; }
        .status-critical { background: rgba(255,0,0,0.3); color: #f00; border: 1px solid #f00; animation: pulse 0.5s infinite; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }
        .stat-item { text-align: center; flex: 1; }
        .stat-label { font-size: 12px; color: #888; }
        .stat-number { font-size: 24px; font-weight: bold; color: #00d4ff; }
        .logs-panel {
            background: rgba(0,0,0,0.8);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        .logs-title { color: #aaa; font-size: 14px; margin-bottom: 10px; border-bottom: 1px solid #333; padding-bottom: 5px; }
        .log-list {
            height: 200px;
            overflow-y: auto;
            font-family: 'Consolas', monospace;
            font-size: 12px;
        }
        .log-item { padding: 5px; border-bottom: 1px solid #222; }
        .log-info { color: #0f0; }
        .log-warning { color: #ff0; }
        .log-error { color: #f00; }
        .log-critical { color: #f00; font-weight: bold; }
        .badge {
            position: fixed;
            bottom: 10px;
            right: 10px;
            background: rgba(0,0,0,0.7);
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            color: #0f0;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 "智瞳" 厂区宿舍边缘计算安全预警系统</h1>
        <div class="subtitle">边缘计算 | 实时预警 | 视觉自检 | Windows版</div>

        <div class="dashboard">
            <div class="video-panel">
                <img id="video-feed" src="/video_feed" alt="视频流">
            </div>

            <div class="status-panel">
                <div id="status-display" class="status-value status-normal">System Healthy</div>
                <div class="stats">
                    # <div class="stat-item">
                    #     <div class="stat-label">入侵次数</div>
                    #     <div class="stat-number" id="intrusion-count">0</div>
                    # </div>
                    # <div class="stat-item">
                    #     <div class="stat-label">遮挡次数</div>
                    #     <div class="stat-number" id="occlusion-count">0</div>
                    # </div>
                    <div class="stat-item">
                        <div class="stat-label">运行时长</div>
                        <div class="stat-number" id="uptime">00:00:00</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="logs-panel">
            <div class="logs-title">📋 实时日志</div>
            <div class="log-list" id="log-list">
                <div class="log-item log-info">系统初始化完成 (Windows版)</div>
            </div>
        </div>
    </div>
    <div class="badge" id="perf-badge">WebSocket连接中...</div>

    <script>
        let ws = null;
        let reconnectTimer = null;

        function connectWebSocket() {
            const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
            ws = new WebSocket(`${protocol}//${location.host}/ws`);

            ws.onopen = () => {
                document.getElementById('perf-badge').innerHTML = '实时推送已连接';
                document.getElementById('perf-badge').style.color = '#0f0';
            };

            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                const statusDiv = document.getElementById('status-display');
                statusDiv.innerText = data.status.message;
                statusDiv.className = `status-value status-${data.status.status}`;

                document.getElementById('intrusion-count').innerText = data.stats.intrusion;
                document.getElementById('occlusion-count').innerText = data.stats.occlusion;
                document.getElementById('uptime').innerText = data.stats.uptime;

                if (data.logs && data.logs.length) {
                    const logList = document.getElementById('log-list');
                    data.logs.forEach(log => {
                        const div = document.createElement('div');
                        div.className = `log-item log-${log.level}`;
                        div.innerText = `[${log.timestamp}] ${log.message}`;
                        logList.insertBefore(div, logList.firstChild);
                        while (logList.children.length > 100) logList.removeChild(logList.lastChild);
                    });
                }
            };

            ws.onclose = () => {
                document.getElementById('perf-badge').innerHTML = '连接断开，重连中...';
                document.getElementById('perf-badge').style.color = '#ff0';
                reconnectTimer = setTimeout(connectWebSocket, 3000);
            };
        }

        connectWebSocket();
    </script>
</body>
</html>
    '''


def start_web_server(host: str = "0.0.0.0", port: int = 5000):
    """启动Web服务器（Windows兼容）"""
    import uvicorn

    print(f"\n[Web] 启动服务器: http://{host}:{port}")
    print(f"[Web] 事件循环: asyncio (Windows兼容)")
    print(f"[Web] HTTP协议: h11 (纯Python实现)")
    print("-" * 50)

    # Windows优化配置
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="warning",
        loop="asyncio",  # Windows使用asyncio
        http="h11",  # 使用h11协议
        workers=1,  # 单进程更稳定
        timeout_keep_alive=5,
        limit_concurrency=100,
    )


__all__ = ['start_web_server', 'update_frame', 'set_alert_status', 'add_log', 'event_counter']