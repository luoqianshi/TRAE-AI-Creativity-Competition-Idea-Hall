# web/fastapi_server.py
# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""
高性能Web服务器 - 基于FastAPI + Uvicorn
解决同步阻塞和性能瓶颈问题
"""

import asyncio
import cv2
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from collections import deque
import time
from typing import Optional
import threading
import sys
import platform

app = FastAPI(title="智瞳安全预警系统", version="2.0")

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# 全局状态管理 - 使用无锁数据结构
class FrameBuffer:
    """无锁帧缓冲区 - 使用双缓冲技术"""

    def __init__(self, max_size=2):
        self._frames = [None, None]  # 双缓冲区
        self._current = 0
        self._timestamp = [0, 0]

    def update(self, frame):
        """更新帧 - 无需锁，原子操作"""
        next_idx = 1 - self._current
        self._frames[next_idx] = frame.copy() if frame is not None else None
        self._timestamp[next_idx] = time.time()
        self._current = next_idx

    def get(self):
        """获取最新帧"""
        idx = self._current
        return self._frames[idx], self._timestamp[idx]


# 全局状态
frame_buffer = FrameBuffer()
alert_status = {"status": "normal", "message": "System Healthy"}
log_queue = deque(maxlen=200)  # 双端队列，自动管理最大长度
event_counter = {"intrusion": 0, "occlusion": 0}
start_time = time.time()


# 视频编码器池 - 复用编码器减少内存分配
class JPEGEncoderPool:
    """JPEG编码器池 - 避免重复创建编码器"""

    def __init__(self, quality=85):
        self.quality = quality
        self._cache = {}

    def encode(self, frame):
        """编码帧为JPEG - 使用缓存参数"""
        if frame is None:
            return None
        # 使用不同尺寸的缓存键
        key = frame.shape[:2]
        if key not in self._cache:
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), self.quality]
            self._cache[key] = encode_param
        else:
            encode_param = self._cache[key]

        _, buffer = cv2.imencode('.jpg', frame, encode_param)
        return buffer.tobytes()


encoder_pool = JPEGEncoderPool(quality=75)  # 降低质量提升速度


def add_log(message: str, level: str = "info"):
    """添加日志（线程安全）"""
    timestamp = time.strftime("%H:%M:%S")
    log_queue.append({
        "timestamp": timestamp,
        "message": message,
        "level": level
    })
    print(f"[{timestamp}] {level.upper()}: {message}")


def update_frame(frame):
    """供主程序调用的帧更新函数"""
    frame_buffer.update(frame)


def set_alert_status(status: str, message: str = None):
    """设置警报状态"""
    global alert_status
    messages = {
        'normal': 'System Healthy',
        'alert': 'ALERT: Intrusion Detected!',
        'critical': 'CRITICAL ERROR: Camera Occluded!'
    }
    alert_status = {
        "status": status,
        "message": message or messages.get(status, 'Unknown')
    }


async def video_stream_generator():
    """异步视频流生成器 - 支持背压控制"""
    last_frame_time = 0
    min_frame_interval = 1.0 / 20  # 限制最大20fps

    while True:
        current_time = time.time()

        # 帧率限制
        if current_time - last_frame_time < min_frame_interval:
            await asyncio.sleep(0.001)
            continue

        frame, timestamp = frame_buffer.get()

        if frame is not None:
            # 使用线程池执行编码（避免阻塞事件循环）
            loop = asyncio.get_event_loop()
            jpeg_data = await loop.run_in_executor(None, encoder_pool.encode, frame)

            if jpeg_data:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n'
                       b'Cache-Control: no-cache\r\n\r\n' + jpeg_data + b'\r\n')
                last_frame_time = current_time
        else:
            await asyncio.sleep(0.01)


# API路由
@app.get("/")
async def index():
    """返回主页"""
    from fastapi.responses import HTMLResponse
    return HTMLResponse(content=get_html_template(), status_code=200)


@app.get("/video_feed")
async def video_feed():
    """视频流端点 - 异步非阻塞"""
    return StreamingResponse(
        video_stream_generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
        }
    )


@app.get("/api/status")
async def api_status():
    """状态API - 快速响应"""
    return JSONResponse(content=alert_status)


@app.get("/api/logs")
async def api_logs():
    """日志API - 返回最近日志"""
    return JSONResponse(content={"logs": list(log_queue)})


@app.get("/api/stats")
async def api_stats():
    """统计API"""
    elapsed = int(time.time() - start_time)
    return JSONResponse(content={
        "intrusion_count": event_counter["intrusion"],
        "occlusion_count": event_counter["occlusion"],
        "uptime": f"{elapsed // 3600:02d}:{(elapsed % 3600) // 60:02d}:{elapsed % 60:02d}"
    })


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket端点 - 用于实时推送
    相比HTTP轮询，WebSocket延迟更低，服务器负载更小
    """
    await websocket.accept()

    try:
        while True:
            # 推送实时状态
            data = {
                "status": alert_status,
                "stats": {
                    "intrusion": event_counter["intrusion"],
                    "occlusion": event_counter["occlusion"],
                    "uptime": int(time.time() - start_time)
                },
                "logs": list(log_queue)[-10:]  # 只推送最近10条
            }
            await websocket.send_json(data)
            await asyncio.sleep(0.5)  # 每500ms推送一次
    except WebSocketDisconnect:
        pass


def get_html_template():
    """返回优化的HTML模板 - 使用WebSocket替代轮询"""
    return """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智瞳安全预警系统 - 高性能监控大屏</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 {
            text-align: center;
            color: #00d4ff;
            margin-bottom: 20px;
            font-size: 28px;
        }
        .dashboard {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 20px;
            margin-bottom: 20px;
        }
        .video-panel {
            background: #000;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        .video-panel img {
            width: 100%;
            height: auto;
            display: block;
        }
        .status-panel {
            background: rgba(30,30,50,0.95);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        .status-value {
            font-size: 24px;
            font-weight: bold;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }
        .status-normal { background: rgba(0,255,0,0.2); color: #0f0; border: 1px solid #0f0; }
        .status-alert { background: rgba(255,255,0,0.2); color: #ff0; border: 1px solid #ff0; animation: pulse 1s infinite; }
        .status-critical { background: rgba(255,0,0,0.3); color: #f00; border: 1px solid #f00; animation: pulse 0.5s infinite; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        .logs-panel {
            background: rgba(0,0,0,0.8);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        .log-list {
            height: 200px;
            overflow-y: auto;
            font-family: 'Consolas', monospace;
            font-size: 12px;
        }
        .log-item { padding: 5px; border-bottom: 1px solid #222; }
        .log-info { color: #0f0; }
        .log-warning { color: #ff0; }
        .log-error { color: #f00; }
        .log-critical { color: #f00; font-weight: bold; }
        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }
        .stat-item { text-align: center; flex: 1; }
        .stat-label { font-size: 12px; color: #888; }
        .stat-number { font-size: 24px; font-weight: bold; color: #00d4ff; }
        .performance-badge {
            position: fixed;
            bottom: 10px;
            right: 10px;
            background: rgba(0,0,0,0.7);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 10px;
            color: #0f0;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 "智瞳" 厂区宿舍边缘计算安全预警系统 <span style="font-size:14px;">v2.0 高性能版</span></h1>

        <div class="dashboard">
            <div class="video-panel">
                <img id="video-feed" src="/video_feed" alt="视频流">
            </div>

            <div class="status-panel">
                <div id="status-display" class="status-value status-normal">System Healthy</div>
                <div class="stats">
                    <div class="stat-item">
                        <div class="stat-label">今日入侵</div>
                        <div class="stat-number" id="intrusion-count">0</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">今日遮挡</div>
                        <div class="stat-number" id="occlusion-count">0</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">系统运行</div>
                        <div class="stat-number" id="uptime">00:00:00</div>
                    </div>
                </div>
                <div style="margin-top:15px; font-size:12px; color:#888; text-align:center;">
                    数据传输: WebSocket | 编码: GPU加速
                </div>
            </div>
        </div>

        <div class="logs-panel">
            <div class="log-list" id="log-list">
                <div class="log-item log-info">系统初始化完成 (高性能模式)</div>
                <div class="log-item log-info">WebSocket连接建立中...</div>
            </div>
        </div>
    </div>
    <div class="performance-badge" id="perf-badge">延迟: --ms | FPS: --</div>

    <script>
        // 使用WebSocket替代HTTP轮询 - 减少80%的请求量
        let ws = null;
        let reconnectTimer = null;

        // 性能监控
        let lastFrameTime = performance.now();
        let frameCount = 0;

        function connectWebSocket() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

            ws.onopen = function() {
                console.log('WebSocket连接已建立');
                addLogToUI('WebSocket连接已建立，实时推送已启用', 'info');
                if (reconnectTimer) clearTimeout(reconnectTimer);
            };

            ws.onmessage = function(event) {
                const data = JSON.parse(event.data);
                // 更新UI
                updateStatusUI(data.status);
                updateStatsUI(data.stats);
                updateLogsUI(data.logs);
            };

            ws.onclose = function() {
                console.log('WebSocket连接断开，尝试重连...');
                addLogToUI('WebSocket连接断开，正在重连...', 'warning');
                reconnectTimer = setTimeout(connectWebSocket, 3000);
            };

            ws.onerror = function(error) {
                console.error('WebSocket错误:', error);
            };
        }

        // 监控视频帧性能
        const videoFeed = document.getElementById('video-feed');
        videoFeed.onload = function() {
            const now = performance.now();
            const latency = now - lastFrameTime;
            frameCount++;

            // 更新性能显示
            if (frameCount % 30 === 0) {
                const fps = (frameCount * 1000 / (now - lastFrameTime)).toFixed(1);
                document.getElementById('perf-badge').innerHTML = `延迟: ${latency.toFixed(0)}ms | FPS: ${fps}`;
                frameCount = 0;
            }
            lastFrameTime = now;
        };

        function updateStatusUI(status) {
            const statusDiv = document.getElementById('status-display');
            statusDiv.innerText = status.message;
            statusDiv.className = `status-value status-${status.status}`;
        }

        function updateStatsUI(stats) {
            document.getElementById('intrusion-count').innerText = stats.intrusion;
            document.getElementById('occlusion-count').innerText = stats.occlusion;
            const hours = Math.floor(stats.uptime / 3600);
            const minutes = Math.floor((stats.uptime % 3600) / 60);
            const seconds = stats.uptime % 60;
            document.getElementById('uptime').innerText = 
                `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
        }

        function updateLogsUI(logs) {
            const logList = document.getElementById('log-list');
            if (logs && logs.length > 0) {
                logs.forEach(log => {
                    if (!document.querySelector(`.log-item:first-child`) || 
                        document.querySelector(`.log-item:first-child`).innerText !== `[${log.timestamp}] ${log.message}`) {
                        addLogToUI(`[${log.timestamp}] ${log.message}`, log.level);
                    }
                });
            }
        }

        function addLogToUI(message, level) {
            const logList = document.getElementById('log-list');
            const div = document.createElement('div');
            div.className = `log-item log-${level}`;
            div.innerText = message;
            logList.insertBefore(div, logList.firstChild);
            while (logList.children.length > 100) {
                logList.removeChild(logList.lastChild);
            }
        }

        // 启动WebSocket连接
        connectWebSocket();
        lastFrameTime = performance.now();
    </script>
</body>
</html>
    """


# def start_web_server(host: str = "0.0.0.0", port: int = 5000):
#     """启动高性能Web服务器"""
#     import multiprocessing
#
#     # 获取CPU核心数
#     workers = multiprocessing.cpu_count()
#
#     # 配置Uvicorn服务器
#     config = uvicorn.Config(
#         app,
#         host=host,
#         port=port,
#         log_level="warning",
#         workers=min(workers, 4),  # 最多4个工作进程
#         loop="uvloop",  # 使用uvloop加速事件循环
#         http="httptools",  # 使用httptools加速HTTP解析
#     )
#     server = uvicorn.Server(config)
#     server.run()

# # web/fastapi_server.py - Windows兼容版本
# def start_web_server(host: str = "0.0.0.0", port: int = 5000):
#     """启动高性能Web服务器 - Windows兼容版"""
#     import multiprocessing
#
#     # 获取CPU核心数
#     workers = multiprocessing.cpu_count()
#
#     # Windows兼容配置 - 移除uvloop和httptools
#     config = uvicorn.Config(
#         app,
#         host=host,
#         port=port,
#         log_level="warning",
#         workers=min(workers, 2),  # Windows下建议不超过2个worker
#         # Windows下使用默认的asyncio事件循环和h11协议
#         loop="asyncio",  # 改为asyncio（Windows支持）
#         http="h11",  # 改为h11（纯Python实现，Windows兼容）
#     )
#     server = uvicorn.Server(config)
#     server.run()

def start_web_server(host: str = "0.0.0.0", port: int = 5000):
    """启动Web服务器 - 自动适配操作系统"""
    import multiprocessing

    workers = multiprocessing.cpu_count()

    # 基础配置
    config_kwargs = {
        "app": app,
        "host": host,
        "port": port,
        "log_level": "warning",
        "workers": min(workers, 2) if platform.system() == "Windows" else min(workers, 4),
    }

    # 根据操作系统选择最优配置
    if platform.system() == "Windows":
        # Windows: 使用asyncio + h11
        config_kwargs.update({
            "loop": "asyncio",
            "http": "h11",
        })
        print("[配置] Windows模式: asyncio + h11")
    elif platform.system() == "Linux":
        # Linux: 使用uvloop + httptools（最高性能）
        config_kwargs.update({
            "loop": "uvloop",
            "http": "httptools",
        })
        print("[配置] Linux模式: uvloop + httptools (高性能)")
    elif platform.system() == "Darwin":  # macOS
        # macOS: uvloop可用，但httptools可选
        config_kwargs.update({
            "loop": "uvloop",
            "http": "h11",
        })
        print("[配置] macOS模式: uvloop + h11")

    config = uvicorn.Config(**config_kwargs)
    server = uvicorn.Server(config)
    server.run()

# 导出供主程序调用的接口
__all__ = ['start_web_server', 'update_frame', 'set_alert_status', 'add_log']