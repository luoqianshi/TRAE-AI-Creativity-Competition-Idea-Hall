#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
"智瞳"厂区宿舍边缘计算安全预警系统 (融合版)

融合特性:
1. 架构: 基于 main.py (文件2) 的模块化架构 (Web, DB, Logger, 信号处理)。
2. 核心逻辑: 基于 main_windows.py (文件1) 的活体检测 + 智能锁定 + 区域报警。
"""

import cv2
import numpy as np
import json
import time
import threading
import signal
import sys
import os
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import serial
import serial.tools.list_ports
from flask import Flask, render_template

# from Antiocclusion import Antiocclusion

app = Flask(__name__)

# --- 1. 导入文件2 (架构版) 的依赖 ---
try:
    from detection.alarm import AlarmController
    from database.db_manager import DatabaseManager
    from utils.logger import SystemLogger
    from web.server import start_web_server, update_frame, set_alert_status, add_log
except ImportError as e:
    print(f"⚠️ 警告: 架构模块导入失败 ({e})，将使用模拟模式运行。")


    # --- 模拟类 (如果架构文件不存在，使用这些类防止报错) ---
    class AlarmController:
        def __init__(self, cfg=None): print("模拟: 报警器初始化")

        def set_light_normal(self): pass

        def set_light_warning(self): pass

        def set_light_critical(self): pass

        def turn_off_all_lights(self): pass


    class DatabaseManager:
        def add_event(self, *args): pass


    class SystemLogger:
        def log_info(self, msg): print(f"[INFO] {msg}")

        def log_error(self, msg): print(f"[ERROR] {msg}")


    def start_web_server(*args):
        pass


    def update_frame(*args):
        pass


    def set_alert_status(*args):
        pass


    def add_log(*args):
        pass

class CameraThread:
    def __init__(self, camera_id, width, height):
        pass
    def start(self):
        pass


class AntiOculation:
    def __init__(self,
                threshold_ratio=0.6,
                threshold_brightness=40,
                occlusion_area_threshold=0.5,
                brightness_threshold = 40,  # 亮度阈值
                uniform_ratio_threshold = 0.5,  # 均匀区域比例阈值（50%）
                std_dev_threshold = 15,  # 标准差阈值（低标准差=均匀区域）
                edge_density_threshold = 0.02,  # 边缘密度阈值（低边缘密度=遮挡）
                consecutive_frames_threshold = 3):

        self.threshold_ratio = threshold_ratio
        self.threshold_brightness = threshold_brightness
        self.occlusion_area_threshold = occlusion_area_threshold  # 画面遮挡面积阈值（50%）
        self.frame_count = 0
        self.consecutive_dark_frames = 0
        self.consecutive_occluded_frames = 0
        self.max_consecutive_dark_frames = 2  # 连续5帧暗度过低才认为是遮挡
        self.max_consecutive_occluded_frames = 3  # 连续3帧大面积遮挡才认为是遮挡
        self.brightness_threshold = brightness_threshold
        self.uniform_ratio_threshold = uniform_ratio_threshold
        self.std_dev_threshold = std_dev_threshold
        self.edge_density_threshold = edge_density_threshold
        self.consecutive_frames_threshold = consecutive_frames_threshold

        self.frame_count = 0
        self.consecutive_occluded_frames = 0
        self.last_occlusion_status = False

    def is_camera_occluded(frame, brightness_threshold=60, uniform_ratio_threshold=0.45):
        """
        改进的摄像头遮挡检测函数 - 针对你截图中的情况优化
        """
        if frame is None:
            return True

        try:
            # 转换为灰度图
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            height, width = gray.shape
            total_pixels = height * width

            # 1. 计算平均亮度（关键：你的截图亮度很低）
            avg_brightness = np.mean(gray)

            # 2. 计算标准差（你的截图标准差应该很小）
            std_dev = np.std(gray)

            # 3. 计算低亮度像素比例
            low_brightness_mask = gray < brightness_threshold
            low_brightness_ratio = np.sum(low_brightness_mask) / total_pixels

            # 4. 计算局部标准差（检测均匀区域）
            # 使用5x5窗口
            kernel_size = 5
            mean = cv2.blur(gray.astype(np.float32), (kernel_size, kernel_size))
            mean_sq = cv2.blur(gray.astype(np.float32) ** 2, (kernel_size, kernel_size))
            local_var = mean_sq - mean ** 2
            local_std = np.sqrt(np.maximum(local_var, 0))

            # 均匀区域（标准差<10的区域）
            uniform_mask = local_std < 10
            uniform_ratio = np.sum(uniform_mask) / total_pixels

            # 5. 边缘检测（Canny）
            edges = cv2.Canny(gray, 30, 100)
            edge_density = np.sum(edges > 0) / total_pixels

            # === 关键改进：针对你截图的情况设置宽松条件 ===
            # 条件1: 平均亮度很低（<80） AND 大面积均匀（>45%）
            condition1 = (avg_brightness < 90) and (uniform_ratio > uniform_ratio_threshold)

            # 条件2: 标准差很低（<20） AND 低亮度区域多（>60%）
            condition2 = (std_dev < 20) and (low_brightness_ratio > 0.4)

            # 条件3: 边缘密度极低（<2%）
            condition3 = edge_density < 0.02

            # 只要满足任意一个条件就认为是遮挡（针对你的场景放宽条件）
            is_occluded = condition1 or condition2 or condition3

            # 调试输出（你可以临时启用查看数值）
            # print(f"遮挡检测: 亮={avg_brightness:.1f}, 标准差={std_dev:.1f}, "
            #       f"均匀={uniform_ratio:.1f}%, 边缘={edge_density:.1f}%, 遮挡={is_occluded}")

            return is_occluded

        except Exception as e:
            print(f"遮挡检测错误: {e}")
            return True  # 出错时默认认为遮挡

    def detect(self, frame):
        if frame is None:
            return False, 80, 0

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        height, width = gray.shape
        total_pixels = height * width

        # 计算平均亮度
        avg_brightness = np.mean(gray)

        avg_brightness = np.mean(gray)
        std_dev = np.std(gray)

        # 计算低亮度区域的比例
        low_brightness_mask = gray < self.threshold_brightness
        low_brightness_ratio = np.sum(low_brightness_mask) / total_pixels

        kernel_size = 2
        # 计算局部方差：E[X^2] - (E[X])^2
        mean = cv2.blur(gray.astype(np.float32), (kernel_size, kernel_size))
        mean_sq = cv2.blur(gray.astype(np.float32) ** 1, (kernel_size, kernel_size))
        local_var = mean_sq - mean ** 1
        local_std = np.sqrt(np.maximum(local_var, 0))

        # 低标准差区域（均匀区域）比例
        uniform_mask = local_std < self.std_dev_threshold
        uniform_ratio = np.sum(uniform_mask) / total_pixels

        # 4. 计算边缘密度（Canny边缘检测）
        edges = cv2.Canny(gray, 20, 100)
        edge_density = np.sum(edges > 0) / total_pixels

        # 5. 综合判断遮挡条件（针对你截图中的情况）
        # 条件1: 整体亮度很低 AND 大面积均匀
        condition1 = (avg_brightness < 10) and (uniform_ratio > self.uniform_ratio_threshold)

        # 条件2: 标准差很低（图像缺乏细节）
        condition2 = std_dev < self.std_dev_threshold

        # 条件3: 边缘密度很低（缺乏纹理和边界）
        condition3 = edge_density < self.edge_density_threshold

        # 条件4: 大面积低亮度区域
        condition4 = low_brightness_ratio > 0.3  # 70%以上区域很暗

        # 只要满足任意一个条件，就认为是遮挡
        occlusion_conditions = [condition1, condition2, condition3, condition4]
        occlusion_count = sum(occlusion_conditions)

        is_occluded = occlusion_count >= 1

        # 防抖处理：连续多帧才确认遮挡
        if is_occluded:
            self.consecutive_occluded_frames += 1
        else:
            self.consecutive_occluded_frames = 0

        final_occlusion = self.consecutive_occluded_frames >= self.consecutive_frames_threshold

        # 调试信息
        debug_info = {
            'avg_brightness': avg_brightness,
            'std_dev': std_dev,
            'low_brightness_ratio': low_brightness_ratio,
            'uniform_ratio': uniform_ratio,
            'edge_density': edge_density,
            'conditions': occlusion_conditions,
            'occlusion_count': occlusion_count
        }

        return final_occlusion, avg_brightness, int(low_brightness_ratio * 100), int(uniform_ratio * 100), int(
            edge_density * 100)

        # # # 检测是否有大面积遮挡
        if low_brightness_ratio > self.threshold_ratio:
            self.consecutive_dark_frames += 1
        else:
            self.consecutive_dark_frames = 0

        # 如果连续几帧都检测到大面积暗区，则认为被遮挡
        is_occluded = self.consecutive_dark_frames >= self.max_consecutive_dark_frames

        return is_occluded, avg_brightness, int(low_brightness_ratio * 100)


class USBAlarmController:

    def __init__(self, port=None, baudrate=9600):
        self.ser = None
        self.port = port
        # 自动查找端口
        if self.port is None:
            self.port = self.find_usb_port()
        if self.port:
            try:
                self.ser = serial.Serial(self.port, baudrate, timeout=1)
                print(f"USB串口连接成功: {self.port}")
                self.set_light_normal()  # 初始化开绿灯
            except Exception as e:
                print(f"USB串口连接失败: {e}")
                self.ser = None
        else:
            print("未找到USB串口设备")

    def find_usb_port(self):
        """自动查找USB转串口设备"""
        ports = list(serial.tools.list_ports.comports())
        for port in ports:
            if 'CH340' in port.description or 'CH341' in port.description or 'USB' in port.description:
                return port.device
        return None

    def calculate_checksum(self, address, operation):
        """计算校验和"""
        return (0xA0 + address + operation) & 0xFF

    def send_command(self, address, operation):
        buzzer_enabled = True
        """发送命令"""
        if not self.ser or not self.ser.is_open:
            return False
        try:
            checksum = self.calculate_checksum(address, operation)
            command = bytearray([0xA0, address, operation, checksum])
            self.ser.write(command)
            time.sleep(0.1)
            return True
        except Exception as e:
            print(f"发送命令失败: {e}")
            return False

    def set_light_normal(self):
        """绿灯 (正常)"""
        self.send_command(0x03, 0x00)  # 红关
        self.send_command(0x01, 0x00)  # 黄关
        self.send_command(0x02, 0x01)  # 绿开
        print("💡 报警灯: 绿灯 (正常)")

    def set_light_warning(self):
        """黄灯 (警告)"""
        self.send_command(0x03, 0x00)  # 红关
        self.send_command(0x02, 0x00)  # 绿关
        self.send_command(0x01, 0x01)  # 黄开
        print("💡 报警灯: 黄灯 (警告)")

    def set_light_critical(self):
        """红灯+蜂鸣器 (严重警报)"""
        self.send_command(0x01, 0x00)  # 黄灯关闭
        self.send_command(0x02, 0x00)  # 绿灯关闭
        # 修改点：使用 "红灯+蜂鸣器" 指令 (地址 0x07, 操作 0x01 开启)
        self.send_command(0x07, 0x01)
        print("🚨 报警灯: 红灯鸣叫 (严重警报)")
    # def set_light_critical(self):
    #     """红灯 (严重)"""
    #     self.send_command(0x01, 0x00)  # 黄关
    #     self.send_command(0x02, 0x00)  # 绿关
    #     self.send_command(0x03, 0x01)  # 红开 (仅红灯，无蜂鸣器)
    #     print("💡 报警灯: 红灯 (严重)")

    def turn_off_all_lights(self):
        """关闭所有灯"""
        self.send_command(0x00, 0x00)
        print("💡 报警灯: 关闭")

    def close(self):
        """关闭串口"""
        if self.ser and self.ser.is_open:
            self.ser.close()


class ZhiTongSystem:
    """智瞳系统主控制类 (融合版)"""

    def __init__(self, config_path='config.json'):
        """初始化系统"""
        # print(config_path)
        try:
            print(f"正在尝试加载配置文件: {config_path}...")
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            print("✅ 配置文件加载成功")
        except FileNotFoundError:
            print(f"⚠️ 警告: 找不到配置文件 '{config_path}'，正在使用默认配置...")
            self.config = {}  # 设置为空字典，后续逻辑会使用默认值
        except json.JSONDecodeError:
            print(f"⚠️ 警告: 配置文件格式错误，正在使用默认配置...")
            self.config = {}
        # 1. 加载配置
        self.config = self.load_config(config_path)

        # 2. 初始化目录
        os.makedirs('evidence', exist_ok=True)
        os.makedirs('logs', exist_ok=True)

        # 3. 初始化架构模块 (文件2的功能)
        self.logger = SystemLogger()
        self.db_manager = DatabaseManager()
        # self.alarm_controller = AlarmController(self.config.get('alarm', {}))
        # 使用 USB 串口报警器
        self.alarm_controller = USBAlarmController()


        self.face_cascade = cv2.CascadeClassifier(os.path.join('haarcascade_frontalface_default.xml'))
        self.face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        self.eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
        self.smile_cascade = cv2.CascadeClassifier('haarcascade_smile.xml')
        self.right_ear_cascade = cv2.CascadeClassifier(os.path.join('haarcascade_mcs_rightear.xml'))
        self.left_ear_cascade = cv2.CascadeClassifier(os.path.join('haarcascade_mcs_leftear.xml'))
        self.fullbody_cascade = cv2.CascadeClassifier(os.path.join('haarcascade_fullbody.xml'))

        if self.face_cascade.empty():
            print("⚠️ 警告: 人脸模型加载失败")

        # 5. 初始化状态变量 (文件1的核心逻辑变量)
        self.running = False
        self.cap = None

        # --- 智能锁定状态机 ---
        self.is_locked = False  # 是否锁定目标
        self.has_entered_core = False  # 是否进入过核心区 (一旦进入保持红灯)
        self.lost_frames = 0  # 丢失计数器
        self.max_lost_frames = 15  # 允许丢失的最大帧数 (防抖)
        self.manual_silence_until = 0  # 手动消警后的静音截止时间
        self.manual_silence_seconds = 1  # 手动消警后短暂防止立即重复报警

        # 字体路径
        self.font_path = self._find_font()

        # 始化防遮挡检测器
        self.anti_occlusion = AntiOculation()


    def load_config(self, path):
        """加载配置文件，如果不存在则创建默认配置"""
        default_cfg = {
            "camera": {"device_id": 1, "width": 640, "height": 480},
            "alarm": {"port": "COM3", "baudrate": 9600},
            "web": {"host": "0.0.0.0", "port": 5000}
        }
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return default_cfg
        return default_cfg

    def _find_font(self):
        """查找中文字体"""
        paths = ["C:/Windows/Fonts/simhei.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
        for p in paths:
            if os.path.exists(p): return p
        return None

    def init_camera(self):
        """初始化摄像头"""
        cam_cfg = self.config.get('camera', {})
        self.cap = cv2.VideoCapture(cam_cfg.get('device_id', 0))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam_cfg.get('width', 640))
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam_cfg.get('height', 480))
        if not self.cap.isOpened():
            self.logger.log_error("无法打开摄像头")
            return False
        return True

    def save_evidence(self, frame, event_type):
        """保存证据 (文件2功能)"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = f"evidence/{event_type}_{ts}.jpg"
        cv2.imwrite(path, frame)
        self.db_manager.add_event(event_type, path)
        add_log(f"证据保存: {path}")

    def is_manual_silence_active(self):
        return time.time() < self.manual_silence_until

    def manual_reset_alarm(self, source="Q/Enter"):
        self.alarm_controller.turn_off_all_lights()
        self.is_locked = False
        self.has_entered_core = False
        self.lost_frames = 0
        self.manual_silence_until = time.time() + self.manual_silence_seconds
        set_alert_status("normal")
        add_log(f"手动消警: {source}，静音 {self.manual_silence_seconds} 秒")
        self.logger.log_info(f"【手动消警】来源: {source}，静音 {self.manual_silence_seconds} 秒")
        print(f"【系统】已手动消警，{self.manual_silence_seconds} 秒内不会立即重复报警")

    # --- 【核心注入】文件1的活体检测逻辑 ---
    def detect_features(self, gray, face_rect):
        """检测人脸特征 (眼睛/嘴巴) 以判断是否为活体"""
        x, y, w, h = face_rect
        roi_gray = gray[y:y + h, x:x + w]

        # 检测眼睛
        eyes = self.eye_cascade.detectMultiScale(roi_gray, 1.1, 5, minSize=(15, 15))
        # 检测嘴巴 (在人脸下半部分)
        roi_mouth = gray[y + int(h / 2):y + h, x:x + w]
        mouths = self.smile_cascade.detectMultiScale(roi_mouth, 1.1, 10, minSize=(20, 20))

        return len(eyes) >= 1 or len(mouths) >= 1

    def put_text(self, img, text, pos, color=(0, 255, 0)):
        """绘制中文文本"""
        if self.font_path:
            img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(img_pil)
            font = ImageFont.truetype(self.font_path, 20, encoding="utf-8")
            draw.text(pos, text, font=font, fill=color[::-1])  # BGR -> RGB
            return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
        else:
            cv2.putText(img, text, pos, cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            return img

    def advanced_liveness_detection(self, frame, gray, face_rect):

        x, y, w, h = face_rect


        roi_gray = gray[y:y + h, x:x + w]
        eyes = self.eye_cascade.detectMultiScale(roi_gray, 1.05, 2, minSize=(10, 10))

        roi_mouth = gray[y + int(h / 3):y + h, x:x + w]
        mouths = self.smile_cascade.detectMultiScale(roi_mouth, 1.05, 5, minSize=(15, 15))

        if len(eyes) >= 1 or len(mouths) >= 1:
            return True, "标准活体检测通过"

            face_roi = gray[y:y + h, x:x + w]
            edges = cv2.Canny(face_roi, 30, 80)  # 降低Canny阈值

            # 计算左右半脸的边缘密度差异（侧脸特征）
            left_half = edges[:, :edges.shape[1] // 2]
            right_half = edges[:, edges.shape[1] // 2:]

            left_density = np.sum(left_half) / left_half.size
            right_density = np.sum(right_half) / right_half.size

            # 如果边缘密度差异明显，认为是侧脸活体
            density_ratio = max(left_density, right_density) / (min(left_density, right_density) + 1e-6)
            if density_ratio > 1.3:  # 从2.0降到1.3，更敏感
                return True, "侧脸活体检测通过（轮廓分析）"

        # === 第三层：口罩/面罩情况（单一特征）===
        if len(eyes) >= 1 or len(mouths) >= 1:
            return True, "口罩情况活体检测通过（单一特征）"

        # === 第四层：人形检测兜底（完全遮挡情况）===
        # 在整个画面中检测人形
        bodies = self.fullbody_cascade.detectMultiScale(gray, 1.05, 1, minSize=(40, 80))

        if len(bodies) > 0:
            # 检查是否有人形在人脸附近
            for (bx, by, bw, bh) in bodies:
                # 计算人脸和人形的重叠度
                face_center_x = x + w // 2
                face_center_y = y + h // 2

                extended_bx = bx - bw // 4
                extended_by = by - bh // 4
                extended_bw = bw * 1.5
                extended_bh = bh * 1.

                if (extended_bx <= face_center_x <= extended_bx + extended_bw and
                        extended_by <= face_center_y <= extended_by + extended_bh):
                    return True, "人形检测兜底通过"

        return False, "活体检测失败"

    def _validate_models(self):
        """验证所有模型是否加载成功"""
        models = {
            '人脸': self.face_cascade,
            '眼睛': self.eye_cascade,
            '嘴巴': self.smile_cascade,
            '左耳': self.left_ear_cascade,
            '右耳': self.right_ear_cascade,
            '人形': self.fullbody_cascade
        }

        missing_models = []
        for name, model in models.items():
            if model.empty():
                missing_models.append(name)

        if missing_models:
            print(f"⚠️ 警告: 以下模型加载失败: {', '.join(missing_models)}")
            print("请确保 haarcascade 目录包含所有必要的 .xml 文件")
        else:
            print("✅ 所有活体检测模型加载成功")
    def process_frame(self, frame):

        face = None
        is_occluded, avg_brightness, low_brightness_ratio, uniform_ratio, edge_density = self.anti_occlusion.detect(
            frame)
        if hasattr(self, 'debug_mode') and self.debug_mode:
            # 在画面上显示遮挡检测结果
            debug_text = f"亮:{avg_brightness:.1f} 标准差:{self.anti_occlusion.std_dev_threshold:.1f} 均匀:{uniform_ratio}% 边缘:{edge_density}%"
            frame = self.put_text(frame, debug_text, (10, 120), (255, 255, 255))

        if is_occluded:
            silence_active = self.is_manual_silence_active()
            remaining_silence = max(0.0, self.manual_silence_until - time.time())

            # 摄像头被遮挡，设置红灯并返回处理后的帧
            if silence_active:
                self.alarm_controller.turn_off_all_lights()
                status_text = f"状态：摄像头被遮挡，手动静音中 ({remaining_silence:.1f}s)"
            else:
                self.alarm_controller.set_light_critical()
                status_text = f"状态：危险 - 摄像头被遮挡 (亮度:{avg_brightness:.1f}, 暗区比例:{low_brightness_ratio}%)"

            # 在画面上叠加红色警告
            overlay = frame.copy()
            overlay[:] = (0, 0, 255)  # 红色
            cv2.addWeighted(overlay, 0.3, frame, 0.7, 0, frame)

            # 添加警告文字
            title_text = "!!! 危险：摄像头被遮挡 !!!"
            if silence_active:
                title_text = f"!!! 摄像头被遮挡，已手动静音 {remaining_silence:.1f}s !!!"
            frame = self.put_text(frame, title_text, (10, 30), (0, 0, 255))
            frame = self.put_text(frame, f"亮度: {avg_brightness:.1f}, 暗区比例: {low_brightness_ratio}%", (10, 60),
                                  (0, 0, 255))

            # 保存证据截图
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"evidence/camera_occluded_{timestamp}.jpg"
            os.makedirs("evidence", exist_ok=True)
            cv2.imwrite(filename, frame)
            add_log(f"证据保存: {filename}")

            # 更新Web状态
            set_alert_status("alert" if silence_active else "critical")
            update_frame(frame)
            return frame

        # 2. 摄像头未被遮挡，继续进行正常的人脸检测流程
        # 预处理
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        h, w = frame.shape[:2]

        # 3. 定义区域 (文件1逻辑: 核心区域在中间)
        # 核心区域 (中心 40%)
        core_w, core_h = int(w * 0.4), int(h * 0.4)
        core_x, core_y = int(w * 0.3), int(h * 0.3)

        # 绘制区域框
        cv2.rectangle(frame, (core_x, core_y), (core_x + core_w, core_y + core_h), (255, 0, 0), 2)
        frame = self.put_text(frame, "核心警戒区", (core_x, core_y - 10), (255, 0, 0))


        faces = self.face_cascade.detectMultiScale(gray, 1.05, 5, minSize=(50, 50))
        valid_target = None
        liveness_info = ""

        if len(faces) > 0:
            face = max(faces, key=lambda x: x[2] * x[3])

            # 使用升级后的活体检测
            is_live, liveness_info = self.advanced_liveness_detection(frame, gray, face)

            if is_live:
                valid_target = face
                add_log(f"活体检测: {liveness_info}")

        # 5. 智能锁定状态机 (文件1核心逻辑)
        if valid_target is not None:
            self.lost_frames = 0
            if not self.is_locked:
                self.is_locked = True
                self.has_entered_core = False  # 新目标，重置入侵状态
                add_log("🔒 目标锁定")
        else:
            if self.is_locked:
                self.lost_frames += 1
                if self.lost_frames > self.max_lost_frames:
                    self.is_locked = False
                    self.has_entered_core = False
                    add_log("🔓 目标解锁")

        valid_target = face
        if hasattr(self, 'debug_mode') and self.debug_mode:
            frame = self.put_text(frame, f"活体: {liveness_info}", (10, 90), (0, 255, 0))

        else:
             # 即使没有检测到人脸，也要检查是否有其他人形
            bodies = self.fullbody_cascade.detectMultiScale(
          gray,
          scaleFactor=1.05,
          minNeighbors=1,
            minSize=(40, 80)
       )
        if len(bodies) > 0:
            # 如果检测到人形但没检测到人脸，仍然认为有目标
            # 这种情况可能是严重遮挡，但仍需报警
            valid_target = (bodies[0][0], bodies[0][1], bodies[0][2], bodies[0][3])
            liveness_info = "人形检测激活（无人脸）"
            if hasattr(self, 'debug_mode') and self.debug_mode:
                frame = self.put_text(frame, f"警告: {liveness_info}", (10, 90), (0, 165, 255))

        # 6. 报警逻辑决策 (文件1逻辑)
        alarm_level = 0  # 0:正常, 1:警告(黄), 2:严重(红)

        if self.is_locked and valid_target is not None:
            tx, ty, tw, th = valid_target
            cx, cy = tx + tw // 2, ty + th // 2

            # 判断是否进入核心区
            in_core = (core_x < cx < core_x + core_w) and (core_y < cy < core_y + core_h)

            if in_core:
                self.has_entered_core = True

            if self.has_entered_core:
                alarm_level = 2  # 只要进过核心区，就一直红灯
            else:
                alarm_level = 1  # 锁定但未进核心区，黄灯
        else:
            alarm_level = 0  # 未锁定，绿灯

        # 7. 执行硬件控制与绘制
        status_text = ""
        color = (0, 255, 0)

        if self.is_manual_silence_active():
            remaining_silence = max(0.0, self.manual_silence_until - time.time())
            self.alarm_controller.turn_off_all_lights()
            if alarm_level == 0:
                status_text = "状态：正常 (绿灯)"
                color = (0, 255, 0)
                set_alert_status("normal")
            else:
                status_text = f"状态：手动消警中 ({remaining_silence:.1f}s)"
                color = (255, 255, 0)
                set_alert_status("alert")
        elif alarm_level == 0:
            self.alarm_controller.set_light_normal()
            status_text = "状态：正常 (绿灯)"
            color = (0, 255, 0)
            set_alert_status("normal")
        elif alarm_level == 1:
            self.alarm_controller.set_light_warning()
            status_text = "状态：警告 - 目标徘徊 (黄灯)"
            color = (0, 165, 255)
            set_alert_status("alert")
        elif alarm_level == 2:
            self.alarm_controller.set_light_critical()
            status_text = "状态：严重 - 目标入侵 (红灯)"
            color = (0, 0, 255)
            set_alert_status("critical")

        # 绘制结果
        if self.is_locked and valid_target is not None:
            tx, ty, tw, th = valid_target
            cv2.rectangle(frame, (tx, ty), (tx + tw, ty + th), color, 3)
            frame = self.put_text(frame, "目标锁定", (tx, ty - 30), color)

        frame = self.put_text(frame, status_text, (10, 30), color)

        # 推送到Web
        update_frame(frame)
        return frame

    @staticmethod
    def _rect_center(rect):
        x, y, w, h = rect
        return x + w // 2, y + h // 2

    @staticmethod
    def _point_in_rect(point, rect):
        x, y, w, h = rect
        px, py = point
        return x <= px <= x + w and y <= py <= y + h

    def get_core_rect(self, frame, ratio=0.4):
        height, width = frame.shape[:2]
        core_w = int(width * ratio)
        core_h = int(height * ratio)
        core_x = (width - core_w) // 2
        core_y = (height - core_h) // 2
        return core_x, core_y, core_w, core_h

    def draw_core_region(self, frame, core_rect, intruded=False, thickness=2):
        color = (0, 0, 255) if intruded else (255, 0, 0)
        x, y, w, h = core_rect
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, thickness)
        label = '核心区入侵' if intruded else '核心区'
        cv2.putText(frame, label, (x, max(0, y - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA)
        return frame

    def draw_faces(self, frame, faces, core_rect=None, thickness=2):
        intruded = False
        for (x, y, w, h, score) in faces:
            center = self._rect_center((x, y, w, h))
            if core_rect is not None and self._point_in_rect(center, core_rect):
                color = (0, 0, 255)
                label = '锁定'
                intruded = True
            else:
                color = (255, 0, 0)
                label = '目标'
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, thickness)
            cv2.putText(frame, f"{label}:{score:.2f}", (x, max(0, y - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1,
                        cv2.LINE_AA)

        if core_rect is not None:
            self.draw_core_region(frame, core_rect, intruded=intruded, thickness=thickness)

        return frame

    def run(self):
        """主循环"""
        web_cfg = self.config.get('web', {})
        web_thread = threading.Thread(
            target=start_web_server,
            kwargs={
                'host': web_cfg.get('host', '127.0.0.1'),
                'port': web_cfg.get('port', 5000),
            },
            daemon=True
        )
        web_thread.start()

        if not self.init_camera():
            set_alert_status("critical")
            add_log("无法打开摄像头，Web界面已启动，请检查摄像头连接和占用情况。", level='error')
            self.logger.log_error("无法打开摄像头，系统保持运行以便访问 Web 界面")
            print("Web 界面已启动: http://127.0.0.1:5000")
            print("摄像头初始化失败，按 Ctrl+C 退出程序。")
            while True:
                time.sleep(1)

        self.running = True
        self.logger.log_info("系统启动")

        while self.running:
            ret, frame = self.cap.read()
            if not ret: break
            frame = self. process_frame(frame)
            cv2.imshow("ZhiTong Fusion", frame)
            key = cv2.waitKey(1)
            if key != -1:
                key &= 0xFF

            # 支持 Q / Enter / 空格 / R 手动消警，ESC 退出
            if key in (ord('q'), ord('Q'), ord('r'), ord('R'), 13, 10, 32):
                key_name_map = {
                    ord('q'): 'Q',
                    ord('Q'): 'Q',
                    ord('r'): 'R',
                    ord('R'): 'R',
                    13: 'Enter',
                    10: 'Enter',
                    32: 'Space',
                }
                self.manual_reset_alarm(key_name_map.get(key, 'Hotkey'))
            elif key == 27:  # ESC
                break

        self.cleanup()

    def cleanup(self):
        self.running = False
        if self.cap: self.cap.release()
        cv2.destroyAllWindows()
        # self.alarm_controller.turn_off_all_lights()
        self.alarm_controller.turn_off_all_lights()
        self.alarm_controller.close()
        self.logger.log_info("系统退出")


if __name__ == "__main__":
    app = ZhiTongSystem()
    app.run()
