#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
报警联动模块
控制USB报警灯和蜂鸣器
"""

import serial
import serial.tools.list_ports
import threading
import time
import sys


class AlarmController:
    """报警控制器"""

    def __init__(self, config):
        """
        初始化报警控制器

        Args:
            config: 报警配置
        """
        self.serial_port_name = config.get('serial_port', 'COM3')
        self.baud_rate = config.get('baud_rate', 9600)
        self.alert_duration = config.get('alert_duration', 3)

        self.serial_conn = None
        self.alarm_active = False
        self.alarm_thread = None

        self._init_serial()

    def _init_serial(self):
        """初始化串口连接"""
        try:
            # 尝试连接配置的串口
            self.serial_conn = serial.Serial(
                port=self.serial_port_name,
                baudrate=self.baud_rate,
                timeout=1
            )
            print(f"报警灯已连接: {self.serial_port_name}")
        except Exception as e:
            print(f"警告: 无法连接报警灯 - {e}")
            print("系统将以模拟模式运行（报警功能禁用）")
            self.serial_conn = None

    def _send_command(self, command):
        """
        发送串口命令

        Args:
            command: 命令字节
        """
        if self.serial_conn and self.serial_conn.is_open:
            try:
                self.serial_conn.write(command)
            except Exception as e:
                print(f"发送命令失败: {e}")

    def trigger_intrusion_alarm(self):
        """触发入侵报警（闪烁）"""
        if self.alarm_active:
            return

        self.alarm_active = True

        def alarm_loop():
            start_time = time.time()
            while self.alarm_active and (time.time() - start_time) < self.alert_duration:
                # 发送高电平（开）
                self._send_command(b'H')
                time.sleep(0.3)
                # 发送低电平（关）
                self._send_command(b'L')
                time.sleep(0.3)
            self.alarm_active = False
            # 确保关闭报警
            self._send_command(b'L')

        self.alarm_thread = threading.Thread(target=alarm_loop)
        self.alarm_thread.daemon = True
        self.alarm_thread.start()

        print("[报警] 入侵检测触发 - 报警灯闪烁")

    def trigger_critical_alarm(self):
        """触发严重警报（长亮）"""
        # 停止当前报警
        self.alarm_active = False
        if self.alarm_thread:
            self.alarm_thread.join(timeout=0.5)

        # 发送持续高电平
        self._send_command(b'H')

        print("[报警] 严重警报触发 - 报警灯长亮")

    def stop_alarm(self):
        """停止报警"""
        self.alarm_active = False
        self._send_command(b'L')
        print("[报警] 报警已停止")

    def cleanup(self):
        """清理资源"""
        self.stop_alarm()
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            print("报警灯连接已关闭")