#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
防遮挡检测模块
检测摄像头是否被遮挡或遭受强光攻击
"""

import cv2
import numpy as np


class AntiOcclusionDetector:
    """防遮挡检测器"""

    def __init__(self, config):
        """
        初始化防遮挡检测器

        Args:
            config: 配置字典，包含亮度阈值和连续帧数阈值
        """
        self.low_threshold = config.get('brightness_low_threshold', 30)
        self.high_threshold = config.get('brightness_high_threshold', 240)
        self.consecutive_threshold = config.get('consecutive_frames_threshold', 10)

        self.occlusion_counter = 0
        self.last_brightness = 0
        self.is_occluded = False

    def calculate_brightness(self, frame):
        """
        计算图像的平均亮度

        Args:
            frame: 输入图像帧

        Returns:
            float: 平均亮度值
        """
        # 转换为灰度图
        if len(frame.shape) == 3:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        else:
            gray = frame

        # 计算平均亮度
        brightness = np.mean(gray)
        return brightness

    def detect(self, frame):
        """
        检测摄像头是否被遮挡

        Args:
            frame: 输入图像帧

        Returns:
            tuple: (是否被遮挡, 亮度值, 计数器值)
        """
        brightness = self.calculate_brightness(frame)

        # 判断是否超出正常亮度范围
        is_abnormal = (brightness < self.low_threshold or
                       brightness > self.high_threshold)

        if is_abnormal:
            self.occlusion_counter += 1
        else:
            self.occlusion_counter = 0

        # 判断是否达到触发阈值
        if self.occlusion_counter >= self.consecutive_threshold:
            self.is_occluded = True
        else:
            self.is_occluded = False

        self.last_brightness = brightness

        return self.is_occluded, brightness, self.occlusion_counter

    def reset(self):
        """重置检测状态"""
        self.occlusion_counter = 0
        self.is_occluded = False