#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
入侵检测模块
基于背景减除的运动目标检测
"""

import cv2
import numpy as np


class IntrusionDetector:
    """入侵检测器"""

    def __init__(self, config, roi_config):
        """
        初始化入侵检测器

        Args:
            config: 检测配置
            roi_config: ROI区域配置
        """
        self.area_threshold = config.get('intrusion_area_threshold', 800)
        self.history = config.get('background_history', 100)
        self.var_threshold = config.get('background_var_threshold', 16)

        # ROI区域
        self.roi_x = roi_config.get('x', 0)
        self.roi_y = roi_config.get('y', 0)
        self.roi_w = roi_config.get('width', 640)
        self.roi_h = roi_config.get('height', 480)

        # 创建背景减除器
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=self.history,
            varThreshold=self.var_threshold,
            detectShadows=True
        )

        self.kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

    def extract_roi(self, frame):
        """
        提取ROI区域

        Args:
            frame: 原始图像

        Returns:
            numpy.ndarray: ROI区域图像
        """
        roi = frame[self.roi_y:self.roi_y + self.roi_h,
                    self.roi_x:self.roi_x + self.roi_w]
        return roi

    def detect(self, frame):
        """
        检测入侵

        Args:
            frame: 原始图像帧

        Returns:
            tuple: (是否检测到入侵, ROI区域, 有效轮廓列表)
        """
        # 提取ROI区域
        roi = self.extract_roi(frame)

        if roi.size == 0:
            return False, roi, []

        # 应用背景减除
        fg_mask = self.bg_subtractor.apply(roi)

        # 二值化处理
        _, binary_mask = cv2.threshold(fg_mask, 200, 255, cv2.THRESH_BINARY)

        # 形态学处理：膨胀连接断裂区域
        dilated_mask = cv2.dilate(binary_mask, self.kernel)

        # 查找轮廓
        contours, _ = cv2.findContours(dilated_mask, cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)

        # 筛选有效轮廓
        valid_contours = []
        intrusion_detected = False

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > self.area_threshold:
                valid_contours.append(cnt)
                intrusion_detected = True

        # 在ROI上绘制轮廓
        roi_with_contours = roi.copy()
        for cnt in valid_contours:
            x, y, w, h = cv2.boundingRect(cnt)
            cv2.rectangle(roi_with_contours, (x, y), (x + w, y + h), (0, 255, 0), 2)

        return intrusion_detected, roi_with_contours, valid_contours

    def reset(self):
        """重置背景模型"""
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=self.history,
            varThreshold=self.var_threshold,
            detectShadows=True
        )