#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日志管理模块
"""

import logging
import os
from datetime import datetime


class SystemLogger:
    """系统日志管理器"""

    def __init__(self, log_dir='logs'):
        """
        初始化日志系统

        Args:
            log_dir: 日志目录
        """
        self.log_dir = log_dir
        self.logger = logging.getLogger('ZhiTongSystem')
        self.logger.setLevel(logging.DEBUG)

        # 创建日志目录
        os.makedirs(log_dir, exist_ok=True)

        # 文件处理器
        log_filename = f"{log_dir}/system_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.FileHandler(log_filename, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)

        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # 格式化器
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # 添加处理器
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)

    def log_info(self, message):
        """记录信息日志"""
        self.logger.info(message)

    def log_warning(self, message):
        """记录警告日志"""
        self.logger.warning(message)

    def log_error(self, message):
        """记录错误日志"""
        self.logger.error(message)

    def log_debug(self, message):
        """记录调试日志"""
        self.logger.debug(message)