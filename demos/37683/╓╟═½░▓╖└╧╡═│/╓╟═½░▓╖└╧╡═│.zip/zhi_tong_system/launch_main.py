#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import runpy
import socket
import sys
import threading
import time
import webbrowser


ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
MAIN_PATH = os.path.join(ROOT_DIR, "main.py")
WEB_URL = "http://127.0.0.1:5000"


def _prepare_environment():
    os.chdir(ROOT_DIR)
    os.environ.setdefault("OPENCV_VIDEOIO_PRIORITY_MSMF", "0")
    os.environ.setdefault("OPENCV_VIDEOIO_PRIORITY_DSHOW", "1000")

    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _patch_socket_getfqdn():
    original_getfqdn = socket.getfqdn

    def safe_getfqdn(name=""):
        try:
            return original_getfqdn(name)
        except UnicodeDecodeError:
            return "localhost"

    socket.getfqdn = safe_getfqdn


def _open_browser_when_ready():
    deadline = time.time() + 20
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", 5000), timeout=1):
                webbrowser.open(WEB_URL, new=1)
                return
        except OSError:
            time.sleep(1)


if __name__ == "__main__":
    _prepare_environment()
    _patch_socket_getfqdn()
    threading.Thread(target=_open_browser_when_ready, daemon=True).start()
    runpy.run_path(MAIN_PATH, run_name="__main__")
