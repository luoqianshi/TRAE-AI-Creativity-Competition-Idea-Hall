import os
import sys
import sqlite3
from datetime import datetime

# 确保 database 目录存在
os.makedirs('database', exist_ok=True)

db_path = 'database/security.db'

# 1. 连接数据库（如果文件不存在会自动创建）
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 2. 创建 events 表（这是解决你报错的关键）
# 注意：一定要包含 timestamp 字段，且不能为空
cursor.execute('''
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        timestamp DATETIME NOT NULL
    )
''')

# 3. 提交并关闭
conn.commit()
conn.close()

print(f"✅ 成功！数据库已创建：{os.path.abspath(db_path)}")