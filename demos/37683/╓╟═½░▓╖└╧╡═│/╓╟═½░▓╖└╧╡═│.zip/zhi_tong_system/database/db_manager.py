#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
数据库管理模块
管理SQLite数据库，存储报警记录
"""

import sqlite3
import os
from datetime import datetime


class DatabaseManager:
    """数据库管理器"""

    def __init__(self, db_path='security.db'):
        """
        初始化数据库

        Args:
            db_path: 数据库文件路径
        """
        self.db_path = db_path
        self._init_database()

    def _init_database(self):
        """初始化数据库表结构"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                image_path TEXT,
                status TEXT DEFAULT 'pending',
                description TEXT
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                log_level TEXT NOT NULL,
                message TEXT NOT NULL
            )
        ''')

        conn.commit()
        conn.close()

        print(f"数据库初始化完成: {self.db_path}")

    def add_event(self, event_type, image_path=None, description=None):
        """
        添加事件记录

        Args:
            event_type: 事件类型 (Intrusion/Occlusion)
            image_path: 证据图片路径
            description: 事件描述

        Returns:
            int: 插入的记录ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute('''
            INSERT INTO events (timestamp, event_type, image_path, status, description)
            VALUES (?, ?, ?, ?, ?)
        ''', (timestamp, event_type, image_path, 'pending', description))

        event_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return event_id

    def update_event_status(self, event_id, status):
        """
        更新事件状态

        Args:
            event_id: 事件ID
            status: 新状态
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE events SET status = ? WHERE id = ?
        ''', (status, event_id))

        conn.commit()
        conn.close()

    def get_recent_events(self, limit=20):
        """
        获取最近的事件记录

        Args:
            limit: 返回记录数量

        Returns:
            list: 事件记录列表
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, timestamp, event_type, image_path, status
            FROM events
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (limit,))

        events = cursor.fetchall()
        conn.close()

        return events

    def add_log(self, log_level, message):
        """
        添加系统日志

        Args:
            log_level: 日志级别 (INFO/WARNING/ERROR)
            message: 日志消息
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute('''
            INSERT INTO system_logs (timestamp, log_level, message)
            VALUES (?, ?, ?)
        ''', (timestamp, log_level, message))

        conn.commit()
        conn.close()

    def get_recent_logs(self, limit=50):
        """
        获取最近的系统日志

        Args:
            limit: 返回记录数量

        Returns:
            list: 日志记录列表
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, timestamp, log_level, message
            FROM system_logs
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (limit,))

        logs = cursor.fetchall()
        conn.close()

        return logs